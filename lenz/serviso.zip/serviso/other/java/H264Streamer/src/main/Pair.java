//
//  Pair.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 13/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package main;

public class Pair<A,B> {
	private A first;
	private B second;
	
	public Pair(A first, B second) {
		this.first = first;
		this.second = second;
	}
	
	public A first() {
		return first;
	}
	
	public B second() {
		return second;
	}
}
