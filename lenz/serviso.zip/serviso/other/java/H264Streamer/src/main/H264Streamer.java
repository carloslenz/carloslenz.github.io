//
//  H264Streamer.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 02/01/09.
//  Copyright (c) 2009 Carlos Eduardo Lenz. All rights reserved.
//
package main;

public class H264Streamer {

    public static void main (String args[]) {
		try {
			avcff.run.Main.main(args);
		} catch (ExitExecutionException e) {
			System.out.println(e.getMessage());
			Throwable cause = e.getCause();
			if (cause != null) {
				cause.printStackTrace();
			}
			System.exit(1);
		}
    }
}
