//
//  EventRecorder.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 09/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package main;

import main.ExitExecutionException;
import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class EventRecorder {
	static private EventRecorder instance =
		new EventRecorder("stderr", System.err);
	
	static public EventRecorder getInstance() {
		return instance;
	}
	
	static public void add(Object... params) {
		getInstance().add(params);
	}
	
	static public void change(File file) {
		try {
			String previous = instance.filename;
			instance = new EventRecorder(file.getCanonicalPath(),
										 new FileOutputStream(file));
			instance.addEvent(new Object[] { "previous-file", previous });
		}
		catch (IOException ex) {
			getInstance().addEvent(new Object[] { "change-failed",
												  file.getPath() });
		}
	}
	
	private String filename;
	private Writer writer;
	
	private EventRecorder(String filename, OutputStream os) {
		this.filename = filename;
		this.writer = new OutputStreamWriter(os);
	}
	
	public void addEvent(Object[] params) {
		try {
			long when = System.nanoTime();
			writer.write("event: ");
			for (Object obj : params) {
				writer.append(obj.toString()).append(' ');
			}
			writer.append(Long.toString(when)).append('\n');
		}
		catch (IOException ex) {
			ExitExecutionException.interrupt(ex,
											 Messages.EVENT_WRITE_ERROR_MSG);
		}
	}
}
