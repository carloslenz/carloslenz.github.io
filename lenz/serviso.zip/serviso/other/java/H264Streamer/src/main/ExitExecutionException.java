//
//  ExitExecutionException.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 02/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package main;

public class ExitExecutionException extends RuntimeException {
	public ExitExecutionException(String msg) {
		super(msg);
	}

	public ExitExecutionException(String msg, Throwable t) {
		super(msg, t);
	}
	
	static public void interrupt(Messages msg, Object... args) {
		throw new ExitExecutionException(msg.format(args));
	}

	static public void interrupt(String msg) {
		throw new ExitExecutionException(msg);
	}

	static public void interrupt(Throwable t, Messages msg, Object... args) {
		throw new ExitExecutionException(msg.format(args), t);
	}

	static public void interrupt(Throwable t, String msg) {
		throw new ExitExecutionException(msg, t);
	}
}
