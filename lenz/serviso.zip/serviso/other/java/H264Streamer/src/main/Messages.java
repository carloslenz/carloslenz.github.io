//
//  Messages.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 09/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package main;

import java.util.HashMap;
import java.util.Map;

public enum Messages {
	EVENT_WRITE_ERROR_MSG("Could not write to event log"),
	DGRAM_NOT_COMPLETE_MSG("Datagram not complete"),
	MISSING_INTERFACE_PORT_MSG("missing argument net-interface:ip-port"),
	IPPORT_NOT_NUMBER_MSG("ip-port must be an integer number"),
	UNRECOGNIZED_INTERFACE_PORT_MSG("unrecognized argument format, expected " +
									"interface:ip-port"),
	NET_INTERFACE_NOT_FOUND_MSG("The network interface name was not found"),
	UNKNOWN_HOST_MSG("Unknown host"),
	DGRAM_SEND_ERROR_MSG("Datagram send error"),
	DGRAM_RECEIVE_ERROR_MSG("Datagram receive error"),
	SOCKET_ERROR_MSG("Socket error"),
	IO_ERROR_MSG("I/O error"),
	MISSING_DECODE_TIME_MSG("Missing decode time"),
	EXTRA_DECODE_TIME_MSG("Extra decode time"),
	WRITE_ERROR("Error writing output"),
	UNKNOWN_SLICE_TYPE("unknown slice type = %d"),
	UNKNOWN_NALU_TYPE("unknown NALU type = %d"),
	FILE_NOT_FOUND("File not found: %s"),
	INVALID_QTBINARY_ITEM("Not a valid QtBinary item (size > 1)!"),
	READ_MAX_32BITS("cannot read more than 32 bits"),
	INVALID_IGNORE_BITS("invalid ignoreReadBits: %d"),
	NALU_LEN("NALU length = %ld"),
	LENGTH_SIZE_MINUS_ONE("Invalid LengthSizeMinusOne: expected 0, 1 or 3 " +
						  "but got %d"),
	EXPECTED_SIZE("expected: %ld got %ld"),
	STSD_VERSION_FLAGS_0("Unrecognized stsd version&flags, expected 0 but " +
						 "got %ld"),
	AVCC_MISSING_CHILD("Node avc1 does not havea avcC child node"),
	MULTIPLE_VIDEO_TRACKS("Found multiple video tracks (avc1)"),
	SIZE_EQ_0("size == 0 is not supported"),
	EXTENDED_SIZE_1("extended size (1) is not supported"),
	TRAILING_DATA("unexpected (trailing) binary data!"),
	INNER_ITEM_OVERFLOW("inner item overflow"),
	PREDEF_MINUS_1("Pre-defined field unrecognized, found %d instead of -1"),
	PREDEF_UNRECOGNIZED("Reserved/Pre-Defined field unrecognized, byte " +
						"%d : expected %d but got %d"),
	INVALID_PACKETS("Invalid packets: %ld,%ld"),
	UNKNOWN_ERROR("unknown error"),
	MISSING_FILENAME("missing argument: filename"),
	UNEXPECTED_FILE_NOT_FOUND("FileNotFound: should not happen since it was " +
							"opened before"),
	FILE_READ_ERROR("FileReadError from %ld to %ld"),
	UNKNOWN_VIDEO_TYPE("Unknown video type"),
	STSD_1_ENTRY("Only 1-entry stsd-s are supported, not %d"),
	CONVERSION_ERROR("Error converting '%s' to %s"),
	FILE_ERROR("File error: %s"),
	UNKNOWN_OPERATION("unknown operation: %s"),
	PLAYER_ERROR("Error starting player: %s"),
	MISSING_CONFIGURATION("Missing configuration named: %s"),
	JMX_ERROR("Java Management error"),
	GAP("Gap between %d and %d");
	
	private final String message;

	Messages(String message) {
		this.message = message;
	}
	
	public String format(Object... args) {
		return String.format(message, args);
	}
}
