//
//  CompressControlInfo.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 28/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.common;

import main.ExitExecutionException;
import main.Messages;
import java.io.OutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
//import java.util.zip.GZIPOutputStream;

public class CompressControlInfo {
	static private final CompressControlInfo instance =
		new CompressControlInfo();
	
	static public CompressControlInfo instance() {
		return instance;
	}
	
	private long startMem, sizeMem;
	private PacketImportances importanceMem;
	
	private int count;
	private long last = 0;
	private int fileNum = 0;
	private DataOutputStream stream;
//	private GZIPOutputStream gstream;
	
	public void add(long start, int size, PacketImportances importance) {
		try {
			startChecking(start, size);
			if (startMem == 0) {
				startMem = start;
				sizeMem = size;
				importanceMem = importance;				
			} else if (importance != importanceMem) {
				writeMem();
				startMem = start;
				sizeMem = size;
				importanceMem = importance;
			} else {
				sizeMem += size;
			}
//			stream.writeInt((int) start);
//			stream.writeInt(size);
//			stream.writeByte(importance.getImportance());
			last += size;
		}
		catch (IOException ex) {
			ExitExecutionException.interrupt(ex, Messages.IO_ERROR_MSG);
		}
	}
	
	private final long MAX_UINT = Integer.MAX_VALUE; // problem over 2M
	private final long MAX_USHORT = MAX_UINT; //Character.MAX_VALUE;
	
	private void startChecking(long start, int size) {
		if (last != 0) {
			if (last != start) {
				ExitExecutionException.interrupt(Messages.GAP,
												 Long.valueOf(last),
												 Long.valueOf(start));
			}
			if (start > MAX_UINT || size > MAX_USHORT) {
				// TODO: proper message
				System.err.format("Too big %d %d", Long.valueOf(start),
								  Integer.valueOf(size));
				System.exit(1);
			}
//			if (++count > 20) {
//				openStream();
//			}
			return;
		}		
		last = start;
		openStream();
	}
	
	private void openStream() {
		try {
			count = 1;
			if (fileNum++ >= 1) {
				close();
			}
			String fname = "/tmp/testvidpcs.txt";
//			String fname = String.format("/tmp/test/%06d.sgz",
//										 Integer.valueOf(fileNum));
			OutputStream os = new FileOutputStream(fname);
//			gstream = new GZIPOutputStream(os);
			stream = new DataOutputStream(os);
		}
		catch (IOException ex) {
			ExitExecutionException.interrupt(ex, Messages.IO_ERROR_MSG);
		}
	}
	
	private void writeMem() throws IOException {
		String ln = String.format("%d,%d,%d\n", Long.valueOf(startMem),
								  Long.valueOf(sizeMem),
								  Byte.valueOf(importanceMem.getImportance()));
		
		stream.writeUTF(ln);
	}
	
	public void close() {
		try {
			if (stream != null) {
				if (startMem != 0) {
					writeMem();
				}
				stream.flush();
//				gstream.finish();
				stream.close();
			}
		}
		catch (IOException ex) {
			ExitExecutionException.interrupt(ex, Messages.IO_ERROR_MSG);
		}
	}
	
	protected void finalize() {
		close();
	}
}
