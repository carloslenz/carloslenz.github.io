//
//  Configuration.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 14/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.run;

import main.ExitExecutionException;
import main.Messages;
import avcff.common.ControlProtocolType;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.Properties;

public class Configuration {
	
	// static:
	
	// for use with System.getenv
	static private final String HOME_ENV_KEY = "HOME";
	
	// for use with Properties.getProperty
	static private final String OPERATION_KEY = "operation";
	static private final String SOURCE_KEY = "source";
	static private final String DESTINATION_KEY = "destination";
	static private final String PLAYER_KEY = "player";
	static private final String NETWORK_INTERFACE_KEY = "networkinterface";
	static private final String HOST_KEY = "host";
	static private final String PORT_NUMBER_KEY = "port";
	static private final String SERVER_HOST_KEY = "serverhost";
	static private final String SERVER_PORT_NUMBER_KEY = "serverport";
	static private final String ERROR_RATE_KEY = "errorrate";
	static private final String PROTOCOL_KEY = "protocol";

	static private final String DEFAULT_FILENAME = "H264Streamer.properties";
	static private final String DEFAULT_OPTION = "default";
	
	static public Configuration loadFromCommandLineArguments(String[] args) {
		String filename = DEFAULT_FILENAME;
		String option = DEFAULT_OPTION;
		switch (args.length) {
			case 0:
				// defaults filename and action
				break;
			case 1:
				// default filename
				option = args[0];
				break;
			case 2:
			default: // ignore extra arguments
				filename = args[0];
				option = args[1];
				break;
		}
		return loadFilenameWithOption(filename, option);
	}
	
	static public Configuration loadFilenameWithOption(String filename,
													   String option) {
		boolean firstFailed = false;
		
		Properties defaults = new Properties();
		try {
			String home = System.getenv(HOME_ENV_KEY);
			InputStream isDefaults = fileInputStream(filename, home);
			defaults.load(isDefaults);
		} catch (IOException ex) {
			firstFailed = true;
		}
		
		Properties properties = new Properties(defaults);
		try {
			InputStream isProperties = fileInputStream(filename, null);
			properties.load(isProperties);
		} catch (IOException ex) {
			if (firstFailed) {
				ExitExecutionException.interrupt(Messages.FILE_ERROR,									 filename);
			}
		}
		
		return new Configuration(properties, option);
	}
	
	static private InputStream fileInputStream(String filename, String path)
	throws FileNotFoundException {
		return new FileInputStream(new File(path, filename));
	}
	
	// instance
	
	private Properties properties;
	private String option;
	
	public Configuration(Properties properties, String option) {
		this.properties = properties;
		this.option = option;
	}
	
	public String getOperation() {
		return getValueForKey(OPERATION_KEY);
	}
	
	public String getSource() {
		return getValueForKey(SOURCE_KEY);
	}
	
	public String getDestination() {
		return getValueForKey(DESTINATION_KEY);
	}
	
	public String getPlayer() {
		return getValueForKey(PLAYER_KEY);
	}
	
	public ControlProtocolType getProtocolType() {
		return stringToProtocolType(getValueForKey(PROTOCOL_KEY));
	}
	
	public NetworkInterface getNetworkInterface() {
		return stringToNetworkInterface(getValueForKey(NETWORK_INTERFACE_KEY));
	}
	
	public InetAddress getAddress() {
		return stringToInetAddress(getValueForKey(HOST_KEY));
	}
	
	public int getPort() {
		return stringToInt(getValueForKey(PORT_NUMBER_KEY));
	}
	
	public InetAddress getServerAddress() {
		return stringToInetAddress(getValueForKey(SERVER_HOST_KEY));
	}
	
	public int getServerPort() {
		return stringToInt(getValueForKey(SERVER_PORT_NUMBER_KEY));
	}
	
	public float getErrorRate() {
		return stringToFloat(getValueForKey(ERROR_RATE_KEY));
	}

	private String getValueForKey(String key) {
		return this.properties.getProperty(this.option + '.' + key);
	}
	
	private InetAddress stringToInetAddress(String host) {
		if (host == null) {
			return null;
		}
		try {
			return InetAddress.getByName(host);
		} catch (UnknownHostException ex) {
			ExitExecutionException.interrupt(ex, Messages.UNKNOWN_HOST_MSG);
			return null;
		}
	}
	
	private int stringToInt(String value) {
		if (value == null) {
			return 0;
		}
		try {
			return Integer.parseInt(value);
		} catch (NumberFormatException ex) {
			ExitExecutionException.interrupt(Messages.CONVERSION_ERROR,
											 value, "int");
			return 0;
		}
	}
	
	private ControlProtocolType stringToProtocolType(String name) {
		// TODO: ignore the parameter for now
		return ControlProtocolType.STREAMING;
	}
	
	private float stringToFloat(String value) {
		if (value == null) {
			return 0;
		}
		try {
			return Float.parseFloat(value);
		} catch (NumberFormatException ex) {
			ExitExecutionException.interrupt(Messages.CONVERSION_ERROR,
											 value, "float");
			return 0;
		}
	}

	private NetworkInterface stringToNetworkInterface(String networkInterfaceName) {
		try {
			Enumeration<NetworkInterface> enumeration =
				NetworkInterface.getNetworkInterfaces();
			while (enumeration.hasMoreElements()) {
				NetworkInterface netIn = enumeration.nextElement();
				String displayName = netIn.getDisplayName();
				if (displayName.equals(networkInterfaceName)) {
					return netIn;
				}
			}
		} catch (SocketException ex) {
			ExitExecutionException.interrupt(ex, Messages.SOCKET_ERROR_MSG);
		}
//		ExitExecutionException.interrupt(Messages.NET_INTERFACE_NOT_FOUND_MSG);
		return null;
	}
}
