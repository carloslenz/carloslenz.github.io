//
//  PacketInfo.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 23/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

public class PacketInfo {
	private int size;
	private double decodeTime;
	private boolean recoveryRequested;
	
	public PacketInfo(double decodeTime, int size) {
		this.decodeTime = decodeTime;
		this.size = size;
		this.recoveryRequested = false;
	}
	
	public double getDecodeTime() {
		return decodeTime;
	}

	public int getSize() {
		return size;
	}
	
	public boolean isRecoveryRequested() {
		return recoveryRequested;
	}

	public void setRecoveryRequested(boolean b) {
		recoveryRequested = b;
	}
}
