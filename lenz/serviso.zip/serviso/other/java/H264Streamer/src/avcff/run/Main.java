/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.run;

/**
 *
 * @author cel
 */
public class Main {
	private Setup setup;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Main(args).execute();
    }
    
    Main(String[] args) {
		Configuration config =
			Configuration.loadFromCommandLineArguments(args);
		this.setup = new Setup(config);
	}
    
    public void execute() {
		this.setup.execute();
    }
}
