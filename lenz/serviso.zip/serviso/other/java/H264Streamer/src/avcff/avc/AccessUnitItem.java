/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.avc;

import avcff.common.PacketImportances;
import java.io.IOException;
import java.io.OutputStream;

/**
 *
 * @author cel
 */
public interface AccessUnitItem {
    void printInfo(String prefix);
    void writeTo(OutputStream os, int naluLen, long start) throws IOException;
	int size();
	byte[] getData();
	PacketImportances getImportance();
}
