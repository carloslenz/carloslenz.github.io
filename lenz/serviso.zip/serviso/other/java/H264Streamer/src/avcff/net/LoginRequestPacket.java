//
//  LoginRequestPacket.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 23/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import java.io.IOException;
import java.io.ObjectInputStream;

public class LoginRequestPacket extends ControlPacket {
	public LoginRequestPacket(Destination origin) {
		super (origin);
	}
	
	public PacketTypes getType() {
		return PacketTypes.LOGIN_REQUEST;
	}
	
	static public LoginRequestPacket readFromStream(ObjectInputStream ois)
	throws IOException {
		ControlPacket packet = ControlPacket.readFromStream(ois);
		return new LoginRequestPacket(packet.getDestination());
	}
	
}
