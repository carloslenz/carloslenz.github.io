//
//  ControlPacket.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 11/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import main.ExitExecutionException;
import main.Messages;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.net.InetAddress;

public class ControlPacket extends AbstractPacket {

	private Destination myself;
	
	public ControlPacket(Destination myself) {
		this.myself = myself;
	}
	
	public PacketTypes getType() {
		return PacketTypes.CONTROL;
	}
	
	public Destination getDestination() {
		return myself;
	}
	
	public void writeToStream(ObjectOutputStream oos) throws IOException {
		byte[] buffer = myself.getAddress().getAddress();
		byte len = (byte) buffer.length;
		oos.writeByte(len);
		oos.write(buffer);
		oos.writeInt(myself.getPort());
	}
	
	static public ControlPacket readFromStream(ObjectInputStream ois)
	throws IOException {
		byte len = ois.readByte();
		byte[] buffer = new byte[len];
		ois.readFully(buffer);
		InetAddress address = InetAddress.getByAddress(buffer);
		int port = ois.readInt();
		return new ControlPacket(new Destination(address, port));
	}
}
