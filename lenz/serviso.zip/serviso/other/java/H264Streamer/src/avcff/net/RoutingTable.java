//
//  RoutingTable.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 17/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import java.net.InetAddress;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class RoutingTable {
	private final int STREAMING_FAKE_ROUTING_INDEX = -1;
	
	private Node myself;
	private Destination server;
	private Map<Integer, Set<Destination>> routes;
	private Set<Destination> knownNodes;
	
	public RoutingTable(InetAddress address, int port) {
		this.myself = new Node(address, port);
		this.routes = new HashMap<Integer, Set<Destination>>();
		this.knownNodes = new HashSet<Destination>();
		this.server = this.myself;
	}
	
	public void setServer(InetAddress address, int port) {
		this.server = new Destination(address, port);
		addKnownNode(this.server);
	}
	
	public Node getMyself() {
		return myself;
	}
	
	public Destination getServer() {
		return server;
	}
	
	public void addDestination(Destination dest) {
		addDestination(STREAMING_FAKE_ROUTING_INDEX, dest);
	}
	
	public Destination[] getDestinations() {
		return getDestinationsFor(STREAMING_FAKE_ROUTING_INDEX);
	}
	
	public void removeDestination(Destination dest) {
		removeDestination(STREAMING_FAKE_ROUTING_INDEX, dest);
	}
	
	public void addDestination(int i, Destination dest) {
		Set<Destination> destinations = routes.get(i);
		if (destinations == null) {
			destinations = new HashSet<Destination>();
			routes.put(i, destinations);
		}
		destinations.add(dest);
		addKnownNode(dest);
	}
	
	public Destination[] getDestinationsFor(int i) {
		Set<Destination> destinations = routes.get(i);
		if (destinations == null) {
			// use default routes if possible
			// TODO: check for possible exploits
			if (i != STREAMING_FAKE_ROUTING_INDEX) {
				return getDestinations();
			} else {
				return null;
			}
		}
		return destinations.toArray(new Destination[0]);
	}
	
	public void removeDestination(int i, Destination dest) {
		Set<Destination> destinations = routes.get(i);
		if (destinations != null) {
			destinations.remove(dest);
		}
	}
	
	public void addKnownNode(Destination dest) {
		knownNodes.add(dest);
	}
	
	public Set<Destination> getKnownNodes() {
		return knownNodes;
	}

	public void removeKnownNode(Destination dest) {
		knownNodes.add(dest);
	}
}
