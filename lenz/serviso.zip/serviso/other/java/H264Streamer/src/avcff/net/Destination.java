//
//  Destination.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 11/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import main.Messages;
import main.ExitExecutionException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.io.IOException;

public class Destination {
	protected InetAddress address;
	protected int port;
	
	public Destination(String host, int port) {
		try {
			this.address = InetAddress.getByName(host);
			this.port = port;
		} catch (UnknownHostException ex) {
			ExitExecutionException.interrupt(ex, Messages.UNKNOWN_HOST_MSG);
		}
	}

	public Destination(InetAddress address, int port) {
		this.address = address;
		this.port = port;
	}
	
	public InetAddress getAddress() {
		return address;
	}
	
	public int getPort() {
		return port;
	}

	public void send(DatagramSocket from, AbstractPacket packet) {
		try {
			byte[] data = packet.writeToArray();
			DatagramPacket dgram =
			new DatagramPacket(data, data.length, address, port);
			from.send(dgram);
		}
		catch (IOException ex) {
			ExitExecutionException.interrupt(ex,
											 Messages.DGRAM_SEND_ERROR_MSG);
		}
	}
}
