/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.avc;

import main.Messages;
import main.ExitExecutionException;

/**
 *
 * @author cel
 */
public class BitReader {
    private byte[] data;
    private int pos;

    BitReader(byte[] data) {
        this.data = data;
        this.pos = 0;
    }
    
    long readBits(int bits) {
        if (bits <= 0)
            return 0;
        
        if (bits > 32) {
            ExitExecutionException.interrupt(Messages.READ_MAX_32BITS);
		}
        
        int usingBits = unusedBits();
        long value = (byte) ignoreReadBits(getIt(), 8 - usingBits);
        advance(usingBits);
        if (usingBits < bits) {
            usingBits = bits - usingBits;
            while (usingBits > 8) {
                value = (value << 8) | getIt();
                advance(8);
                usingBits -= 8;
            }
            value = (value << usingBits) | ignoreReadBits(getIt(), -usingBits);
            advance(usingBits);
        } else if (usingBits > bits) {
            int leftBits = usingBits - bits;
            value >>= leftBits;
            advance(-leftBits);
        }
        return value & selectedBits(bits);
    }

    int ignoreReadBits(int v, int ammount) {
        switch (ammount) {
            case -7:
                return v >> 1;
            case -6:
                return v >> 2;
            case -5:
                return v >> 3;
            case -4:
                return v >> 4;
            case -3:
                return v >> 5;
            case -2:
                return v >> 6;
            case -1:
                return v >> 7;
            case -8: case 0: case 8:
                return v;
            case 7:
                return v & 1;
            case 6:
                return v & 3;
            case 5:
                return v & 7;
            case 4:
                return v & 15;
            case 3:
                return v & 31;
            case 2:
                return v & 63;
            case 1:
                return v & 127;
            default:
                ExitExecutionException.interrupt(Messages.INVALID_IGNORE_BITS,
												 Integer.valueOf(ammount));
				return -1;
        }
    }

    byte getIt() {
        return data[alignedPos()];
    }
    
    void advance(int bits) {
        pos += bits;
    }

    int alignedPos() {
        return pos / 8;
    }

    int unusedBits() {
        int b = pos % 8;
        return (b == 0) ? 8 : 8 - b;
    }

    byte readUev() {
        int zeroesRead = 0;
        while(readBits(1) == 0) {
            zeroesRead++;
        }
//        byte codeNum = (byte) (Math.pow(2, zeroesRead) - 1 +
//							   readBits(zeroesRead));
        byte codeNum = (byte) ((1 << zeroesRead) - 1 + readBits(zeroesRead));
        return codeNum;
    }

    long selectedBits(int bits) {
        switch (bits) {
            case 32:
                return 0xFFFFFFFF;
            case 31:
                return 0x7FFFFFFF;
            case 30:
                return 0x3FFFFFFF;
            case 29:
                return 0x1FFFFFFF;
            case 28:
                return 0x0FFFFFFF;
            case 27:
                return 0x07FFFFFF;
            case 26:
                return 0x03FFFFFF;
            case 25:
                return 0x01FFFFFF;
            case 24:
                return 0x00FFFFFF;
            case 23:
                return 0x007FFFFF;
            case 22:
                return 0x003FFFFF;
            case 21:
                return 0x001FFFFF;
            case 20:
                return 0x000FFFFF;
            case 19:
                return 0x0007FFFF;
            case 18:
                return 0x0003FFFF;
            case 17:
                return 0x0001FFFF;
            case 16:
                return 0x0000FFFF;
            case 15:
                return 0x00007FFF;
            case 14:
                return 0x00003FFF;
            case 13:
                return 0x00001FFF;
            case 12:
                return 0x00000FFF;
            case 11:
                return 0x000007FF;
            case 10:
                return 0x000003FF;
            case 9:
                return 0x000001FF;
            case 8:
                return 0x000000FF;
            case 7:
                return 0x0000007F;
            case 6:
                return 0x0000003F;
            case 5:
                return 0x0000001F;
            case 4:
                return 0x0000000F;
            case 3:
                return 0x00000007;
            case 2:
                return 0x00000003;
            case 1:
                return 0x00000001;
            case 0:
            default:
                return 0;
        }
    }
}
