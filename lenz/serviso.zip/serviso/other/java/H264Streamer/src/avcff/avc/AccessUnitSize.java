/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.avc;

import avcff.common.PacketImportances;
import avcff.mp4ff.QtData;
import java.io.IOException;
import java.io.OutputStream;

/**
 *
 * @author cel
 */
public class AccessUnitSize /*implements AccessUnitItem*/ {
    private long sampleSize;

    AccessUnitSize(long sampleSize) {
        this.sampleSize = sampleSize;
    }

    public void printInfo(String prefix) {
    }

    public void writeTo(OutputStream os, int naluLen) throws IOException {
        os.write(getData());
    }
	
	public byte[] getData() {
		return QtData.wordToBytes(sampleSize);
	}
	
	public PacketImportances getImportance() {
		return PacketImportances.ACCESS_UNIT_SIZE_UNUSED;
	}

}
