//
//  ControlProtocol.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 19/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

public interface ControlProtocol {
	void incommingControlPacketForServer(ControlPacket control, Server server);
	void incommingControlPacketForClient(ControlPacket control, Client client);
	void incommingLoginRequestForServer(LoginRequestPacket control,
										Server server);
	void incommingLoginRequestForClient(LoginRequestPacket control,
										Client client);
	void serverCompleteLoginForDestination(Destination dest, Server server);
	void clientCompleteLoginForDestination(Destination dest, Client client);
	Destination destinationForRecovery(int i, Client client);
}
