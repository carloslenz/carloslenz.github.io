/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

import avcff.packetizer.Packetizer;
import java.io.IOException;
import java.io.OutputStream;

/**
 *
 * @author cel
 */
public abstract class QtData {

    private long size;

    public QtData(long size) {
        this.size = size;
    }
    
    public long getSize() {
        return size;
    }
    
    public void printInfo() {
        printInfo("");
    }
	
	public Packetizer getPacketizer() {
		// overwritten by some subclasses
		throw new UnsupportedOperationException();
	}
	
	public byte[] getRange(long offset, int maxSize) {
		int size = Math.min(maxSize, (int)(getSize() - offset));
		byte[] data = new byte[size];
		getRange(offset, data, 0);
		return data;
	}
	
	public long getRange(long rangeStart, byte[] data, long dataOffset) {
		// overwritten by some subclasses
		throw new UnsupportedOperationException();
	}
    
    abstract void printInfo(String prefix);
    
    public abstract void writeTo(OutputStream os) throws IOException;

    static void shiftToByte(long x, byte[] b, int i) {
        b[i] = (byte) ((x >> (24 - 8 * i)) & 255);
    }

    static public byte[] wordToBytes(long x) {
        byte[] b = new byte[4];
        shiftToByte(x, b, 0);
        shiftToByte(x, b, 1);
        shiftToByte(x, b, 2);
        shiftToByte(x, b, 3);
        return b;
    }

    static public long bytesToWord(byte[] b) {
        return bytesToWord(b, 0);
    }

    static public long bytesToWord(byte[] b, int pos) {
        short[] ub = bytesToUnsigned(b, pos);
        return ub[3] +
            (ub[2] << 8) +
            (ub[1] << 16) +
            (ub[0] << 24);
    }

    static public byte[] shortToBytes(int x) {
        byte[] b = new byte[2];
        shiftToByte(x, b, 0);
        shiftToByte(x, b, 1);
        return b;
    }

    static public int bytesToShort(byte[] b) {
        short[] ub = bytesToUnsigned(b);
        return ub[1] +
            (ub[0] << 8);
    }

    static public short[] bytesToUnsigned(byte[] b) {
        return bytesToUnsigned(b, 0);
    }

    static public short[] bytesToUnsigned(byte[] b, int pos) {
        short[] ub = new short[b.length - pos];
        for (int i = pos; i < b.length; ++i) {
            byte x = b[i];
            ub[i - pos] = (short) ((x >= 0) ? x : 256 + x);
        }
        return ub;
    }
    
}
