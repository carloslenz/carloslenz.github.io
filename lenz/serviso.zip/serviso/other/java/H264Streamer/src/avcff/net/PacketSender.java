//
//  PacketSender.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 13/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import main.Pair;
import java.util.Set;
import java.util.HashSet;

public class PacketSender implements HistoryListener, Runnable {
	private Networked net;
	private Set<NetPacket> historyItemsSet;
	
	public PacketSender(Networked net) {
		this.net = net;
		this.historyItemsSet = new HashSet<NetPacket>();
	}
	
	public void historyItemSet(NetPacket packet) {
		synchronized (historyItemsSet) {
			historyItemsSet.add(packet);
		}
	}
	
	public void run() {
		synchronized (historyItemsSet) {
			for (NetPacket packet : historyItemsSet) {
				net.schedulePacketDelivery(packet);
			}
			historyItemsSet.clear();
		}
	}
}
