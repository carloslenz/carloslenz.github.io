//
//  SendSomePackets.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 19/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import java.net.DatagramSocket;

public class PacketDelivery implements Runnable {
	private Destination[] destinations;
	private AbstractPacket packet;
	private DatagramSocket socket;
	
	public PacketDelivery(AbstractPacket packet, DatagramSocket socket,
						   Destination[] destinations) {
		this.destinations = destinations;
		this.packet = packet;
		this.socket = socket;
	}
	
	public void run() {
		for (Destination dest: destinations) {
			dest.send(socket, packet);
		}
	}
}
