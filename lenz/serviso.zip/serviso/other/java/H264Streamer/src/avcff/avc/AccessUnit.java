/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.avc;

import main.Messages;
import main.ExitExecutionException;
import avcff.mp4ff.QtBinary;
import avcff.mp4ff.QtMdatChunk;
import avcff.mp4ff.QtMdatPacketCache;
import avcff.mp4ff.QtPacket;
import avcff.packetizer.AccessUnitPacketizer;
import avcff.packetizer.Packetizer;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author cel
 */
public class AccessUnit implements QtMdatChunk {

    AccessUnitItem[] splitNALUs(byte[] data, int naluLenLen) {
        
        QtBinary bin = new QtBinary(data);

        List<AccessUnitItem> nalus = new ArrayList<AccessUnitItem>();

        // according to MPEG-4 Part 15 spec, it should work in this way!
        //long sampleSize = bin.getUInt32(0);
        //nalus.add(new AccessUnitSize(sampleSize));
        //int pos = 4; // skip sampleSize
        int pos = 0;
        long len = 0;
        for (; pos < data.length; pos += len + naluLenLen) {
            len = getLen(bin, pos, naluLenLen);
            if (len > data.length) {
                ExitExecutionException.interrupt(Messages.NALU_LEN, 
												 Long.valueOf(len));
            }
            if (len == 0) {
                len = data.length - pos;
            }
            byte[] b = new byte[(int)len];
            System.arraycopy(data, pos + naluLenLen, b, 0, b.length);
            byte[] bLen = new byte[naluLenLen];
            System.arraycopy(data, pos, bLen, 0, bLen.length);
            nalus.add(new NALU(bLen, b));
        }
        return nalus.toArray(new AccessUnitItem[0]);
    }
    
    long getSampleSize(QtPacket packet) {
        return packet.size();
    }
	
	public AccessUnitItem[] getNALUs(QtPacket packet,
									 QtMdatPacketCache cache) {
        byte[] data = cache.fetch(packet.getStart(), packet.getStop());
        int naluLenLen = cache.getNaluLen();
		return splitNALUs(data, naluLenLen);
	}

    public void printInfo(QtPacket packet, String prefix,
						  QtMdatPacketCache cache) {
        System.out.println(prefix + "(" + packet.getStart() + ")" +
						   "AVC Sample: "+ getSampleSize(packet));
        for (AccessUnitItem item : getNALUs(packet, cache)) {
            item.printInfo(prefix + " ");
        }
    }

    public void writeTo(QtPacket packet, OutputStream os,
						QtMdatPacketCache cache) throws IOException {
//        // according to MPEG-4 Part 15 spec, it should work!
//        os.write(QtData.wordToBytes(getSampleSize(packet)));
        byte[] data = cache.fetch(packet.getStart(), packet.getStop());
        int naluLenLen = cache.getNaluLen();
		long start = packet.getStart();
        for (AccessUnitItem item : splitNALUs(data, naluLenLen)) {
//            if (avcff.Main.shouldSimulateFailureNow())
//                continue; // WRONG: should write zeroes
            item.writeTo(os, cache.getNaluLen(), start);
			start += item.size();
        }
    }
	
	public Packetizer getPacketizer(QtPacket packet, QtMdatPacketCache cache) {
		return new AccessUnitPacketizer(this, packet, cache);
	}

    long getLen(QtBinary bin, int pos, int naluLen) {
        switch (naluLen) {
        case 1:
            return bin.getByte(pos);
        case 2:
            return bin.getUInt16(pos);
        case 4:
            return bin.getUInt32(pos);
        default:
            invalidNaluLenError(naluLen);
            return -1;
        }
    }
    
    static void invalidNaluLenError(int naluLen) {
        ExitExecutionException.interrupt(Messages.LENGTH_SIZE_MINUS_ONE,
										 Integer.valueOf(naluLen - 1));
    }
}
