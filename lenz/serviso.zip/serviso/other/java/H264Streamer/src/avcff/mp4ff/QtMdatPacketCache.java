/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

import main.Messages;
import main.ExitExecutionException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cel
 */
public class QtMdatPacketCache {
    private File file;
    private int naluLen;

    QtMdatPacketCache(File file) {
        this.file = file;
    }

    public byte[] fetch(long start, long stop) {
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            fis.skip(start);
            
            if (stop <= 0)
                stop = getFileSize();

            int size = (int) (stop - start);
            byte[] data = new byte[size];
            fis.read(data);

            return data;
        } catch (FileNotFoundException ex) {
            ExitExecutionException.
				interrupt(Messages.UNEXPECTED_FILE_NOT_FOUND);
			return null;
        } catch (IOException ex) {
            ExitExecutionException.interrupt(Messages.FILE_READ_ERROR,
											 Long.valueOf(start),
											 Long.valueOf(stop));
			return null;
        } finally {
            try {
                fis.close();
            } catch (IOException ex) {
                Logger.getLogger(QtMdatPacketCache.class.getName()).
					log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void setNaluLen(int naluLen) {
        this.naluLen = naluLen;
    }

    public int getNaluLen() {
        return naluLen;
    }

    long getFileSize() {
        return file.length();
    }
}
