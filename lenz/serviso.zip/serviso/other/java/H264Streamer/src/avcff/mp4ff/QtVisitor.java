/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

import main.ExitExecutionException;
import main.Messages;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 *
 * @author cel
 */
class QtVisitor {

    private QtPacket[] packetInfos;
	private double timescale;
    private List<Long> videoOffsets2 = null;
    private List<Long> otherOffsets2 = null;
    private List<Long> sampleSizes = null;
	private List<Double> sampleDecodeTimes = null;
    private List<Long> otherSizes2 = null;
    private List<QtSampleToChunkEntry> otherS2CEntries = null;
    private List<QtSampleToChunkEntry> videoS2CEntries = null;
    private SortedSet<QtPacket> packets = new TreeSet<QtPacket>();
    
    private LinkedList<String> boxes = new LinkedList<String>();
    private boolean gotVmhd = false;
    private boolean gotTracks = false;
    private boolean gotSizes = false;
    private boolean gotSmhd = false;
    private int naluLen = -1;
    
    void enter(String name) {
        if ("vmhd".equals(name))
            gotVmhd = true;
        else if ("smhd".equals(name))
            gotSmhd = true;
        boxes.addLast(name);
    }

    void visit(QtData data) {
        String name = boxes.removeLast();
        if ("mdia".equals(name)) { // CHECK: was "minf"
            gotVmhd = false;
            gotSmhd = false;
			timescale = 0;
        }
        List<Long> targetOffsets = null;
        List<Long> targetSizes = null;
        List<QtSampleToChunkEntry> targetS2CEntries = null;
		if ("mdhd".equals(name)) {
            // Format:
            // =======================
            // QtBox:
            // - int32: size
            // - int32: type = 'mdhd'
            // option A QtBinary:
            // - int8:  version = 0
            // - int24: flags = 0
			// - int32:	creation_time
			// - int32:	modification_time
			// - int32:	timescale
			// - int32:	duration
			// option B QtBinary:
            // - int8:  version = 1
            // - int24: flags = 0
			// - int64:	creation_time
			// - int64:	modification_time
			// - int32:	timescale
			// - int64:	duration
            QtBinary bin = ((QtBox)data).getBinary();
            long version = bin.getUInt32(0);
			switch ((int)version) {
				case 0:
					// skip: version(1b) + flags(3b) +
					//	creation_time(4b) + modification_time(4b)
					timescale = bin.getUInt32(12);
					break;
				case 1:
					// skip: version(1b) + flags(3b) +
					//	creation_time(8b) + modification_time(8b)
					timescale = bin.getUInt32(20);
					break;
				default:
					timescale = 0;
					break;
			}
        } else if ("stts".equals(name)) {
            // Format:
            // =======================
            // QtBox:
            // - int32: size
            // - int32: type = 'stts'
            // QtBinary:
            // - int8:  version = 0
            // - int24: flags = 0
            // - int32: entry_count
            // - int32,int32 * count: sample_counts,sample_deltas
			sampleDecodeTimes = new ArrayList<Double>();
			QtBinary bin = ((QtBox)data).getBinary();
			int offset = 4;
			// skip: version(1b) + flags(3b)
			long entry_count = bin.getUInt32(offset);
			offset += 4;
			long totalDecodeTime = 0;
			for (int i = 0; i < entry_count; ++i, offset +=4) {
				long sample_count = bin.getUInt32(offset);
				offset += 4;
				Double value = totalDecodeTime / timescale;
				totalDecodeTime += bin.getUInt32(offset);
				for (int j = 0; j < sample_count; ++j) {
					sampleDecodeTimes.add(value);
				}
			}
        } else if ("stco".equals(name)) {
            // Format:
            // =======================
            // QtBox:
            // - int32: size
            // - int32: type = 'stco'
            // QtBinary:
            // - int8:  version = 0
            // - int24: flags = 0
            // - int32: count
            // - int32 * count: offsets
            List<Long> offsets = new ArrayList<Long>();
            QtBinary bin = ((QtBox)data).getBinary();
            long count = bin.getUInt32(4); // skip version(1b)+flags(3b)
            long words = (bin.getSize())/4;
            if (count + 2 == words) {
                // consider the previously skipped word and the count one
                for (int i = 0; i < count; ++i) {
                    offsets.add(bin.getUInt32((2 + i) * 4));
                }
            } else {
                ExitExecutionException.interrupt(Messages.EXPECTED_SIZE, 
												 Long.valueOf(words),
												 Long.valueOf(count + 2));
            }
            targetOffsets = offsets;
            if (gotVmhd) {
                targetS2CEntries = videoS2CEntries;
                videoOffsets2 = offsets;
                targetSizes = sampleSizes;
                gotTracks = true;
            } else {
                targetS2CEntries = otherS2CEntries;
                otherOffsets2 = offsets;
                targetSizes = otherSizes2;
            }
        } else if ("stsz".equals(name)) {
            // Format:
            // =======================
            // QtBox:
            // - int32: size
            // - int32: type = 'stsz'
            // QtBinary:
            // - int8:  version = 0
            // - int24: flags = 0
            // - uint32 sample_size
            // - uint32 sample_count
            // - uint32[*] entry_size { if sample_size == 0 }
            List<Long> entrySizes = new ArrayList<Long>();
            QtBinary bin = ((QtBox)data).getBinary();
            long sampleSize = bin.getUInt32(4); // skip version(1b)+flags(3b)
            long sampleCount = bin.getUInt32(8);
            if (sampleSize == 0) {
                for (int i = 0; i < sampleCount; ++i) {
                    entrySizes.add(bin.getUInt32((3 + i) * 4));
                }
            } else {
                for (int i = 0; i < sampleCount; ++i) {
                    entrySizes.add(sampleSize);
                }
            }
            targetSizes = entrySizes;
            if (gotVmhd) {
                targetS2CEntries = videoS2CEntries;
                sampleSizes = entrySizes;
                targetOffsets = videoOffsets2;
                gotSizes = true;
            } else {
                targetS2CEntries = otherS2CEntries;
                otherSizes2 = entrySizes;
                targetOffsets = otherOffsets2;
            }
        } else if ("stsd".equals(name) && gotVmhd()) {
            QtBinary bin = ((QtBox)data).getBinary();
            long word = bin.getUInt32(0);
            if (word != 0) {
                ExitExecutionException.interrupt(Messages.STSD_VERSION_FLAGS_0,
												 Long.valueOf(word));
            }
            long entryCount = bin.getUInt32(4);
            if (entryCount != 1) {
                ExitExecutionException.interrupt(Messages.STSD_1_ENTRY,
												 entryCount);
            }
            int pos = 8;
            for (int i = 0; i < entryCount; ++i) {
                long entrySize = bin.getUInt32(pos);
                String entryName = new String(bin.getWord(pos+4));
                if ("avc1".equals(entryName)) {
                    // MPEG4-Part 10: VisualSampleEntry ignore 78b
                    pos += 78;
                    // MPEG4-Part 15: AVCConfigurationRecord ignore
					//  header (avcC) 8b, data 4b
                    pos += 8 + 4;
					// ignore size too
                    String entry2Name = new String (bin.getWord(pos)); 
                    pos += 4;
                    if (!"avcC".equals(entry2Name)) {
                        ExitExecutionException.
							interrupt(Messages.AVCC_MISSING_CHILD);
                    }
                    pos += 4; // ignore 4x 1b fields
                    byte bitRec = bin.getByte(pos);
                    pos ++;
                    if (naluLen > 0) {
                        ExitExecutionException.
							interrupt(Messages.MULTIPLE_VIDEO_TRACKS);
					}
                    naluLen = (bitRec & 3) + 1;
                    // bitRec = bin.getByte(pos);
                    // int nrSPS = bitRec & 0x1F;
                    // pos ++;
                    //     nrSPS x (2b len + SPS NALUs)
                    // int nrPPS = bin.getByte(pos);
                    // pos ++;
                    //     nrPPS x (2b len + PPS NALUs)
                    break;
                }
                pos += entrySize;
            }
        } else if ("stsc".equals(name)) {
            // Format:
            // =======================
            // QtBox:
            // - int32: size
            // - int32: type = 'stsc'
            // QtBinary:
            // - int8:  version = 0
            // - int24: flags = 0
            // - uint32 entry_count
            // - uint32[*] first_chunk, samples_per_chunk,
			//             sample_description_index, firstSample
            List<QtSampleToChunkEntry> entries =
				new ArrayList<QtSampleToChunkEntry>();
            QtBinary bin = ((QtBox)data).getBinary();
            long entryCount = bin.getUInt32(4); // skip version(1b)+flags(3b)
            for (int i = 0, pos = 8; i < entryCount; ++i, pos += 12) {
                long firstChunk = bin.getUInt32(pos);
                long samplesPerChunk = bin.getUInt32(pos + 4);
                long sampleDescriptionIndex = bin.getUInt32(pos + 8);
                entries.add(new QtSampleToChunkEntry(firstChunk,
													 samplesPerChunk,
													 sampleDescriptionIndex));
            }
            targetS2CEntries = entries;
            if (gotVmhd) {
                videoS2CEntries = entries;
                targetOffsets = videoOffsets2;
                targetSizes = sampleSizes;
            } else {
                otherS2CEntries = entries;
                targetOffsets = otherOffsets2;
                targetSizes = otherSizes2;
            }
        }
        if (targetOffsets != null && targetSizes != null &&
			targetS2CEntries != null)
		{
            packets.addAll(generatePackets(targetOffsets, targetSizes,
										   targetS2CEntries, gotVmhd));
			sampleDecodeTimes = null;
            videoOffsets2 = null;
            sampleSizes = null;
            videoS2CEntries = null;
            otherOffsets2 = null;
            otherSizes2 = null;
            otherS2CEntries = null;
        }
    }
    
    boolean gotVmhd() {
        return gotVmhd;
    }
    
    boolean gotSmhd() {
        return gotSmhd;
    }

    boolean gotTracks() {
        return gotTracks;
    }
    
    void complete() {
        if (packetInfos == null)
            generateAllPackets();
    }

    void generateAllPackets() {
        packetInfos = packets.toArray(new QtPacket[0]);
    }
        
    List<QtPacket> generatePackets(List<Long> offsets, List<Long> sizes,
								   List<QtSampleToChunkEntry> entries,
								   boolean isVideo) {
        List<QtPacket> pInfos = new ArrayList<QtPacket>();
        int i = 1;
        int sizeI = 0;
        long firstSample = 0;
		Iterator<Double> decodeTimesIterator = sampleDecodeTimes.iterator();
        for (; i < entries.size(); ++i) {
            QtSampleToChunkEntry entry = entries.get(i-1);
            long firstChunk = entry.getFirstChunk();
            long samplesPerChunk = entry.getSamplesPerChunk();
            QtSampleToChunkEntry nextEntry = entries.get(i);
            long nextChunk = nextEntry.getFirstChunk();
            long nextSample = (nextChunk - firstChunk) * samplesPerChunk +
				firstSample;
            firstSample = generateSampleToChunkPackets(pInfos,
													   firstChunk,
													   nextChunk,
													   firstSample,
													   nextSample,
													   samplesPerChunk,
													   offsets,
													   sizes,
													   decodeTimesIterator,
													   isVideo);
        }
        QtSampleToChunkEntry entry = entries.get(i-1);
        generateSampleToChunkPackets(pInfos,
									 entry.getFirstChunk(),
									 offsets.size() + 1,
									 firstSample,
									 sizes.size() + 1,
									 entry.getSamplesPerChunk(),
									 offsets,
									 sizes,
									 decodeTimesIterator,
									 isVideo);
		if (decodeTimesIterator.hasNext()) {
			ExitExecutionException.interrupt(Messages.EXTRA_DECODE_TIME_MSG);
		}
        return pInfos;
    }

    long generateSampleToChunkPackets(List<QtPacket> pInfos, long firstChunk,
									  long nextChunk, long firstSample,
									  long nextSample, long samplesPerChunk,
									  List<Long> offsets, List<Long> sizes,
									  Iterator<Double> decodeTimesIterator,
									  boolean isVideo) {
        for (; firstChunk < nextChunk; ++firstChunk) {
            long start = offsets.get((int) (firstChunk - 1));
            for (int k = 0; k < samplesPerChunk; ++k, ++firstSample) {
                long stop = start + sizes.get((int) firstSample);
				if (!decodeTimesIterator.hasNext()) {
					ExitExecutionException.
						interrupt(Messages.MISSING_DECODE_TIME_MSG);
				}
                pInfos.add(new QtPacket(decodeTimesIterator.next(), start,
										stop, getPacketType(isVideo)));
                start = stop;
            }
        }
        return firstSample;
    }
    
    QtPacket.QtPacketType getPacketType(boolean isVideo) {
        return isVideo ? 
			QtPacket.QtPacketType.Video : 
			QtPacket.QtPacketType.Other;
    }

    QtPacket[] getPackets() {
        return packetInfos;
    }
    
    int getNaluLen() {
        return naluLen;
    }
    
}
