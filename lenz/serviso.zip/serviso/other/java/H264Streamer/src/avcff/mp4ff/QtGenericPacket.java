/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

import avcff.common.CompressControlInfo;
import avcff.common.PacketImportances;
import avcff.packetizer.Packetizer;
import avcff.packetizer.GenericChunkPacketizer;
import java.io.IOException;
import java.io.OutputStream;

/**
 *
 * @author cel
 */
public class QtGenericPacket implements QtMdatChunk {
    private String kind;
    
    QtGenericPacket(String kind) {
        this.kind = kind;
    }

    public void printInfo(QtPacket packet, String prefix,
						  QtMdatPacketCache cache) {
        System.out.println(prefix + "(" + packet.getStart() + ")" + kind +
						   ": " + packet.size());
    }

    public void writeTo(QtPacket packet, OutputStream os,
						QtMdatPacketCache cache) throws IOException {
        os.write(cache.fetch(packet.getStart(), packet.getStop()));
		CompressControlInfo.instance().add(packet.getStart(),
										   (int)packet.size(),
										   PacketImportances.SOUND);
    }
	
	public Packetizer getPacketizer(QtPacket packet, QtMdatPacketCache cache) {
		return new GenericChunkPacketizer(this, packet, cache);
	}
}
