/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

import main.Messages;
import main.ExitExecutionException;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author cel
 */
public class QtReader {
    private InputStream is;
    private long position;
    private Set<String> binaryAtoms;
    private QtVisitor visitor;
    private File file;
    private QtMdat mdat;
	private boolean toplevel;

    public QtReader(File file) throws FileNotFoundException {
        this.file = file;
        this.is = new FileInputStream(file);
		// BufferedInputStream provoca OutOfMemoryError:
		//this.is = new BufferedInputStream(new FileInputStream(file));
        this.position = 0L;
        this.visitor = new QtVisitor();
		this.toplevel = false;
        initBinaryAtoms();
    }
    
    public List<QtData> readAllBoxes() throws IOException {
        List<QtData> list = new ArrayList<QtData>();
		this.toplevel = true;
        for (QtData item = readNextBox(); item != null; item = readNextBox()) {
            list.add(item);
			this.toplevel = true;
        }
        
        initMdatNaluLen();
        
        
        // separated offsets
//        List<Long> videoOffsets = visitor.getVideoOffsets();
//        Long[] vidArray = new Long[videoOffsets.size()];
//        SortedSet<Long> otherOffsets = visitor.getOtherOffsets();
//        Long[] otherArray = new Long[otherOffsets.size()];
//        list.add(new QtOffsets(videoOffsets.toArray(vidArray), true));
//        list.add(new QtOffsets(otherOffsets.toArray(otherArray), false));
        
        // video-only portions
//        list.add(new QtPacketsInfo(visitor.getVideoPackets()));
        return list;
    }
    
    QtData readNextBox() throws IOException {
        try {
            return readNextBox(Integer.MAX_VALUE);
        } catch (EOFException ex) {
            return null;
        }
    }
    
    QtData readNextBox(int maxSize) throws IOException {
        QtData data = readNextBoxSimple(maxSize);
        visitor.visit(data);
        return data;
    }
    
    QtData readNextBoxSimple(int maxSize) throws IOException {
        byte bWord[] = new byte[4];
        byte bName[] = new byte[4];
		
		long initialPosition = position;
        
        //String msg = "" + position + ": ";
        long size = readWord(bWord);
        //System.out.print(msg); // not at EOF
        
        String name = readName(bName);
        int used = bWord.length + bName.length;
        
        if (size == 0) {
            ExitExecutionException.interrupt(Messages.SIZE_EQ_0);
        } else if (size == 1) {
            ExitExecutionException.interrupt(Messages.EXTENDED_SIZE_1);
        }
        
        if (name == null) {
            byte bBin[] = new byte[maxSize];
            System.arraycopy(bWord, 0, bBin, 0, bWord.length);
            System.arraycopy(bName, 0, bBin, bWord.length, bName.length);
            readBytes(bBin, used, maxSize - used);
            
            ExitExecutionException.interrupt(Messages.TRAILING_DATA);
            return new QtBinary(maxSize, bBin);
        } else {
            long remainingSize = size - bWord.length - bName.length;
            List<QtData> items = new ArrayList<QtData>();
            
            visitor.enter(name);
			
			boolean isTop = toplevel;

            if (isBinaryAtom(name)) {
                QtData data = null;

                if ("mdat".equals(name) /* && visitor.gotTracks()*/) {
                    data = mdat = new QtMdat(file, position, remainingSize);
                    skipBytes(remainingSize);
					
					if (!visitor.gotTracks()) {
						System.err.println("ERROR: Couldn't find track information before mdat");
					}
                } else {
                    maxSize = (int) remainingSize;

                    byte bBin[] = new byte[maxSize];

                    long posBefore = position;
                    readBytes(bBin);
 
                    data = new QtBinary(bBin);
                }
                items.add(data);
            } else {        
                //skipBytes(remainingSize);
                int specialSize = getSpecialSize(name);
                if (specialSize < 0) {
                    readSamples(- specialSize, items);
                } else {
                    if (specialSize > 0) {
                        byte[] specialBytes = new byte[specialSize];
                        readBytes(specialBytes);
                        items.add(new QtBinary(specialBytes));
                    }
                    readBoxItems(remainingSize - specialSize, items);
                }
            }
			if (isTop) {
				return new QtTopBox(size, initialPosition, name, items);
			} else {
				return new QtBox(size, name, items);				
			}
        }
    }
    
    void readBoxItems(long remainingSize, List<QtData> items) {
		this.toplevel = false;
        while (remainingSize > 0) {
            remainingSize = readNextItem(items, remainingSize);
        }
    }
    
    long readNextItem(List<QtData> items, long remainingSize) {
        try {
            QtData item = readNextBox((int)remainingSize);
            items.add(item);
            return remainingSize - item.getSize();
        } catch (IOException ex) {
            ExitExecutionException.interrupt(Messages.INNER_ITEM_OVERFLOW);
			return -1;
        }
    }

    String readName(byte[] b) throws IOException {
        readBytes(b);
        char[] c = new char[b.length];
        for (int i = 0; i < b.length; ++i) {
            byte x = b[i];
            if (!isAsciiLowercase(x))
                return null;
            c[i] = (char) x;
        }
        return new String(c);
    }
    
    long readWord(byte[] b) throws IOException {
        readBytes(b);
        long word = QtData.bytesToWord(b);
        return word;
    }
        
    int readShort() {
        byte[] b = new byte[2];
        return QtData.bytesToShort(b);
    }

    int readBytes(byte[] b, int pos, int size) throws IOException {
        int len = is.read(b, pos, size);
        if (len == -1) {
            throw new EOFException();
        }
        position += len;
        assert len == size;
        return len;
    }
    
    void skipBytes(long len) throws IOException {
        len = is.skip(len);
        if (len == -1) {
            throw new EOFException();
        }
        position += len;
    }

    boolean isAsciiLowercase(byte x) {
        return (x >= 97 &&  x <= 122); // between 'a' and 'z'
    }

    int readBytes(byte[] b) throws IOException {
        return readBytes(b, 0, b.length);
    }

    void initBinaryAtoms() {
        this.binaryAtoms = new HashSet<String>();
        String[] atoms = new String[] {
            "ftyp", "wide", "free", "mdat", "mvhd", "tkhd", "mdhd", "mvhd",
            "crgn", "prfl", "tkhd", "kmat", "elst", "hdlr", "stts", "stss",
            "stsz", "stsc", "stco", "vmhd", "hdlr", "dref", "smhd",
            "hdlr", "dinf", "udta", "stsd", //"stbl",
            "iods", "ctts", "chap", "gmhd"
        };
        for (String atom : atoms) {
            binaryAtoms.add(atom);
        }
    }

    boolean isBinaryAtom(String name) {
        return binaryAtoms.contains(name);
    }

    QtPacket[] getMdatPackets() {
        return visitor.getPackets();
    }

    int getSpecialSize(String name) throws IOException {
//        if ("stsd".equals(name) && visitor.gotVmhd()) {
//            byte b[] = new byte[4];
//            long size = readWord(b);
//            return (int) -size;
//        }
        return 0;
    }

    QtData readSample() throws IOException {
        byte bWord[] = new byte[4];
        byte bName[] = new byte[4];
        
        //String msg = "" + position + ": ";
        long size = readWord(bWord);
        //System.out.print(msg); // not at EOF
        
        String name = readName(bName);
        int used = bWord.length + bName.length;

        // SampleEntry
        byte bReserved[] = new byte[12];
        readBytes(bReserved, 0, 6); // const uint8[6] reserved = 0
        ensureValue(bReserved, 0, 6);
        
        int dataReferenceIndex = readShort();
        
        // VisualSampleEntry
        readBytes(bReserved, 0, 2); // uint16 pre_defined = 0
        ensureValue(bReserved, 0, 2);
        
        readBytes(bReserved, 0, 2); // const uint16 reserved = 0
        ensureValue(bReserved, 0, 2);
        
        readBytes(bReserved, 0, 12); // uint32[3] pre_defined = 0
        ensureValue(bReserved, 0, 12);
        
        int width = readShort();
        int height = readShort();
        
        byte bData[] = new byte[32];
        long horizresolution = readWord(bData); // 0x00480000 => 72 dpi
        long vertresolution = readWord(bData);
        
        
        readBytes(bReserved, 0, 4); // const uint32 reserved = 0
        ensureValue(bReserved, 0, 4);
        
        int frameCount = readShort(); // 1
        
        readBytes(bData, 0, 32);
        String compressorname = new String(bData);
        
        int depth = readShort(); // 0x0018
        int preDefMinus1 = readShort();
        if (preDefMinus1 != -1)
            ExitExecutionException.interrupt(Messages.PREDEF_MINUS_1,
											 Integer.valueOf(preDefMinus1));
        
        return new QtVideoSampleEntry(16, dataReferenceIndex, width, height,
									  horizresolution, vertresolution,
									  frameCount, depth);
    }

    void readSamples(int i, List<QtData> items) throws IOException {
        while (--i > 1) {
            items.add(readSample());
        }
    }

    void ensureValue(byte[] bData, int value, int len) {
        for (int i = 0; i < len; ++i) {
            byte b = bData[i];
            if (b != value) {
                ExitExecutionException.interrupt(Messages.PREDEF_UNRECOGNIZED,
												 Integer.valueOf(i),
												 Integer.valueOf(value),
												 Integer.valueOf(b));
            }
        }
    }

    private void initMdatNaluLen() {
        visitor.complete();
        mdat.setPackets(getMdatPackets());
        mdat.setNaluLen(visitor.getNaluLen());
    }
}
