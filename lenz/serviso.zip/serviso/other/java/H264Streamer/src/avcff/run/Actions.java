//
//  Actions.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 15/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.run;

import main.ExitExecutionException;
import main.Messages;
import avcff.common.ControlProtocolType;
import avcff.mp4ff.QtBox;
import avcff.mp4ff.QtData;
import avcff.mp4ff.QtMdat;
import avcff.mp4ff.QtReader;
import avcff.net.Client;
import avcff.net.NetPacket;
import avcff.net.Server;
import avcff.packetizer.Packetizer;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FilenameFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.List;

public class Actions {
    static private boolean TEST_PRODUCING_ERRORS = false;
	static private float errorRate = 0;
	
    static public boolean shouldSimulateFailureNow() {
        return TEST_PRODUCING_ERRORS && (Math.random() < errorRate);
    }

	static public void copy(String inFile, String outFile) {
		try {
			OutputStream os = new FileOutputStream(outFile);
			// buffered cripples the output somehow:
			os = new BufferedOutputStream(os);
			outputFilename(inFile, os);
		} catch (FileNotFoundException ex) {
			ExitExecutionException.interrupt(Messages.FILE_NOT_FOUND, outFile);
		}
	}
	
	static public void compare(String inFile, String outFile) {
		InputStream fis1 = getFileInputStream(inFile);
        InputStream fis2 = getFileInputStream(outFile);
        
        int b1 = 0;
        int b2 = 0;
        int i = 0;
        
        do {
			try {
				b1 = fis1.read();
			} catch (IOException ex) {
				ExitExecutionException.interrupt(ex, Messages.FILE_ERROR,
												 inFile);
			}
			try {
				b2 = fis2.read();
			} catch (IOException ex) {
				ExitExecutionException.interrupt(ex, Messages.FILE_ERROR,
												 inFile);
			}
			i++;
        } while (b1 == b2 && b1 != -1 && b2 != -1);
        
        if (b1 == b2) {
            System.out.println("identical");
        } else {
			String shorterName = null;
			if (b1 == -1) {
				shorterName = inFile;
			} else if (b2 == -1) {
				shorterName = outFile;
			}			
			if (shorterName != null) {
				System.out.format("%s is shorter\n", shorterName);
			} else {
				System.out.format("at %d, got %d versus %d\n",
								  Integer.valueOf(i), Integer.valueOf(b1),
								  Integer.valueOf(b2));
			}
        }
    }
	
	static public void out(String inFile) {
		outputFilename(inFile, System.out);
	}
	
	static public void play(String inFile, String player) {
		outputFilename(inFile, newPlayerOutputStream(player));
	}

	static public void testPlay(String inFile, String player,
								float errorRate) {
		setErrorRate(errorRate);
		outputFilename(inFile, newPlayerOutputStream(player));
	}

	static public void test(String inFile, float errorRate) {
		setErrorRate(errorRate);
		out(inFile);
	}

	static public void log(String inFile) {
		printHeader(inFile);
		for (QtData item : readFromFilename(inFile)) {
			item.printInfo();
		}		
	}

	static public void server(String source, NetworkInterface networkInterface,
							  InetAddress address, int port,
							  ControlProtocolType protocolType) {
		address = addressOrNetworkInterfaceNotNull(address, networkInterface);
		Server server = new Server(address, port, protocolType);
		for (QtData item : readFromFilename(source)) {
			if (item instanceof QtMdat) {
				server.signalHeaderHasEnded();
			}
			Packetizer packetizer = item.getPacketizer();
			while (packetizer.hasNext()) {
				NetPacket packet = packetizer.next();
				server.addNetPacket(packet);
			}
		}			
		server.signalNoMorePackets();
		server.startOperation();
	}

	static public void client(NetworkInterface networkInterface,
							  InetAddress address, int port,
							  InetAddress serverAddress,
							  int serverPort,
							  ControlProtocolType protocolType,
							  String player) {
		address = addressOrNetworkInterfaceNotNull(address, networkInterface);
		serverAddress = addressOrNetworkInterfaceNotNull(serverAddress,
														 networkInterface);	
		Client client = new Client(address, port, serverAddress, serverPort,
								   protocolType, player);
		client.startOperation();
	}
	
	static public void extract(String source) {
		FilenameFilter mp4FnameFilter = new FilenameFilter() {
			public boolean accept(File dir, String fname) {
				return fname.matches("^.*\\.mp4$");
			}
		};
		File[] files = new File(source).listFiles(mp4FnameFilter);
		if (files == null) {
			System.out.println("No files found at: " + source);
		}
		try {
			for (File f : files) {
				System.out.println("MP4 File: " + f.getCanonicalPath());
				File dest = new File(f.getCanonicalPath() + ".info");
				if (dest.exists()) {
					System.out.println("Skipping, found " + dest.getCanonicalPath());
					continue;
				}
				for (QtData data : readFromFile(f)) {
					QtData item0 = data;
					if (data instanceof QtBox) {
						item0 = ((QtBox)data).first();
					}
					if (item0 instanceof QtMdat) {
						FileOutputStream fos = new FileOutputStream(dest);
						System.out.println("Extracted to: " +
									   dest.getCanonicalPath());
						((QtMdat)item0).extractTo(fos);
						break;
					}
				}
				System.gc();
			}
		} catch (IOException ex) {
			ExitExecutionException.interrupt(ex, Messages.UNKNOWN_ERROR);
		}
	}
	
	// used by package avcff.net
	
	static public OutputStream newPlayerOutputStream(String player) {
		OutputStream os = startPlayerProcess(player).getOutputStream();
		return new BufferedOutputStream(os);
	}	
	
	// private methods
	
	static private InetAddress
	addressOrNetworkInterfaceNotNull(InetAddress address,
									 NetworkInterface networkInterface) {
		if (address == null && networkInterface != null) {
			// TODO: ignores all but the first address
			return networkInterface.getInetAddresses().nextElement();
		}
		return address;
	}
		
	
	static private void printHeader(String filename) {
		String bars = "==========";
		System.out.println(bars);
		System.out.println("Filename: " + filename);
		System.out.println(bars);
	}
	
	static private List<QtData> readFromFilename(String inFile) {
		return readFromFile(new File(inFile));
	}

	static private List<QtData> readFromFile(File f) {
		String fname = f.getAbsolutePath();
		try {
			fname = f.getCanonicalPath();
			QtReader reader = new QtReader(f);
			return reader.readAllBoxes();
		} catch (FileNotFoundException ex) {
			ExitExecutionException.interrupt(Messages.FILE_NOT_FOUND,
											 fname);
		} catch (IOException ex) {
			ExitExecutionException.interrupt(ex, Messages.UNKNOWN_ERROR);
		}
		return null;
	}	

	static private void outputFilename(String inFile, OutputStream out) {
		for (QtData item : readFromFilename(inFile)) {
			try {
				item.writeTo(out);
				out.flush();
			} catch (IOException ex) {
				ExitExecutionException.interrupt(ex, Messages.WRITE_ERROR);
			}
		}
	}
	
	static private Process startPlayerProcess(String player) {
		try {
			return new ProcessBuilder(player.split(" ")).start();
		} catch (IOException ex) {
			ExitExecutionException.interrupt(ex, Messages.PLAYER_ERROR,
											 player);
			return null;
		}
	}

    static int byteToInt(int b) {
        return (b << 8) >> 8;
    }
	
	static private InputStream getFileInputStream(String filename) {
		try {
			FileInputStream fis = new FileInputStream(new File(filename));
			return new BufferedInputStream(fis);
		} catch (FileNotFoundException ex) {
			ExitExecutionException.interrupt(Messages.FILE_NOT_FOUND,
											 filename);
			return null;
		}
	}
	
	static private void setErrorRate(float rate) {
		TEST_PRODUCING_ERRORS = true;
		errorRate = rate;
	}
}
