//
//  Setup.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 14/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.run;

import main.Messages;
import main.ExitExecutionException;
import avcff.common.ControlProtocolType;
import java.net.InetAddress;
import java.net.NetworkInterface;

public class Setup {
	
	static final public String COPY_OPERATION = "copy";
	static final public String COMPARE_OPERATION = "compare";
	static final public String OUT_OPERATION = "out";
	static final public String PLAY_OPERATION = "play";
	static final public String TEST_OPERATION = "test";
	static final public String TESTPLAY_OPERATION = "testplay";
	static final public String LOG_OPERATION = "log";
	static final public String SERVER_OPERATION = "server";
	static final public String CLIENT_OPERATION = "client";
	static final public String NETPLAY_OPERATION = "netplay";
	static final public String EXTRACT_OPERATION = "extract";

	private String operation;
	private String source;
	private String destination;
	private String player;
	private NetworkInterface networkInterface;
	private InetAddress address;
	private int port;
	private InetAddress serverAddress;
	private int serverPort;
	private float errorRate;
	private ControlProtocolType protocolType;
	
	public Setup(Configuration config) {
		operation = config.getOperation();
		source = config.getSource();
		destination = config.getDestination();
		player = config.getPlayer();
		networkInterface = config.getNetworkInterface();
		address = config.getAddress();
		port = config.getPort();
		serverAddress = config.getServerAddress();
		serverPort = config.getServerPort();
		errorRate = config.getErrorRate();
		protocolType = config.getProtocolType();
	}
	
	public void execute() {
		if (COPY_OPERATION.equals(operation)) {
			checkNotNull("source", source);
			checkNotNull("destination", destination);
			Actions.copy(source, destination);
		} else if (COMPARE_OPERATION.equals(operation)) {
			checkNotNull("source", source);
			checkNotNull("destination", destination);
			Actions.compare(source, destination);
		} else if (OUT_OPERATION.equals(operation)) {
			checkNotNull("source", source);
			Actions.out(source);
		} else if (TEST_OPERATION.equals(operation)) {
			checkNotNull("source", source);
			checkNotZero("errorrate", errorRate);
			Actions.test(source, errorRate);
		} else if (PLAY_OPERATION.equals(operation)) {
			checkNotNull("source", source);
			checkNotNull("player", player);
			Actions.play(source, player);
		} else if (TESTPLAY_OPERATION.equals(operation)) {
			checkNotNull("source", source);
			checkNotNull("player", player);
			checkNotZero("errorrate", errorRate);
			Actions.testPlay(source, player, errorRate);
		} else if (LOG_OPERATION.equals(operation)) {
			checkNotNull("source", source);
			Actions.log(source);
		} else if (CLIENT_OPERATION.equals(operation)) {
			checkNotZero("port", port);
			checkNotZero("serverport", serverPort);
			checkSomeNotNull("networkinterface, address", networkInterface,
							 address);
			checkSomeNotNull("networkinterface, serveraddress",
							 networkInterface, serverAddress);
			Actions.client(networkInterface, address, port, serverAddress,
						   serverPort, protocolType, null);
		} else if (NETPLAY_OPERATION.equals(operation)) {
			checkNotZero("port", port);
			checkNotZero("serverport", serverPort);
			checkNotNull("player", player);
			checkSomeNotNull("networkinterface, address", networkInterface,
							 address);
			checkSomeNotNull("networkinterface, serveraddress",
							 networkInterface, serverAddress);
			checkNotNull("protocol", protocolType);
			Actions.client(networkInterface, address, port, serverAddress,
							serverPort, protocolType, player);
		} else if (SERVER_OPERATION.equals(operation)) {
			checkNotNull("source", source);
			checkNotZero("port", port);
			checkSomeNotNull("networkinterface, address", networkInterface,
							 address);
			checkNotNull("protocol", protocolType);
			Actions.server(source, networkInterface, address, port,
						   protocolType);
		} else if (EXTRACT_OPERATION.equals(operation)) {
			checkNotNull("source", source);
			Actions.extract(source);
		} else {
			ExitExecutionException.interrupt(Messages.UNKNOWN_OPERATION,
											 operation);
		}
	}
	
	private void checkNotNull(String keyname, Object obj) {
		if (obj == null) {
			ExitExecutionException.interrupt(Messages.MISSING_CONFIGURATION,
											 keyname);
		}
	}

	private void checkSomeNotNull(String keynames, Object... objs) {
		for (Object obj : objs) {
			if (obj != null) {
				return;
			}
		}
		ExitExecutionException.interrupt(Messages.MISSING_CONFIGURATION,
										 keynames);
	}
	
	private void checkNotZero(String keyname, double value) {
		if (value == 0.0) {
			ExitExecutionException.interrupt(Messages.MISSING_CONFIGURATION,
											 keyname);
		}
	}
}
