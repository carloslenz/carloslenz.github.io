/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

import avcff.run.Actions;
import avcff.packetizer.Packetizer;
import java.io.IOException;
import java.io.DataOutputStream;
import java.io.OutputStream;

/**
 *
 * @author cel
 */
public class QtPacket implements Comparable<QtPacket> {
	private double decodeTime;
    private long start;
    private long stop;
    private QtPacketType video;
    
    public enum QtPacketType { Video, Other, Missing };

    public QtPacket(double decodeTime, long start, long stop,
					QtPacketType video) {
		this.decodeTime = decodeTime;
        this.start = start;
        this.stop = stop;
        this.video = video;
    }
	
    public double getDecodeTime() {
        return decodeTime;
    }
	
    public long getStart() {
        return start;
    }

    public long getStop() {
        return stop;
    }

    public boolean isVideo() {
        return video == QtPacketType.Video;
    }

    void printInfo(String string, QtMdatPacketCache cache) {
        getImplementation().printInfo(this, string, cache);
    }

    void writeTo(OutputStream os, QtMdatPacketCache cache) throws IOException {
        if (!Actions.shouldSimulateFailureNow()) {
            getImplementation().writeTo(this, os, cache);
		} else {
			// fail with blank data
			os.write(new byte[(int)(stop - start)]);
		}
    }
	
	void extractTo(DataOutputStream os) throws IOException {
		int size = (int)size();
		switch (video) {
			case Missing:
				System.out.println("missing: " + start);
			case Other:
				size = - size;
				break;
		}
		os.writeInt(size);
	}

    public QtMdatChunk getImplementation() {
        return QtPacketImplementationFactory.getImplementation(video);
    }
	
	public Packetizer getPacketizer(QtMdatPacketCache cache) {
		return getImplementation().getPacketizer(this, cache);
	}

    String rangeString() {
        return Long.toString(start) + "-" + stop;
    }
    
    String sizeString() {
        if (size() > 0)
            return "[" + size() + "]";
        return "";
    }
    
    String typeString() {
        return isVideo() ? "V" : "";
    }

    public long size() {
        return stop - start;
    }

    @Override
    public int hashCode() {
        return Long.valueOf(start).hashCode();
    }
    
    @Override
    public String toString() {
        return typeString() + rangeString() + sizeString();
    }
    
    @Override
    public boolean equals(Object o) {
        if (o instanceof QtPacket) {
            return start == ((QtPacket)o).start;
        }
        return false;
    }

    public int compareTo(QtPacket o) {
        if (start != o.start)
            return (int) (start - o.start);
        if (stop != o.stop)
            return (int) (stop - o.stop);
        if (video != o.video)
            return isVideo() ? +1 : -1;
        return 0;
    }
}
