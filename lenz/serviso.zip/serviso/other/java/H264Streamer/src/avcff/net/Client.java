//
//  Client.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 02/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import main.Messages;
import avcff.common.ControlProtocolType;
import avcff.run.Actions;
import java.io.OutputStream;
import java.net.InetAddress;
import java.util.concurrent.TimeUnit;
import java.util.ArrayList;
import java.util.SortedSet;
import java.util.TreeSet;

public class Client extends Networked {
	private String player;
	private PacketSender sender;
	private PacketReader reader;
	private OutputStream os;
	private PacketInfo[] pInfos;

	public Client(InetAddress address, int port, InetAddress serverAddress,
				  int serverPort, ControlProtocolType proto, String player) {
		super (serverAddress, serverPort, proto);
		this.sender = new PacketSender(this);
		this.history.addHistoryListener(this.sender);
		this.reader = new PacketReader(this);
		this.history.addHistoryListener(this.reader);
		this.player = player;
		this.loginResponses = new ArrayList<LoginResponsePacket>();
		routingTable.setServer(address, port);
	}
	
	public void startOperation() {
		super.startOperation();
		scheduleExecutionsPerSec(this.sender, 30);
		scheduleExecutionsPerSec(this.reader, 30);
		schedulePacketDelivery(getMyself().newLoginRequestPacket(),
							   getServer());
	}
	
	public void requestPacketRecoveryFor(int i) {
		PacketInfo pInfo = pInfos[i];
		if (pInfo.isRecoveryRequested()) {
			return;
		}
		pInfo.setRecoveryRequested(true);
		Destination dest = controlProtocol.destinationForRecovery(i, this);
		RecoveryRequestPacket packet = getMyself().newRecoveryRequestPacket(i);
		schedulePacketDelivery(packet, dest);
	}
	
	public void incommingNetPacket(NetPacket packet) {
		addNetPacket(packet);
	}
	
	public void incommingControlPacket(ControlPacket packet) {
		controlProtocol.incommingControlPacketForClient(packet, this);
	}
	
	public void incommingLoginRequestPacket(LoginRequestPacket packet) {
		controlProtocol.incommingLoginRequestForClient(packet, this);
	}
	
	public void incommingLoginResponsePacket(LoginResponsePacket packet) {
		for (LoginResponsePacket response : loginResponses) {
			if (response.compareTo(packet) == 0) {
				// TODO: log duplicated packet (malicious?)
				return;
			}
		}
		loginResponses.add(packet);
		LoginResponsePacket response =
			LoginResponsePacket.tryToJoin(loginResponses);
		if (response != null) {
			this.pInfos = response.getPacketInfos().toArray(new PacketInfo[0]);
			setHeaderSize(response.getHeaderSize());			
		}
	}

	public void completeLoginForDestination(Destination dest) {
		controlProtocol.clientCompleteLoginForDestination(dest, this);
	}
	
	public OutputStream getOutputStream() {
		if (os == null) {
			os = Actions.newPlayerOutputStream(player);
		}
		return os;
	}
	
	public PacketInfo getPacketInfo(int i) {
		if (pInfos.length <= i) {
			return null;
		}
		return pInfos[i];
	}
}
