	//
//  Networked.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 17/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import avcff.common.ControlProtocolType;
import java.net.InetAddress;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public abstract class Networked implements PacketHandler {
	protected final PacketHistory history;
	protected final ControlProtocol controlProtocol;
	protected final RoutingTable routingTable;
	
	private final ScheduledExecutorService scheduler;
	private final PacketReceiver receiver;
	private final LoginServer loginServer;

	private int headerSize;
	protected List<LoginResponsePacket> loginResponses;

	public Networked(InetAddress address, int port,
					 ControlProtocolType proto) {
		this.routingTable = new RoutingTable(address, port);
		this.history = new PacketHistory();
		this.loginServer = new LoginServer(this);
		this.controlProtocol = proto.newProtocolInstance();
		this.scheduler = Executors.newScheduledThreadPool(4);
		this.receiver = new PacketReceiver(getMyself(), this);
	}
	
	public void startOperation() {
		scheduleContinuously(this.receiver);
		// maximum 825 kbps per destination for the header
		scheduleExecutionsPerSec(this.loginServer, 550);
	}

	public void addNetPacket(NetPacket packet) {
		history.writeNetPacket(packet);
	}
	
	// scheduling
	
	public void schedulePacketDelivery(int index) {
		NetPacket packet = history.readNetPacket(index);
		schedulePacketDelivery(packet);
	}

	public void schedulePacketDelivery(NetPacket packet) {
		Destination[] destinations =
			routingTable.getDestinationsFor(packet.getIndex());
		schedulePacketDeliveryForDestinations(packet, destinations);
	}
	
	public void schedulePacketDelivery(int index, Destination dest) {
		NetPacket packet = history.readNetPacket(index);
		schedulePacketDelivery(packet, dest);
	}
	
	public void schedulePacketDelivery(AbstractPacket packet,
									   Destination dest) {
		Destination[] destinations = new Destination[] { dest };
		schedulePacketDeliveryForDestinations(packet, destinations);
	}
	
	protected void scheduleContinuously(Runnable runnable) {
		scheduler.scheduleWithFixedDelay(runnable, 0, 0,
										 TimeUnit.MILLISECONDS);
	}

	protected void scheduleExecutionsPerSec(Runnable runnable, int times) {
		long msDelay = (long)(1000.0 / times);
		scheduler.scheduleAtFixedRate(runnable, 0, msDelay,
									  TimeUnit.MILLISECONDS);
	}

	private void
	schedulePacketDeliveryForDestinations(AbstractPacket packet,
										  Destination[] destinations) {
		if (packet == null) {
			// TODO: log situation
			return;
		}
		Runnable delivery = new PacketDelivery(packet, getMyself().getSocket(),
											   destinations);
		// one-shot action
		scheduler.schedule(delivery, 0, TimeUnit.MILLISECONDS);		
	}
	
	public int getLoginResponseCount() {
		return loginResponses.size();
	}
	
	public void scheduleLoginResponseDelivery(int i, Destination dest) {
		schedulePacketDelivery(loginResponses.get(i), dest);
	}
	
	// accessors
	
	protected void setHeaderSize(int i) {
		this.headerSize = i;
	}
	
	public int getHeaderSize() {
		return this.headerSize;
	}
	
	// login
	
	public void startLoginForDestination(Destination dest) {
		this.loginServer.addDestination(dest);
	}

	public abstract void completeLoginForDestination(Destination dest);
	
	// forwarded methods
	
	protected Node getMyself() {
		return routingTable.getMyself();
	}
	
	protected Destination getServer() {
		return routingTable.getServer();
	}
	
	public void addRoute(int i, Destination dest) {
		routingTable.addDestination(i, dest);
	}

	public void addRoute(Destination dest) {
		routingTable.addDestination(dest);
	}
	
	public void removeRoute(int i, Destination dest) {
		routingTable.removeDestination(i, dest);
	}

	public void removeRoute(Destination dest) {
		routingTable.removeDestination(dest);
	}
	
	public void addKnownNode(Destination dest) {
		routingTable.addKnownNode(dest);
	}
	
	public void removeKnownNode(Destination dest) {
		routingTable.addKnownNode(dest);
	}

	// PacketHandler
	
	public void incommingPacket(AbstractPacket packet) {
		switch (packet.getType()) {
			case NET_PACKET:
				NetPacket net = (NetPacket)packet;
				incommingNetPacket(net);
				break;
			case CONTROL:
				ControlPacket control = (ControlPacket)packet;
				incommingControlPacket(control);
				break;
			case LOGIN_REQUEST:
				LoginRequestPacket login = (LoginRequestPacket)packet;
				incommingLoginRequestPacket(login);
				break;
			case RECOVERY_REQUEST:
				RecoveryRequestPacket recovery = (RecoveryRequestPacket)packet;
				incommingRecoveryRequestPacket(recovery);
				break;
			case LOGIN_RESPONSE:
				LoginResponsePacket response = (LoginResponsePacket)packet;
				incommingLoginResponsePacket(response);
				break;
		}
	}
	
	public void incommingRecoveryRequestPacket(RecoveryRequestPacket packet) {
		schedulePacketDelivery(packet.getIndex(), packet.getDestination());
	}

	abstract public void incommingNetPacket(NetPacket packet);
	abstract public void incommingControlPacket(ControlPacket packet);
	abstract public void
	incommingLoginRequestPacket(LoginRequestPacket packet);
	abstract public void
	incommingLoginResponsePacket(LoginResponsePacket packet);
}
