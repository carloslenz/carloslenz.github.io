//
//  AbstractPacket.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 13/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import main.ExitExecutionException;
import main.Messages;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public abstract class AbstractPacket {
	
	abstract public PacketTypes getType();

	abstract public void writeToStream(ObjectOutputStream os) throws IOException;
	
	public byte[] writeToArray() {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(baos);
			oos.writeByte(getType().toByte());
			writeToStream(oos);
			oos.flush();
			oos.close();
			return baos.toByteArray();
		}
		catch (IOException ex) {
			ExitExecutionException.interrupt(ex, Messages.IO_ERROR_MSG);
			return null;
		}
	}
	
	static public AbstractPacket readFromArray(byte[] data) {
		try {
			ByteArrayInputStream bais = new ByteArrayInputStream(data);
			ObjectInputStream ois = new ObjectInputStream(bais);
			AbstractPacket packet = null;
			byte type = ois.readByte();
			switch (PacketTypes.fromByte(type)) {
				case NET_PACKET:
					packet = NetPacket.readFromStream(ois);
				case CONTROL:
					packet = ControlPacket.readFromStream(ois);
				case LOGIN_REQUEST:
					packet = LoginRequestPacket.readFromStream(ois);
				case RECOVERY_REQUEST:
					packet = RecoveryRequestPacket.readFromStream(ois);
				case LOGIN_RESPONSE:
					packet = LoginResponsePacket.readFromStream(ois);
			}
			return packet;
		} catch (IOException ex) {
			ExitExecutionException.interrupt(ex, Messages.IO_ERROR_MSG);
			return null;
		}
	}
}
