//
//  Server.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 02/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import main.Messages;
import main.ExitExecutionException;
import avcff.common.ControlProtocolType;
import java.net.InetAddress;
import java.lang.management.ManagementFactory;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.JMException;

public class Server extends Networked implements ServerMBean {
	public Server(InetAddress address, int port, ControlProtocolType proto) {
		super (address, port, proto);
	}
	
	public void signalHeaderHasEnded() {
		setHeaderSize(history.size());
	}
	
	public void signalNoMorePackets() {
		if (!noMorePackets()) {
			// TODO: log
			return;
		}
		LoginResponsePacket response =
			new LoginResponsePacket(getMyself(), getHeaderSize());
		for (int i = 0; i < history.size(); ++i) {
			NetPacket packet = history.readNetPacket(i);
			response.addPacketInfo(packet.getDecodeTime(), packet.getSize());
		}
		this.loginResponses = response.breakIntoPackets();
	}
	
	public void startOperation() {
		signalNoMorePackets();
		super.startOperation();
		registerMBean();
	}
	
	private void registerMBean() {
		try {
			MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
			Class<?> klass = getClass();
			String pkgName = klass.getPackage().getName();
			String simpleName = klass.getSimpleName();
			// Construct the ObjectName for the MBean we will register
			ObjectName name = new ObjectName(pkgName + ":type=" + simpleName);
			
			mbs.registerMBean(this, name);
		}
		catch (JMException ex) {
			ExitExecutionException.interrupt(ex, Messages.JMX_ERROR);
		}
	}		
	
	public void startTransmission() {
		synchronized (this) {
//			schedulePacketsByDecodeTime();
//			startServerSender();
		}
	}

	public void completeLoginForDestination(Destination dest) {
		controlProtocol.serverCompleteLoginForDestination(dest, this);
	}
	
	public void incommingNetPacket(NetPacket packet) {
		// TODO: log unexpected
	}
	
	public void incommingLoginResponsePacket(LoginResponsePacket packet) {
		// TODO: log unexpected
	}

	public void incommingControlPacket(ControlPacket packet) {
		controlProtocol.incommingControlPacketForServer(packet, this);
	}

	public void incommingLoginRequestPacket(LoginRequestPacket packet) {
		if (noMorePackets()) {
			controlProtocol.incommingLoginRequestForServer(packet, this);
		} else {
			// empty packet means the server is not ready yet
			schedulePacketDelivery(new LoginResponsePacket(getMyself(),
														   getHeaderSize()),
								   packet.getDestination());
		}
	}
	
	private boolean noMorePackets() {
		return loginResponses != null;
	}
}
