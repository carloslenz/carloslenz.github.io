/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

import avcff.packetizer.Packetizer;
import java.io.IOException;
import java.io.OutputStream;

/**
 *
 * @author cel
 */
public interface QtMdatChunk {

    void printInfo(QtPacket packet, String prefix, QtMdatPacketCache cache);
    void writeTo(QtPacket packet, OutputStream os, QtMdatPacketCache cache)
		throws IOException;
	
	Packetizer getPacketizer(QtPacket packet, QtMdatPacketCache cache);
}
