/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

import main.Messages;
import main.ExitExecutionException;
import avcff.packetizer.Packetizer;
import avcff.packetizer.MdatPacketizer;
import java.io.File;
import java.io.IOException;
import java.io.DataOutputStream;
import java.io.OutputStream;

/**
 *
 * @author cel
 */
public class QtMdat extends QtData {
    private QtPacket[] packets;
    private QtMdatPacketCache cache;
    private long initialPosition;

    QtMdat(File file, long initialPosition, long size) {
        super(size);
        this.initialPosition = initialPosition;
        this.cache = new QtMdatPacketCache(file);
    }
    
    void setPackets(QtPacket[] packets) {
        this.packets = packets;
    }
	
	public QtPacket[] getPackets() {
		return packets;
	}
    
    void setNaluLen(int naluLen) {
        cache.setNaluLen(naluLen);
    }
	
	public long getInitialPosition() {
		return initialPosition;
	}
	
	public Packetizer getPacketizer() {
		return new MdatPacketizer(this);
	}
	
	public Packetizer getChunkPacketizer(long i) {
		return packets[(int)i].getPacketizer(cache);
	}

    @Override
    void printInfo(String prefix) {
        System.out.println(prefix + getSize() + "/binary");
        for (QtPacket packet : packets) {
            packet.printInfo(prefix + " ", cache);
        }
    }

    @Override
	public void writeTo(final OutputStream os) throws IOException {
		final PacketAction action = new PacketAction() {
			public void run(QtPacket packet) throws IOException {
				packet.writeTo(os, cache);
			}
		};
		visitAllPackets(action);
	}

	public void extractTo(OutputStream os) throws IOException {
		final DataOutputStream dos = new DataOutputStream(os);
		final PacketAction action = new PacketAction() {
			public void run(QtPacket packet) throws IOException {
				packet.extractTo(dos);
			}
		};
		int pos = (int)initialPosition;
		dos.writeInt(pos);
		visitAllPackets(action);
	}
	
    public void visitAllPackets(PacketAction action) throws IOException {
        long pos = initialPosition;
        for (int i = 0; i < packets.length; ++i) {
            QtPacket packet = packets[i];
            long start = packet.getStart();
            if (start > pos) {
                action.run(generateMissingPacket(pos, start));
            } else if (pos > start) {
                ExitExecutionException.interrupt(Messages.INVALID_PACKETS,
												 Long.valueOf(pos),
												 Long.valueOf(start));
            }
            action.run(packet);
            pos = packet.getStop();
        }
        long stop = initialPosition + getSize();
        if (pos < stop) {
            action.run(generateMissingPacket(pos, stop));
        }
    }

    QtPacket generateMissingPacket(long start, long stop) {
        // such MDAT interval was not referenced by any sample
		// decodeTime = 0 is ignored here
        return new QtPacket(0, start, stop, QtPacket.QtPacketType.Missing);
    }
}
