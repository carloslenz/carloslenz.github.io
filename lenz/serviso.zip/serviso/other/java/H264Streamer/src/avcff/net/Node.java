//
//  Node.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 10/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import main.ExitExecutionException;
import main.Messages;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.io.IOException;

public class Node extends Destination {
	private DatagramSocket socket;
	
	public Node(InetAddress address, int port) {
		super (address, port);
	}		

	public void receiveTo(PacketHandler handler) {
		try {
			byte[] data = new byte[20 * 1024];
			DatagramPacket dgram = new DatagramPacket(data, data.length);
			getSocket().receive(dgram);
			// int len = dgram.getLength();
			handler.incommingPacket(AbstractPacket.readFromArray(data));
		}
		catch (IOException ex) {
			ExitExecutionException.interrupt(ex,
											 Messages.DGRAM_RECEIVE_ERROR_MSG);
		}
	}
	
	public DatagramSocket getSocket() {
		if (socket == null) {
			try {
				socket = new DatagramSocket(port, address);
			}
			catch (SocketException ex) {
				ExitExecutionException.interrupt(ex,
												 Messages.SOCKET_ERROR_MSG);
			}
		}
		return socket;
	}
	
	public LoginRequestPacket newLoginRequestPacket() {
		return new LoginRequestPacket(this);
	}

	public RecoveryRequestPacket newRecoveryRequestPacket(int index) {
		return new RecoveryRequestPacket(this, index);
	}
}
