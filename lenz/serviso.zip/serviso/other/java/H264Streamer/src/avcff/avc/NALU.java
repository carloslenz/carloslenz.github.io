/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.avc;

import main.ExitExecutionException;
import main.Messages;
import avcff.common.PacketImportances;
import avcff.common.CompressControlInfo;
import avcff.mp4ff.QtData;
import java.io.IOException;
import java.io.OutputStream;

/**
 *
 * @author cel
 */
public class NALU implements AccessUnitItem {
    private byte[] data;
    private byte[] bLen;

    NALU(byte[] bLen, byte[] data) {
        this.bLen = bLen;
        this.data = data;
    }

    BitReader getBitReader() {
        BitReader bReader = new BitReader(data);
        bReader.advance(8); // NALU header
        return bReader;
    }
    
    String getNaluImportanceString() {
        return "Importance: " + getNaluImportance();
    }

    String getNaluTypeString() {
        int naluType = getNaluType();
        switch (naluType) {
            case 1:
                return "non-IDR slice: " + getSliceTypeString();
            case 2:
                return "partition-A";
            case 3:
                return "partition-B";
            case 4:
                return "partition-C";
            case 5:
                return "IDR slice: " + getSliceTypeString();
            case 6:
                return "supplemental enhancement information";
            case 7:
                return "sequence parameter set";
            case 8:
                return "picture parameter set";
            case 9:
                return "access unit delimiter";
            case 10:
                return "end of sequence";
            case 11:
                return "end of stream";
            case 12:
                return "filler data";
            case 13:
                return "sequence parameter set extension";
            default:
                return "unknown NALU type=" + naluType;
        }
    }
    
    String getSliceTypeString() {
        int sliceType = getSliceType();
        switch (sliceType) {
            case 0:
                return "P";
            case 1:
                return "B";
            case 2:
                return "I";
            case 3:
                return "SP";
            case 4:
                return "SI";
            case 5:
                return "P*";
            case 6:
                return "B*";
            case 7:
                return "I*";
            case 8:
                return "SP*";
            case 9:
                return "SI*";
            default:
                return "unknown slice type=" + sliceType;
        }
    }
    
    int getNaluImportance() {
        return (getNaluHeader() >> 5) & 0x03;
    }
    
    int getNaluType() {
        return getNaluHeader() & 31;
    }
    
    byte getNaluHeader() {
        return data[0];
    }
    
    int getSliceType() {
        BitReader bReader = getBitReader();
        bReader.readUev();
        return bReader.readUev();
    }
	
	PacketImportances getNaluTypeImportance() {
        int naluType = getNaluType();
        switch (naluType) {
            case 1:
                return PacketImportances.NON_IDR_SLICE;
            case 2:
                return PacketImportances.PARTITION_A;
            case 3:
                return PacketImportances.PARTITION_B;
            case 4:
                return PacketImportances.PARTITION_C;
            case 5:
                return PacketImportances.IDR_SLICE;
            case 6:
                return PacketImportances.SUPPLEMENTAL_ENHANCEMENT_INFORMATION;
            case 7:
                return PacketImportances.SEQUENCE_PARAMETER_SET;
            case 8:
                return PacketImportances.PICTURE_PARAMETER_SET;
            case 9:
                return PacketImportances.ACCESS_UNIT_DELIMITER;
            case 10:
                return PacketImportances.END_OF_SEQUENCE;
            case 11:
                return PacketImportances.END_OF_STREAM;
            case 12:
                return PacketImportances.FILLER_DATA;
            case 13:
                return PacketImportances.SEQUENCE_PARAMETER_SET_EXTENSION;
            default:
                ExitExecutionException.interrupt(Messages.UNKNOWN_NALU_TYPE, 
												 Integer.valueOf(naluType));
				return PacketImportances.OTHER;
        }
    }
	
	PacketImportances getSliceTypeImportance() {
        int sliceType = getSliceType();
        switch (sliceType) {
            case 0:
                return PacketImportances.P_SLICE;
            case 1:
                return PacketImportances.B_SLICE;
            case 2:
                return PacketImportances.I_SLICE;
            case 3:
                return PacketImportances.SP_SLICE;
            case 4:
                return PacketImportances.SI_SLICE;
            case 5:
                return PacketImportances.P_PLUS_SLICE;
            case 6:
                return PacketImportances.B_PLUS_SLICE;
            case 7:
                return PacketImportances.I_PLUS_SLICE;
            case 8:
                return PacketImportances.SP_PLUS_SLICE;
            case 9:
                return PacketImportances.SI_PLUS_SLICE;
            default:
				ExitExecutionException.interrupt(Messages.UNKNOWN_SLICE_TYPE,
												 Integer.valueOf(sliceType));
                return PacketImportances.OTHER;
        }
    }
	
	public PacketImportances getImportance() {
		PacketImportances importance = getNaluTypeImportance();
		if (importance.getImportance() < 0) {
			return getSliceTypeImportance();			
		}
		return importance;
	}
	
	public byte[] getData() {
		byte[] dest = new byte[bLen.length + data.length];
		System.arraycopy(bLen, 0, dest, 0, bLen.length);
		System.arraycopy(data, 0, dest, bLen.length, data.length);
		return data;
	}

    public void printInfo(String prefix) {
        System.out.println(prefix + data.length + "/" +
						   getNaluImportanceString() + ", " +
						   getNaluTypeString());
    }

    public void writeTo(OutputStream os, int naluLen, long start)
	throws IOException {
        //os.write(encodeNaluLen(data.length, naluLen));
        os.write(bLen);
        os.write(data);
		CompressControlInfo.instance().add(start, size(), getImportance());
    }
	
	public int size() {
		return bLen.length + data.length;
	}
    
    byte[] encodeNaluLen(int len, int naluLen) {
        switch (naluLen) {
            case 1:
                return new byte[] { (byte)len };
            case 2:
                return QtData.shortToBytes(len);
            case 4:
                return QtData.wordToBytes(len);
            default:
                AccessUnit.invalidNaluLenError(naluLen);
                return null;
        }
    }
}
