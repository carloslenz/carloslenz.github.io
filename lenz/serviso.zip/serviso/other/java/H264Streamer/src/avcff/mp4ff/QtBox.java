/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

import main.Messages;
import main.ExitExecutionException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

/**
 *
 * @author cel
 */
public class QtBox extends QtData {
    private String name;
    private List<QtData> items; // only the last may be QtBinary, 

    QtBox(long size, String name, List<QtData> items) {
        super(size);
        this.name = name;
        this.items = items;
    }
    
    public String getName() {
        return name;
    }
	
	public QtData first() {
		return items.get(0);
	}
	
	public long getRange(long rangeStart, byte[] data, long dataOffset) {
		long initialRangeStart = rangeStart;
		if (rangeStart < 8) {
			if (rangeStart < 4) {
				byte [] sz = wordToBytes(getSize());
				for (; rangeStart < sz.length; ++ rangeStart, ++ dataOffset) {
					data[(int)dataOffset] = sz[(int)rangeStart];
				}				
			}
			byte[] nm = getName().getBytes();
			for (int i = (int)(rangeStart - 4); i < nm.length;
				 ++ i, ++ rangeStart, ++ dataOffset)
			{
				data[(int)dataOffset] = nm[i];
			}
		}

		long missing = data.length - dataOffset;
		for (QtData item : items) {
			if (missing < 1) {
				break;
			}
			long nrBytes = item.getRange(rangeStart, data, dataOffset);
			dataOffset += nrBytes;
			rangeStart += nrBytes;
			missing -= nrBytes;
		}
		return rangeStart - initialRangeStart;
	}	
	
    QtBinary getBinary() {
        if (items.size() > 1)
            ExitExecutionException.interrupt(Messages.INVALID_QTBINARY_ITEM);
        return (QtBinary) items.get(0);
    }

    @Override
    void printInfo(String prefix) {
        System.out.println(prefix + getSize() + "/" + name);
        for (QtData item : items) {
            item.printInfo(prefix + " ");
        }
    }

    @Override
    public void writeTo(OutputStream os) throws IOException {
        os.write(wordToBytes(getSize()));
        os.write(name.getBytes());
        for (QtData item: items) {
            item.writeTo(os);
        }
    }
}
