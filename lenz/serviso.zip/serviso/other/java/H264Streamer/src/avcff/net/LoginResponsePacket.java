//
//  LoginRequestPacket.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 23/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LoginResponsePacket extends ControlPacket
implements Comparable<LoginResponsePacket> {
	private List<PacketInfo> pInfos;
	private int partIndex;
	private int partsCount;
	private int headerSize;
	
	public LoginResponsePacket(Destination origin, int headerSize) {
		this (origin, 1, 1, headerSize);
	}
	
	public LoginResponsePacket(Destination origin, int headerSize,
							   List<PacketInfo> pInfos) {
		this (origin, 1, 1, headerSize, pInfos);
	}

	public LoginResponsePacket(Destination origin, int partIndex,
							   int partsCount, int headerSize) {
		this (origin, partIndex, partsCount, headerSize,
			  new ArrayList<PacketInfo>());
	}

	private LoginResponsePacket(Destination origin, int partIndex,
								int partsCount, int headerSize,
								List<PacketInfo> pInfos) {
		super (origin);
		this.pInfos = pInfos;
		this.partIndex = partIndex;
		this.partsCount = partsCount;
		this.headerSize = headerSize;
	}
	
	public PacketTypes getType() {
		return PacketTypes.LOGIN_RESPONSE;
	}
	
	public List<PacketInfo> getPacketInfos() {
		return pInfos;
	}
	
	public int getHeaderSize() {
		return headerSize;
	}
	
	public void addPacketInfo(double decodeTime, int size) {
		addPacketInfo(new PacketInfo(decodeTime, size));
	}

	private void addPacketInfo(PacketInfo pInfo) {
		pInfos.add(pInfo);
	}
	
	public void writeToStream(ObjectOutputStream oos) throws IOException {
		super.writeToStream(oos);
		oos.writeInt(partIndex);
		oos.writeInt(partsCount);
		if (partIndex == partsCount) {
			oos.writeInt(headerSize);
			oos.writeInt(pInfos.size());
		}
		for (PacketInfo pInfo : pInfos) {
			oos.writeDouble(pInfo.getDecodeTime());
			oos.writeInt(pInfo.getSize());
		}
	}
	
	static private final int MAX_PINFOS = 120;
	
	public List<LoginResponsePacket> breakIntoPackets() {
		List<LoginResponsePacket> list = new ArrayList<LoginResponsePacket>();
		int count = pInfos.size() / MAX_PINFOS;
		if ((pInfos.size() % MAX_PINFOS) != 0) {
			count++;
		}
		for (int i = 0; i < count; i++) {
			LoginResponsePacket packet =
				new LoginResponsePacket(getDestination(), i, count,
										headerSize);
			int j = i * MAX_PINFOS;
			int range = Math.min(j + MAX_PINFOS, pInfos.size()); 
			for (; j < range; ++j) {
				packet.addPacketInfo(pInfos.get(j));
			}
			list.add(packet);
		}
		return list;
	}
	
	static public LoginResponsePacket readFromStream(ObjectInputStream ois)
	throws IOException {
		ControlPacket packet = ControlPacket.readFromStream(ois);
		Destination dest = packet.getDestination();
		int partIndex = ois.readInt();
		int partsCount = ois.readInt();
		int headerSize = 0;
		int count = MAX_PINFOS;
		if (partIndex == partsCount) {
			headerSize = ois.readInt();
			count = ois.readInt();
		}
		LoginResponsePacket response =
			new LoginResponsePacket(dest, partIndex, partsCount, headerSize);
		while (--count >= 0) {
			double decodeTime = ois.readDouble();
			int size = ois.readInt();
			response.addPacketInfo(decodeTime, size);
		}
		return response;
	}
	
	static public LoginResponsePacket
	tryToJoin(List<LoginResponsePacket> packets) {
		LoginResponsePacket last = packets.get(packets.size() - 1);
		if (packets.size() != last.partsCount) {
			return null;
		}
		Collections.sort(packets);
		List<PacketInfo> info = new ArrayList<PacketInfo>();
		for (LoginResponsePacket response : packets) {
			for (PacketInfo pInfo : response.pInfos) {
				info.add(pInfo);
			}
		}
		return new LoginResponsePacket(last.getDestination(), last.headerSize,
									   info);
	}
	
	public int compareTo(LoginResponsePacket other) {
		return other.partIndex - partIndex;
	}
}
