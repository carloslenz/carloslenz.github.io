//
//  PacketHistory.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 17/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import main.Pair;
import java.util.ArrayList;
import java.util.List;

public class PacketHistory {
	private ArrayList<NetPacket> history;
	private List<HistoryListener> listeners;
	
	public PacketHistory() {
		this.history = new ArrayList<NetPacket>();
		this.listeners = new ArrayList<HistoryListener>();
	}
	
	public void clearNetPacket(int i) {
		NetPacket packet = readNetPacket(i);
		if (packet != null) {
			packet.clearMemory();
		}
	}
	
	public void addHistoryListener(HistoryListener h) {
		synchronized (listeners) {
			listeners.add(h);
		}
	}

	public void removeHistoryListener(HistoryListener h) {
		synchronized (listeners) {
			listeners.remove(h);
		}
	}
	
	public void writeNetPacket(NetPacket packet) {
		int i = packet.getIndex();
		synchronized (history) {
			history.ensureCapacity(i); // TODO: check malicious code
			int nullsToAdd = i + 1 - history.size();
			while (nullsToAdd-- > 0) {
				history.add(null);
			}
			history.set(i, packet); // TODO: check malicious code
			history.notify();
		}
		fireListeners(packet);
	}
	
	public int size() {
		return history.size();
	}
	
	public NetPacket readNetPacket(int i) {
		synchronized (history) {
			if (i >= history.size()) {
				return null;
			}
			return history.get(i);
		}
	}
	
	private void fireListeners(NetPacket packet) {
		synchronized (listeners) {
			for (HistoryListener l : listeners) {
				l.historyItemSet(packet);
			}
		}
	}
}
