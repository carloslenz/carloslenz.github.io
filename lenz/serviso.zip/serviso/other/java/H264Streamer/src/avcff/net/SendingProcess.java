//
//  SendingProcess.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 23/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

public abstract class SendingProcess implements Runnable {
	protected Destination destination;
	protected Networked net;

	public SendingProcess(Networked net, Destination dest) {
		this.net = net;
		this.destination = dest;
	}

	public abstract boolean isComplete();
	public abstract SendingProcess nextTask();

	public Destination getDestination() {
		return destination;
	}

}
