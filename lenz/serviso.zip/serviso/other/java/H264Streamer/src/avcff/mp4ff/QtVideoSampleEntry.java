/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

/**
 *
 * @author cel
 */
class QtVideoSampleEntry extends QtBox {
    private int dataReferenceIndex;
    private int width;
    private int height;
    private int depth;
    private int frameCount;
    private long vertresolution;
    private long horizresolution;

    QtVideoSampleEntry(long size, int dataReferenceIndex, int width,
					   int height, long horizresolution, long vertresolution,
					   int frameCount, int depth) {
        super(size, "vide", null);
        this.dataReferenceIndex = dataReferenceIndex;
        this.width = width;
        this.height = height;
        this.horizresolution = horizresolution;
        this.vertresolution = vertresolution;
        this.frameCount = frameCount;
        this.depth = depth;
    }
    
    @Override
    public void printInfo(String prefix) {
        System.out.println(prefix + getSize() + "/" + getName());
        //...
    }

    @Override
    public void writeTo(OutputStream os) throws IOException {
        os.write(wordToBytes(getSize()));
        os.write(getName().getBytes());
        //...
    }
}
