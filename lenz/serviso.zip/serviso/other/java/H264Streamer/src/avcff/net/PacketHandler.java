//
//  PacketHandler.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 11/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;


public interface PacketHandler {
	void incommingPacket(AbstractPacket packet);
}
