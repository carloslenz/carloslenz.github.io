//
//  ServerMBean.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 26/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

public interface ServerMBean {
	void startTransmission();
}
