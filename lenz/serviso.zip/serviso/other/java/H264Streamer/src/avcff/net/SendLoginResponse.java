//
//  SendDirectly.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 19/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net; 

public class SendLoginResponse extends SendingProcess {
	private int currentIndex;
	
	public SendLoginResponse(Networked net, Destination dest) {
		super (net, dest);
		this.currentIndex = 0;
	}
	
	public void run() {
		net.scheduleLoginResponseDelivery(currentIndex++, destination);
	}
	
	public boolean isComplete() {
		return currentIndex >= net.getLoginResponseCount();
	}
	
	public SendingProcess nextTask() {
		return new SendDirectly(net, destination);
	}
}
