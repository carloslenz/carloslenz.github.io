//
//  NetPacket.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 02/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import main.ExitExecutionException;
import main.Messages;
import avcff.common.PacketImportances;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;

public class NetPacket extends AbstractPacket {
	
	static private int lastIndex = 0;
	
	private int index;
	private double decodeTime;
	private float importance;
	private long offset;
	private long packetNum;
	private long packetCount;
	private byte[] data;
	
	public NetPacket(double decodeTime, PacketImportances importance,
					 long packetNum, long packetCount, long offset,
					 byte[] data) {
		this (newIndex(), decodeTime, importance.getImportance(), packetNum,
			  packetCount, offset, data);
	}
	
	public NetPacket(int index, double decodeTime,
					 float importance, long packetNum,
					 long packetCount, long offset, byte[] data) {
		this.index = index;
		this.decodeTime = decodeTime;
		this.importance = importance;
		this.packetNum = packetNum;
		this.packetCount = packetCount;
		this.offset = offset;
		this.data = data;
	}
	
	public PacketTypes getType() {
		return PacketTypes.NET_PACKET;
	}

	public int getIndex() {
		return index;
	}
	
	public double getDecodeTime() {
		return decodeTime;
	}	
	
	public float getImportance() {
		return importance;
	}
	
	public long getOffset() {
		return offset;
	}
	
	public long getPacketNum() {
		return packetNum;
	}

	public long getPacketCount() {
		return packetCount;
	}
	
	public int getSize() {
		return data.length;
	}

	public byte[] getData() {
		return data;
	}
	
	public void clearMemory() {
		data = null; // TODO: check if it is used again
	}
	
	public void writeToStream(ObjectOutputStream oos) throws IOException {
		oos.writeInt(index);
		oos.writeDouble(decodeTime);
		oos.writeFloat(importance);
		oos.writeLong(offset);
		oos.writeLong(packetNum);
		oos.writeLong(packetCount);
		oos.writeInt(data.length);
		oos.write(data);
	}
	
	static public NetPacket readFromStream(ObjectInputStream ois)
	throws IOException {
		int index = ois.readInt();
		double decodeTime = ois.readDouble();
		float importance = ois.readFloat();
		long offset = ois.readLong();
		long packetNum = ois.readLong();
		long packetCount = ois.readLong();
		int len = ois.readInt();
		if (len != ois.available()) {
			ExitExecutionException.interrupt(Messages.DGRAM_NOT_COMPLETE_MSG);
		}
		byte[] data = new byte[len];
		ois.read(data);
		return new NetPacket(index, decodeTime, importance, offset, packetNum,
							 packetCount, data);
	}
	
	static private int newIndex() {
		return ++lastIndex;
	}
}
