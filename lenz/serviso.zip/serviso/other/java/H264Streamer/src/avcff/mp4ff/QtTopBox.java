//
//  QtTopBox.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 02/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.mp4ff;

import avcff.packetizer.BoxPacketizer;
import avcff.packetizer.Packetizer;
import java.util.List;

public class QtTopBox extends QtBox {
	private long offset;
	private int itemNum;
	
	public QtTopBox(long size, long offset, String name, List<QtData> items) {
        super(size, name, items);
		this.offset = offset;
	}
	
	public long getOffset() {
		return offset;
	}
	
	public Packetizer getPacketizer() {
		return new BoxPacketizer(this);
	}
}
