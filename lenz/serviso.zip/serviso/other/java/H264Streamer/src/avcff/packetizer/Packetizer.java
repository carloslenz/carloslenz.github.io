//
//  Packetizer.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 02/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.packetizer;

import avcff.net.NetPacket;
import java.util.Iterator;

abstract public class Packetizer implements Iterator<NetPacket> {
	static protected int MTU_Max = 1400;
	
	public void remove() {
		throw new UnsupportedOperationException();
	}
	
	protected long getPacketCountForSize(long size) {
		long count = size / MTU_Max;
		if ((size % MTU_Max) != 0) {
			count ++;
		}
		return count;
	}
}
