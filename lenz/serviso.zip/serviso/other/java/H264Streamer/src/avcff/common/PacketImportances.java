//
//  PacketImportances.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 14/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.common;

enum ImportanceLevels {
	TOP((byte) 10),
	HIGHEST((byte) 8),
	HIGH((byte) 6),
	MEDIUM((byte) 4),
	LOW((byte) 2),
	LOWEST((byte) 1),
	NONE((byte) 0),
	NEGATIVE((byte) -1);

	private byte level;

	ImportanceLevels(byte level) {
		this.level = level;
	}

	public byte getLevel() {
		return level;
	}
}

public enum PacketImportances {
	// NALU Type
	NON_IDR_SLICE(ImportanceLevels.NEGATIVE),
	IDR_SLICE(ImportanceLevels.NEGATIVE),
	
	PARTITION_A(ImportanceLevels.MEDIUM),
	PARTITION_B(ImportanceLevels.LOW),
	PARTITION_C(ImportanceLevels.LOWEST),
	
	SUPPLEMENTAL_ENHANCEMENT_INFORMATION(ImportanceLevels.HIGHEST),
	SEQUENCE_PARAMETER_SET(ImportanceLevels.HIGHEST),
	SEQUENCE_PARAMETER_SET_EXTENSION(ImportanceLevels.HIGHEST),
	PICTURE_PARAMETER_SET(ImportanceLevels.HIGHEST),
	
	ACCESS_UNIT_DELIMITER(ImportanceLevels.NONE), // or MEDIUM ?
	END_OF_SEQUENCE(ImportanceLevels.NONE), // or MEDIUM ?
	END_OF_STREAM(ImportanceLevels.NONE), // or MEDIUM ?

	FILLER_DATA(ImportanceLevels.NONE),

	// SLICE Type
	P_SLICE(ImportanceLevels.LOW),
	P_PLUS_SLICE(ImportanceLevels.LOW),
	SP_SLICE(ImportanceLevels.LOW),
	SP_PLUS_SLICE(ImportanceLevels.LOW),

	B_SLICE(ImportanceLevels.LOWEST),
	B_PLUS_SLICE(ImportanceLevels.LOWEST),

	I_SLICE(ImportanceLevels.MEDIUM),
	I_PLUS_SLICE(ImportanceLevels.MEDIUM),
	SI_SLICE(ImportanceLevels.MEDIUM),
	SI_PLUS_SLICE(ImportanceLevels.MEDIUM),

	// Other
	ACCESS_UNIT_SIZE_UNUSED(ImportanceLevels.NONE),
	SOUND(ImportanceLevels.HIGH),
	OTHER(ImportanceLevels.LOWEST), // or NONE ?

	HEADER(ImportanceLevels.TOP);
	
	private byte importance;
	
	public byte getImportance() {
		return importance;
	}
	
	PacketImportances(byte importance) {
		this.importance = importance;
	}

	PacketImportances(ImportanceLevels value) {
		this (value.getLevel());
	}
	
	static public boolean shouldKeep(byte importance) {
		// packet is too important and should be cached
		return (importance >= 20) ||
		// packet is not so important, only kept by chance
			(Math.random() > (importance / 20.0));
	}
}
