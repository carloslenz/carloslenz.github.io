//
//  StreammingServer.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 19/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

public class Streaming implements ControlProtocol {
	public void incommingControlPacketForServer(ControlPacket control,
												Server server) {
		server.addKnownNode(control.getDestination());
	}
	
	public void incommingControlPacketForClient(ControlPacket control,
												Client	client) {
		client.addKnownNode(control.getDestination());
	}
	
	public void incommingLoginRequestForServer(LoginRequestPacket control,
											   Server server) {
		server.startLoginForDestination(control.getDestination());
	}
	
	public void incommingLoginRequestForClient(LoginRequestPacket control,
											   Client client) {
		// TODO: log unexpected
	}
	
	public void serverCompleteLoginForDestination(Destination dest,
												  Server server) {
		server.addRoute(dest);
	}

	public void clientCompleteLoginForDestination(Destination dest,
												  Client client) {
		// TODO: log error
	}
	
	public Destination destinationForRecovery(int i, Client client) {
		return client.getServer();
	}
}
