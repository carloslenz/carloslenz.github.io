//
//  ControlProtocolType.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 19/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.common;

import avcff.net.ControlProtocol;
import avcff.net.Streaming;

public enum ControlProtocolType {
	STREAMING {
		public ControlProtocol newProtocolInstance() {
			return new Streaming();
		}
	};

	abstract public ControlProtocol newProtocolInstance();
}
