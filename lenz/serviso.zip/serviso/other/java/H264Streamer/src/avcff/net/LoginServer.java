//
//  LoginServer.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 22/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import java.util.LinkedList;
import java.util.Iterator;
import java.util.List;

public class LoginServer implements Runnable {
	private Networked net;
	private List<SendingProcess> senders;
	
	public LoginServer(Networked net) {
		this.net = net;
		this.senders = new LinkedList<SendingProcess>();
	}
	
	public void run() {
		synchronized (senders) {
			Iterator<SendingProcess> it = senders.iterator();
			while (it.hasNext()) {
				SendingProcess sender = it.next();
				sender.run();
				if (sender.isComplete()) {
					it.remove();
					sender = sender.nextTask();
					if (sender == null) {
						Destination dest = sender.getDestination();
						net.completeLoginForDestination(dest);
					} else {
						senders.add(sender);
					}
				}
			}
		}
	}
	
	public void addDestination(Destination dest) {
		synchronized (senders) {
			senders.add(new SendLoginResponse(net, dest));
		}
	}
}
