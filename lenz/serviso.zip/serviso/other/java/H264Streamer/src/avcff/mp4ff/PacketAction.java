//
//  PacketAction.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 27/02/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.mp4ff;

import java.io.IOException;

public interface PacketAction {
	void run(QtPacket packet) throws IOException;
}
