//
//  PacketTypes.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 23/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import main.ExitExecutionException;
import main.Messages;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.util.EnumSet;

public enum PacketTypes {
	NET_PACKET(1),
	CONTROL(2),
	LOGIN_REQUEST(3),
	RECOVERY_REQUEST(4),
	LOGIN_RESPONSE(5);

	private int code;

	PacketTypes(int code) {
		this.code = code;
	}

	public byte toByte() {
		return (byte)code;
	}

	static public PacketTypes fromByte(byte b) {
		for (PacketTypes type : EnumSet.allOf(PacketTypes.class)) {
			if (type.toByte() == b) {
				return type;
			}
		}
		return null;
	}
}
