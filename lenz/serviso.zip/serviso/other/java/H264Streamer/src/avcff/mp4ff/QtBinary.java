/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

import java.io.IOException;
import java.io.OutputStream;

/**
 *
 * @author cel
 */
public class QtBinary extends QtData {
    private byte[] data;

    public QtBinary(byte[] data) {
        this(data.length, data);
    }

    QtBinary(long size, byte[] data) {
        super(size);
        this.data = data;
    }
	
	public long getRange(long rangeStart, byte[] dest, long destOffset) {
		long missing = data.length - destOffset;
		long remaining = getSize() - rangeStart;
		long len = Math.min(missing, remaining);
		System.arraycopy(data, (int)rangeStart, dest, (int)destOffset,
						 (int)len);
		return len;
	}
    
    public byte getByte(int pos) {
        return data[pos];
    }
    
    public int getUInt16(int pos) {
        byte[] b = new byte[2];
        for(int i = 0; i < b.length; ++i)
            b[i] = data[pos + i];
        return bytesToShort(b);
    }

    public long getUInt32(int pos) {
        byte[] b = new byte[4];
        for(int i = 0; i < b.length; ++i)
            b[i] = data[pos + i];
        return bytesToWord(b);
    }
    
    public byte[] getWord(int pos) {
        byte[] b = new byte[4];
        for(int i = 0; i < b.length; ++i)
            b[i] = data[pos + i];
        return b;
    }

    @Override
    void printInfo(String prefix) {
        System.out.println(prefix + getSize() + "/binary");
    }

    @Override
    public void writeTo(OutputStream os) throws IOException {
        os.write(data);
    }

}
