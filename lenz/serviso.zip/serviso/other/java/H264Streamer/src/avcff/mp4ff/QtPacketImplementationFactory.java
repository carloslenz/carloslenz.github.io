/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

import main.Messages;
import main.ExitExecutionException;
import avcff.avc.AccessUnit;

/**
 *
 * @author cel
 */
class QtPacketImplementationFactory {
    
    static QtPacketImplementationFactory factory =
		new QtPacketImplementationFactory();
    private QtMdatChunk accessUnit;
    private QtMdatChunk genericPacket;
    private QtMdatChunk missingPacket;
    
    QtPacketImplementationFactory() {
        this.accessUnit = new AccessUnit();
        this.genericPacket = new QtGenericPacket("Sample");
        this.missingPacket = new QtGenericPacket("Missing");
    }

    static QtMdatChunk getImplementation(QtPacket.QtPacketType isVideo) {
        switch (isVideo) {
        case Video:
            return factory.accessUnit;
        case Other:
            return factory.genericPacket;
        case Missing:
            return factory.missingPacket;
        default:
            ExitExecutionException.interrupt(Messages.UNKNOWN_VIDEO_TYPE);
			return null;
        }
    }
}
