//
//  RecoveryRequestPacket.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 23/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;



public class RecoveryRequestPacket extends ControlPacket {
	private int index;
	
	public RecoveryRequestPacket(Destination dest, int index) {
		super (dest);
		this.index = index;
	}
	
	public PacketTypes getType() {
		return PacketTypes.RECOVERY_REQUEST;
	}
	
	public int getIndex() {
		return index;
	}
	
	public void writeToStream(ObjectOutputStream oos) throws IOException {
		super.writeToStream(oos);
		oos.writeInt(index);
	}
	
	static public RecoveryRequestPacket readFromStream(ObjectInputStream ois)
	throws IOException {
		ControlPacket packet = ControlPacket.readFromStream(ois);
		Destination dest = packet.getDestination();
		int index = ois.readInt();
		return new RecoveryRequestPacket(dest, index);
	}
	
}
