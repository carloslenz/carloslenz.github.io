//
//  BoxPacketizer.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 02/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.packetizer;

import avcff.common.PacketImportances;
import avcff.mp4ff.QtTopBox;
import avcff.net.NetPacket;
import java.util.NoSuchElementException;

public class BoxPacketizer extends Packetizer {
	private QtTopBox target;
	private int offset;
	private long packetNum;
	private long packetCount;

	public BoxPacketizer(QtTopBox target) {
		this.target = target;
		this.offset = 0;
		this.packetNum = 0;
		this.packetCount = getPacketCountForSize(this.target.getSize());
	}
	
	public boolean hasNext() {
		return this.packetNum < this.packetCount;
	}
	
	public NetPacket next() {
		if (!hasNext()) {
			throw new NoSuchElementException();
		}
		byte[] data = this.target.getRange(this.offset, MTU_Max);
		NetPacket result = new NetPacket(0, PacketImportances.HEADER,
										 ++ this.packetNum, this.packetCount,
										 this.target.getOffset() + this.offset,
										 data);
		this.offset += data.length;
		return result;
	}
}
