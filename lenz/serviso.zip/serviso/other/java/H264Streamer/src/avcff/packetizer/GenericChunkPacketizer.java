//
//  GenericChunkPacketizer.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 03/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.packetizer;

import avcff.common.PacketImportances;
import avcff.mp4ff.QtGenericPacket;
import avcff.mp4ff.QtPacket;
import avcff.mp4ff.QtMdatPacketCache;
import avcff.net.NetPacket;
import java.util.NoSuchElementException;

public class GenericChunkPacketizer extends Packetizer {
	private QtPacket target;
	private QtMdatPacketCache cache;
	private long packetNum;
	private long packetCount;
	private long offset;
	
	public GenericChunkPacketizer(QtGenericPacket gp, QtPacket target,
								  QtMdatPacketCache cache) {
		this.target = target;
		this.cache = cache;
		this.offset = target.getStart();
		this.packetNum = 0;
		this.packetCount = getPacketCountForSize(this.target.size());
	}
	
	public boolean hasNext() {
		return this.packetNum < this.packetCount;
	}
	
	public NetPacket next() {
		long len = Math.min(MTU_Max, this.target.getStop() - this.offset);
		if (len < 1) {
			throw new NoSuchElementException();
		}
		long until = this.offset + len;
		byte[] data = this.cache.fetch(this.offset, until);
		// I'm assuming that there are no other packets types
		// other than video and sound:
		NetPacket result = new NetPacket(this.target.getDecodeTime(),
										 PacketImportances.SOUND,
										 ++ this.packetNum, this.packetCount,
										 this.offset, data);
		this.offset += data.length;
		return result;
	}
}
