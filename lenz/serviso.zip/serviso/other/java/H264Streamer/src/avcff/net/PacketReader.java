//
//  PacketReader.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 13/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

import main.EventRecorder;
import main.ExitExecutionException;
import main.Messages;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class PacketReader implements Runnable, HistoryListener {
	private boolean receivingMdat;
	private Client client;
	private OutputStream os;
	private Runnable target;
	private int index;
	private Map<Integer, NetPacket> packets;
	
	private final Runnable outputData = new Runnable() {
		long startTime = 0;
		final double WINDOW_START = 1; // request packets 1sec ahead
		final double WINDOW_STOP = 5; // until 5sec ahead
		public void run() {
			LinkedList<Integer> toOutput = new LinkedList<Integer>();
			LinkedList<Integer> window = new LinkedList<Integer>();
			double limit = elapsedTime();
			int i = index;
			PacketInfo pInfo = null;
			do {
				pInfo = client.getPacketInfo(i++);
				if (pInfo == null) {
					videoHasEnded();
				}
				toOutput.addLast(pInfo.getSize());
			} while (pInfo.getDecodeTime() < limit);
			toOutput.removeLast();
			i--;
			limit += WINDOW_START;
			do {
				pInfo = client.getPacketInfo(i++);
				if (pInfo == null) {
					break;
				}
			} while (pInfo.getDecodeTime() < limit);
			i--;
			limit += WINDOW_STOP;
			do {
				pInfo = client.getPacketInfo(i);
				if (pInfo == null) {
					window.addLast(1); // dummy data that will be removed
					break;
				}
				window.addLast(i++);
			} while (pInfo.getDecodeTime() < limit);
			window.removeLast();
			List<Integer> toRequestRecovery = new ArrayList<Integer>();
			synchronized (packets) {
				for (Integer size : toOutput) {
					NetPacket packet = packets.get(index++);
					byte[] data = null;
					if (packet == null) {
						data = new byte[size];
					} else {
						data = packet.getData();
					}
					writeToStream(data);
				}
				for (Integer idx : window) {
					if (!packets.containsKey(idx)) {
						client.requestPacketRecoveryFor(idx);
					}
				}
			}
		}
		double elapsedTime() {
			long now = System.currentTimeMillis();
			if (startTime == 0) {
				startTime = now;
				return 1.0; // output the 1st sec immediately
			}
			return (now - startTime) / 1000.0;
		}
	};	
	
	private final Runnable waitingMdat = new Runnable() {
		final int MININUM_COUNT = 200; // to have a few packets to output
		public void run() {
			if (!receivingMdat && (packetCount() > MININUM_COUNT)) {
				setTarget(outputData);
			}
		}
	};				

	final Runnable waitingHeader = new Runnable() {
		public void run() {
			int headerSize = client.getHeaderSize();
			if (headerSize > 0 || packetCount() < headerSize) {
				return;
			}
			synchronized (packets) {
				for (int i = 0; i < headerSize; ++i) {
					NetPacket packet = packets.get(i);
					if (packet == null) {
						return;
					}
				}
			}
			// header is complete
			os = client.getOutputStream();
			synchronized (packets) {
				for (int i = 0; i < headerSize; ++i) {
					NetPacket packet = packets.get(i);
					writePacketToStream(packet);
				}
			}
			index = headerSize;
			setTarget(waitingMdat);
		}
	};

	public PacketReader(final Client client) {
		this.target = waitingHeader;
		this.receivingMdat = false;
		this.index = 0;
		this.client = client;
		this.packets = new HashMap<Integer, NetPacket>();
	}
	
	public void run() {
		target.run();
	}
	
	public void historyItemSet(NetPacket packet) {
		int idx = packet.getIndex();
		if (idx >= index) {
			synchronized (packets) {
				packets.put(idx, packet);
			}
		}
	}
	
	public void setReceivingMdat() {
		receivingMdat = true;
	}
	
	private int packetCount() {
		synchronized (packets) {
			return packets.size();
		}
	}
	
	private void setTarget(Runnable r) {
		this.target = r;
	}
	
	private void writePacketToStream(NetPacket packet) {
		writeToStream(packet.getData());
		packets.remove(packet.getIndex());
	}

	private void writeToStream(byte[] data) {
		try {
			os.write(data);
		}
		catch (IOException ex) {
			ExitExecutionException.interrupt(ex, Messages.WRITE_ERROR);
		}
	}
	
	private void videoHasEnded() {
		EventRecorder.add("COMPLETE_VIDEO");
//		os.close();
		System.exit(0);
	}
}
