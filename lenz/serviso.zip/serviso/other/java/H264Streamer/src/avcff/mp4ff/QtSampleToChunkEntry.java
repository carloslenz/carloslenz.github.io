/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avcff.mp4ff;

/**
 *
 * @author cel
 */
public class QtSampleToChunkEntry {
    private long firstChunk;
    private long samplesPerChunk;
    private long sampleDescriptionIndex;

    QtSampleToChunkEntry(long firstChunk, long samplesPerChunk,
						 long sampleDescriptionIndex) {
        this.firstChunk = firstChunk;
        this.samplesPerChunk = samplesPerChunk;
        this.sampleDescriptionIndex = sampleDescriptionIndex;
    }

    public long getFirstChunk() {
        return firstChunk;
    }

    public long getSampleDescriptionIndex() {
        return sampleDescriptionIndex;
    }

    public long getSamplesPerChunk() {
        return samplesPerChunk;
    }

}
