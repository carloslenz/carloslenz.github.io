//
//  PacketReceiver.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 13/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net;

public class PacketReceiver implements Runnable {
	private Node myself;
	private PacketHandler handler;
	
	public PacketReceiver(Node myself, PacketHandler handler) {
		this.myself = myself;
		this.handler = handler;
	}
	
	public void run() {
		myself.receiveTo(handler);
	}	
}
