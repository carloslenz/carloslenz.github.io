//
//  MdatPacketizer.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 02/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.packetizer;

import avcff.mp4ff.QtMdat;
import avcff.net.NetPacket;

public class MdatPacketizer extends Packetizer {
	private QtMdat target;
	private long mdatPacketNum;
	private Packetizer chunkPkt;
	
	public MdatPacketizer(QtMdat target) {
		this.target = target;
		this.mdatPacketNum = 0;
	}

	public boolean hasNext() {
		if (chunkPkt.hasNext()) {
			return true;
		}
		return this.mdatPacketNum < this.target.getPackets().length;
	}
	
	public NetPacket next() {
		if (!this.chunkPkt.hasNext() &&
			this.mdatPacketNum < this.target.getPackets().length)
		{
			this.chunkPkt =
				this.target.getChunkPacketizer(++ this.mdatPacketNum);
		}
		return this.chunkPkt.next();
	}
}
