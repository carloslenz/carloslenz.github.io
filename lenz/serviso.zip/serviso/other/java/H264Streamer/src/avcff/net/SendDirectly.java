//
//  SendDirectly.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 19/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.net; 

public class SendDirectly extends SendingProcess {
	private int currentIndex;
	
	public SendDirectly(Networked net, Destination dest) {
		super (net, dest);
		this.currentIndex = 0;
	}
	
	public void run() {
		net.schedulePacketDelivery(currentIndex++, destination);
	}
	
	public boolean isComplete() {
		return currentIndex >= net.getHeaderSize();
	}
	
	public SendingProcess nextTask() {
		return null;
	}
}
