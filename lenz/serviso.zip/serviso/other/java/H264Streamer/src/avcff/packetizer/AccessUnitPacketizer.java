//
//  AccessUnitPacketizer.java
//  H264Streamer
//
//  Created by Carlos Eduardo Lenz on 03/01/09.
//  Copyright 2009 Carlos Eduardo Lenz. All rights reserved.
//
package avcff.packetizer;

import avcff.avc.AccessUnit;
import avcff.avc.AccessUnitItem;
import avcff.mp4ff.QtMdatPacketCache;
import avcff.mp4ff.QtPacket;
import avcff.net.NetPacket;
import java.util.NoSuchElementException;

public class AccessUnitPacketizer extends Packetizer {

	private QtPacket target;
	private QtMdatPacketCache cache;
	private AccessUnitItem[] nalus;
	private long packetNum;
	private long offset;
	
	public AccessUnitPacketizer(AccessUnit au, QtPacket target,
								QtMdatPacketCache cache) {
		this.target = target;
		this.cache = cache;
		this.nalus = au.getNALUs(this.target, cache);
		this.packetNum = 0;
		this.offset = this.target.getStart();
	}
	
	public boolean hasNext() {
		return this.packetNum + 1 < nalus.length;
	}
	
	public NetPacket next() {
		if (!hasNext()) {
			throw new NoSuchElementException();
		}
		// does not break NALUs!
		AccessUnitItem item = nalus[(int)++packetNum];
		byte[] data = item.getData();
		NetPacket result = new NetPacket(this.target.getDecodeTime(),
										 item.getImportance(), this.packetNum,
										 nalus.length, this.offset, data);
		this.offset += data.length;
		return result;
	}
}
