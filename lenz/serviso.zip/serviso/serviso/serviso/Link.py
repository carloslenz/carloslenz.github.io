# Carlos Eduardo Lenz - PPGCC - UFSC
from copy import copy
from datetime import datetime
from os import rename
from random import choice, sample, uniform
from socket import gethostbyname, gaierror
from sys import argv
from threading import Thread
from time import sleep, time
from traceback import format_exc

from Host import Host, HOSTNAME
from Logger import Logger
from ProcessGroup import DEFAULT_CPU_TM
from util import bind_socket, div_or_zero, mail_error, ANY_NIC

MAX_MSG = 3800
SEND_BUFFER = ''.join([chr(int(uniform(0, 255))) for q in range(0, 2 * MAX_MSG)])
REC_PORT = 37318
QUICK = 0.01
SMALL = 0.025
REPORT_FMT = '!BIdB'
REPLY_FMT = '!B'
MAX_RTT = 0.1
NONE_ST, NOK_ST, OK_ST = range(0, 3)
MIN_RUNS = 10
BAD_NETWORK_RATE = 0.8
BAD_NODE_RATE = 0.55
DEAF_MUTE_RTT = 100
TEST, QUICK, JUMBO, MACH = range(0, 4)
SUBSET_SIZE = 200

AT_STOP = []

class Hi:
	def __init__(self, name, port=REC_PORT, ip=None):
		if not ip:
			ip = gethostbyname(name)
		self.name = name
		self.address = (ip, port)
		self.rtt = DEAF_MUTE_RTT
		self.x = 0
		self.lost50 = 0
		self.last_queue = 0

class HostStatus:
	def __init__(self, max_rtt, s):
		apply(self.set_all, [max_rtt] + s.split(','))

	def set_all(self, max_rtt, hostname, rtt='0', lost50='0', rec_x='0', timestamp='', successes='0', failures='0'):
		self.hostname = hostname
		self.rtt = float(rtt)
		self.lost50 = int(float(lost50))
		self.rec_x = float(rec_x)
		self.timestamp = timestamp
		self.successes = int(successes)
		self.failures = int(failures)
		self.status = NONE_ST
		if self.rtt <= 0:
			self.last_status = NONE_ST
		elif self.rtt < max_rtt:
			self.last_status = OK_ST
		else:
			self.last_status = NOK_ST

	def try_it(self, max_rtt, tester, saving, n):
		ret = tester(self.hostname)
		if callable(saving):
			return saving(ret, n, self.hostname)
		else:
			apply(self.record, [max_rtt] + list(ret))
			return False

	def record(self, max_rtt, rtt, lost50, rec_x):
		self.rtt = rtt
		self.lost50 = lost50
		self.rec_x = rec_x
		self.timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		if rtt < max_rtt:
			self.successes = self.successes + 1
			Logger.info('OK', self.hostname, self.rtt, self.lost50, self.rec_x, 'HISTORY', self.successes, self.failures, self.last_status)
			self.last_status = self.status = OK_ST
		else:
			self.failures = self.failures + 1
			rtt = self.rtt
			if rtt == DEAF_MUTE_RTT:
				rtt = 'DEAF/MUTE'
			Logger.info('NOK', self.hostname, rtt, self.lost50, self.rec_x, 'HISTORY', self.successes, self.failures, self.last_status)
			self.last_status = self.status = NOK_ST
		return self.status

	def is_ok(self):
		return self.current_status() == OK_ST

	def prev_ok(self):
		return self.status == NONE_ST and self.last_status == OK_ST

	def prev_nok(self):
		return self.status == NONE_ST and self.last_status in (NONE_ST, NOK_ST)

	def current_status(self):
		if self.status != NONE_ST:
			return self.status
		return self.last_status

	def is_bad(self):
		return self.current_status() == NOK_ST

	def report(self):
		return '%s,%f,%d,%f,%s,%d,%d' % (self.hostname, self.rtt, self.lost50, self.rec_x, self.timestamp, self.successes, self.failures)

class AllNodes:
	def __init__(self, fname, min_ok, min_rate, max_tries, min_quick_ok, max_rtt, hostname=HOSTNAME):
		self.fname = fname
		self.min_ok = min_ok
		self.min_rate = min_rate
		self.max_tries = max_tries
		self.max_rtt = max_rtt
		self.min_quick_ok = min_quick_ok
		self.hostname = hostname
		self.load_them()

	def split_subsets(self):
		i, self.subsets = 0, []
		while i * SUBSET_SIZE < len(self.nodes):
			subset = AllNodes(self.fname, self.min_ok, self.min_rate, self.max_tries, self.min_quick_ok, self.max_rtt, self.hostname)
			subset.me = self.me
			subset.nodes = self.nodes[i * SUBSET_SIZE : (i+1) * SUBSET_SIZE]
			self.subsets.append(subset)
			i = i + 1

	def load_them(self):
		try:
			self.nodes = [HostStatus(self.max_rtt, s.strip()) for s in open(self.fname).readlines()]
		except IOError:
			Logger.panic('IOError', self.fname)
			self.nodes = []
		self.me = None
		l = [x for x in self.nodes if x.hostname == self.hostname]
		if l:
			self.me = l[0]
			self.nodes = [x for x in self.nodes if x != self.me]
		self.changed = False
		self.subsets = [self]

	def remove(self, hostname):
		if hostname == self.hostname:
			return None
		before = len(self.nodes)
		if before:
			self.nodes = [x for x in self.nodes if x.hostname != hostname]
			assert len(self.nodes) in (before - 1, before)
		return self

	def update(self, hi):
		hs = [x for x in self.nodes if x.hostname == hi.name][0]
		hs.record(self.max_rtt, hi.rtt, hi.lost50, hi.x)

	def include(self, l):
		for s in l:
			if s[0] == '-':
				self.nodes = self.filter_them(lambda x: x.hostname != s[1:])
			else:
				h = HostStatus(self.max_rtt, s)
				l = self.filter_them(lambda x: x.hostname == h.hostname)
				if not l:
					self.nodes.append(h)

	def save_them(self):
		tmpname = '%s.tmp' % self.fname
		f = open(tmpname, 'w')
		if self.me:
			f.write('%s\n' % self.me.report())
		f.writelines(['%s\n' % entry.report() for entry in self.nodes])
		f.close()
		rename(tmpname, self.fname)
		self.changed = False

	def filter_them(self, f):
		return [entry for entry in self.nodes if f(entry)]

	def network_ok(self, dolog=True):
		count = len(self.filter_them(lambda x: x.is_ok()))
		n = len(self.nodes)
		if dolog:
			Logger.high('count OK', count, 'NOK', len(self.bad_nodes()), 'DEAF/MUTE', len(self.deaf_mutes()), 'ALL', n)
		return n >= self.min_ok and div_or_zero(count, n) >= self.min_rate

	def bad_network_rate(self):
		return div_or_zero(len(self.bad_nodes()), len(self.nodes))

	def bad_network(self):
		return self.bad_network_rate() >= BAD_NETWORK_RATE

	def bad_nodes(self):
		return self.filter_them(lambda x: x.is_bad())

	def good_nodes(self):
		return self.filter_them(lambda x: x.current_status() == OK_ST)

	def deaf_mutes(self):
		return self.filter_them(lambda x: x.rtt == DEAF_MUTE_RTT)

	def quicktest_nodes(self):
		seq = self.good_nodes()
		missing = self.max_tries - len(seq)
		if missing > 0:
			l = self.filter_them(lambda x: x not in seq)
			seq = seq.union(sample(l, missing))
		return seq

	def try_one(self, tester, selector, i, saving, l):
		entry = selector(i, l)
		if not callable(saving):
			self.changed = True
		return entry.try_it(self.max_rtt, tester, saving, i)

	def try_them(self, interval, tester, selector, saving, l):
		assert self.nodes
		if self.try_one(tester, selector, 0, saving, l):
			return True
		for i in xrange(1, self.max_tries):
			sleep(interval)
			if self.try_one(tester, selector, i, saving, l):
				return True
		return False

	def quick_try(self, tester, interval):
		ret = False
		self.nr_oks = 0
		def check(l, n, hostname):
			ok = l[0] < self.max_rtt
			rtt = l[0]
			if rtt == DEAF_MUTE_RTT:
				rtt = 'DEAF/MUTE'
			Logger.info('OK?', ok, hostname, rtt, l[1], l[2])
			if ok:
				self.nr_oks = self.nr_oks + 1
			return self.nr_oks >= self.min_quick_ok or self.max_tries - n - 1 + self.nr_oks < self.min_quick_ok
		if self.network_ok():
			self.try_them(interval, tester, lambda i,l: choice(l), check, self.quicktest_nodes())
			ret = self.nr_oks >= self.min_quick_ok
		Logger.high('QUICK result', ret)
		return ret

	def keep_trying(self, tester, interval):
		try:
			self.try_them(interval, tester, choose_least_tested_maker(), None, self.nodes)
		finally:
			if self.changed:
				self.save_them()
		return self.network_ok()

def choose_least_tested_maker():
	tested = set([])
	def choose_least_tested(i, l):
		h = l[1]
		q, group = h.successes + h.failures, [h]
		for h in l:
			n = h.successes + h.failures
			if h not in tested:
				if n < q:
					q, group = n, [h]
				elif n == q:
					group.append(h)
		h = choice(group)
		tested.add(h)
		return h
	return choose_least_tested

def append_config(args):
	srcname, dstname = args
	dstnodes = AllNodes(dstname, 0, 0, 0, 0, 0)
	srcnodes = [ln.strip() for ln in open(srcname).readlines()]
	dstnodes.include(srcnodes)
	dstnodes.save_them()

def start_myself(max_throughput):
	myself = Host([ANY_NIC, int(uniform(6000, 12000))], max_throughput)
	def get_msgs():
		while myself.max_throughput:
			myself(DEFAULT_CPU_TM, SMALL)
	myself.bind(True)
	AT_STOP.append(lambda : myself.stop())
	Thread(target=get_msgs).start()
	return myself

def extract_extra(extra):
	max_throughput, interval = 2000000 / 8, 2 # 2 mbps
	if extra:
		interval = float(extra.pop(0))
		if extra:
			max_throughput = int(extra.pop(0))
	return max_throughput, interval

def log_params(max_throughput, interval, *extra):
	apply(Logger.high, ['HOST', HOSTNAME, 'MAX_X', max_throughput, 'INTERVAL', interval] + list(extra))

def jumbo_test(all_nodes, myself, logger, interval, save=True):
	prio = 0
	missing = set([])
	for subset in all_nodes.subsets:
		for hs in subset.nodes:
			try:
				missing.add(Hi(hs.hostname))
			except gaierror:
				pass
		for i in range (0, 25): # 3.8 kB/msg * 25 msgs * 240 hosts = 2.85 Mbit
			prio = prio + 1
			for hi in missing:
				myself.send(hi, test_msg(prio), prio)
				sleep(0.03) # 180s for 240 hosts: 7s between msgs
		Logger.high('OTHER', len(missing), ' '.join([hi.name for hi in missing]))
		while missing:
			all = copy(missing)
			for hi in all:
				dest = myself.destination(hi.address)
				if not sum(dest.queue_size()):
					missing.remove(hi)
					hi.rtt, hi.x, hi.lost50 = dest.throughput, dest.total_loss(), DEAF_MUTE_RTT
					if dest.round_trip_time:
						hi.rtt = dest.round_trip_time
					subset.update(hi)
			if all != missing:
				Logger.info(len(missing))
			if missing:
				sleep(0.2)
		if save:
			all_nodes.save_them()
	if not save:
		return len(all_nodes.good_nodes()) >= all_nodes.min_quick_ok
	return all_nodes.network_ok()

def test_link(all_nodes, extra, logger, mode):
	Logger.high('CLIENT')
	max_throughput, interval = extract_extra(extra)
	myself = start_myself(max_throughput)
	if mode == JUMBO:
		ret = jumbo_test(all_nodes, myself, logger, interval)
	elif mode == MACH:
		l = all_nodes.good_nodes()
		all_nodes.nodes = sample(l, min(all_nodes.max_tries, len(l)))
		ret = jumbo_test(all_nodes, myself, logger, interval, False)
	else:
		def tester(hostname):
			try:
				prio, hi, stop = 0, Hi(hostname), max_throughput / MAX_MSG / 3
				for i in range (0, 6):
					for j in range(0, stop):
						prio = prio + 1
						myself.send(hi, test_msg(prio), prio)
					test_stats(myself, hi, prio, False, logger)
				return test_stats(myself, hi, '?', True, logger)
			except gaierror:
				return DEAF_MUTE_RTT, 50, 0
		fun = all_nodes.keep_trying
		if mode == QUICK:
			fun = all_nodes.quick_try
		ret = fun(tester, interval)
	if all_nodes.bad_network():
		apply(Logger.info, ['BAD NETWORK', HOSTNAME, 'NODES'] + [x.hostname for x in all_nodes.bad_nodes()])
	return ret

def test_stats(myself, hi, i, last, logger):
	def dest_stats():
		dest = myself.destination(hi.address)
		q = dest.queue_size()
		return [hi.name, 'i', i, 'x', int(dest.throughput), int(dest.throughput_inst()), int(dest.session_throughput()), int(dest.recent_throughput()), 'ps', dest.packet_size_stat(), 'rtt', dest.round_trip_time, 'loss', dest.loss_rate, 'bc', dest.byte_count_stat, 'lost50', dest.total_loss(), 'q', q[0], q[1]]
	def save_stats(l):
		hi.last_queue = sum(l[-2:])
		x, rtt, lost50 = l[7], l[11], l[17]
		if rtt:
			hi.rtt = rtt
		hi.x = x
		hi.lost50 = max(lost50, hi.lost50)
		apply(logger, l)
	l = dest_stats()
	save_stats(l)
	qlast = hi.last_queue
	# save stats
	while last and hi.last_queue:
		while hi.last_queue == qlast:
			sleep(QUICK * 10)
			l = dest_stats()
			qlast = sum(l[-2:])
		save_stats(l)
	return hi.rtt, hi.lost50, hi.x

def test_msg(i):
	first = int(uniform(0, MAX_MSG))
	return chr(i) + SEND_BUFFER[first : first + MAX_MSG]

def process_net(port, args, fun_each, logger):
	start = time()
	period = 15 * 60 # 15 min
	if args:
		period = int(args.pop(0))
	max_throughput, interval = extract_extra(args)
	stop = start + period
	expiration = 10
	myself = Host((ANY_NIC, port), max_throughput)
	bind_socket(myself, port, canChangePort=True)
	log_params(max_throughput, interval, 'PERIOD', period)
	nodes = set([])
	while time() < stop:
		for msg, addr in myself(DEFAULT_CPU_TM, SMALL):
			myself.destination(addr).tick = time()
			key = str(addr)
			if key not in nodes:
				logger(key, '+node', port)
				nodes.add(key)
			fun_each(myself, msg, addr)
		limit = time() - expiration
		for dest in myself.destinations.values():
			if dest.tick <= limit: # expired node
				rtt = 0 # dest.receiver_guess_rtt()
				if rtt and rtt < self.max_rtt:
					Logger.info('GOT', dest.address, 'TO', HOSTNAME, 'LAST (guess) rtt', rtt, 'lost50', dest.lost50)
				logger(dest.address, '-expired', port)
				myself.remove_messages_for(dest.address)
				nodes.remove(str(dest.address))

def rec(args, logger=Logger.dyn):
	Logger.high('REC')
	process_net(REC_PORT, args, lambda *l: None, logger)

def is_bad_node(fname):
	for s in open(fname).readlines():
		if s[0] == '-':
			if s[1:].split()[0] == HOSTNAME:
				Logger.info('Bad Node')
				return True
	Logger.info('Good Node')
	return False

def auto_link(args, logger):
	mode = TEST
	if args[0] == 'quick':
		mode, badnodesfname, args = QUICK, args[1], args[2:]
	elif args[0] == 'mach':
		mode, badnodesfname, args = MACH, args[1], args[2:]
	elif args[0] == 'jumbo':
		mode, args = JUMBO, args[1:]
	nodesfname, wait, period, minok, minrate, maxtries, minquickok, maxrtt = args[:8]
	all_nodes = AllNodes(nodesfname, int(minok), float(minrate), int(maxtries), int(minquickok), float(maxrtt))
	if mode == JUMBO:
		all_nodes.split_subsets()
	wait = int(wait)
	period = str(int(period) * len(all_nodes.subsets))
	extra = args[8:]
	max_throughput, interval = extract_extra(extra)
	opts = [period, interval, max_throughput]
	tRec = Thread(target=lambda : rec(copy(opts), logger))
	tRec.start()
	ret = False
	if mode in (TEST, JUMBO) or not is_bad_node(badnodesfname):
		sleep(wait)
		ret = test_link(all_nodes, opts[1:], logger, mode)
	if tRec.isAlive():
		tRec.join()
	return ret

def main(args):
	try:
		logger = Logger.dbg
		if args and args[0] == '-v':
			args, logger = args[1:], Logger.dyn
		if args:
			if args[0] == '-append':
				return append_config(args[1:])
			return auto_link(args, logger)
	finally:
		Logger.high('exiting...')
		for x in AT_STOP:
			x()

def usage(cmd=argv[0]):
	print 'usage: %s [-v] [quick|mach BAD-NODES-FILE | jumbo] NODES-FILE WAIT PERIOD MIN-OK MIN-RATE MAX-TRIES  MIN-QUICK-OK MAX-RTT [INTERVAL MAX_X]' % cmd
	print 'usage: %s -append SRC DEST' % cmd
