# Carlos Eduardo Lenz - PPGCC - UFSC
from copy import copy
from time import time

from Block import PARTS_PER_BLOCK
from Logger import Logger
from Message import join_data_msg, join_data_msg2, DATA_ID, QDATA_ID, MULTI_ID, METADATA_ID, NACK_ID
from ProcessGroup import SOFT_DELAY
from util import join_offsets

DEFAULT_TIMEOUT = 0.05
			
class Delivery:
	def __init__(self, network, buffer, isSmart, metadata_always):
		self.buffer = buffer
		self.network = network
		self.metadata_always = metadata_always
		self.when = time()
		self.nacks = []
		self.generator = None
		self.todo = []
		if isSmart:
			self.reply_nack = self.smart_reply_nack
			self.msg_joiner = join_data_msg2
		else:
			self.reply_nack = self.trad_reply_nack
			self.msg_joiner = join_data_msg

	def request(self, address, i, bmap):
		self.network.node(address).request_bmap(i, bmap)
	
	def nack(self, address, i, offsets, code=NACK_ID):
		if offsets:
			if code == NACK_ID:
				code, kind = DATA_ID, 'nack'
			else:
				code, kind = QDATA_ID, 'qnack'
			Logger.dbg(8, address, kind, i, offsets)
			self.nacks = [x for x in self.nacks if x[1] != i]
			self.nacks.append((address, i, offsets, code))
	
	def subst_code(self, msg, code):
		found = ord(msg[0])
		if code != found and found not in (METADATA_ID, MULTI_ID):
			msg = chr(code) + msg[1:]
		return msg

	def find_trad_msg(self, i, j):
		bl, prio = self.buffer.get(i), i * PARTS_PER_BLOCK + j
		return [x for x in bl.get_msgs(join_data_msg) if x[0] == prio]

	def trad_reply_nack(self, address, i, offsets, code):
		for j in offsets:
			x = self.find_trad_msg(i, j)
			if x:
				prio, msg = x[0]
				msg = self.subst_code(msg, code)
				self.network.send_data_meta(address, msg, prio, True)
			else:
				Logger.dbg(8, 'cant reply', i, j)
	
	def spans_complete_block(self, offsets, bl, expected_start):
		approx = [(expected_start, self.buffer.block_size)]
		exact = [(bl.start, bl.stop - bl.start)]
		return not cmp(offsets, approx) or not cmp(offsets, exact)
	
	def smart_reply_nack(self, address, i, offsets, code):
		expected_start = self.buffer.expected_start_stop(i)[0]
		offsets = join_offsets(offsets, self.buffer.part_size)
		bl = self.buffer.get(i)
		sent = []
		if self.spans_complete_block(offsets, bl, expected_start):
			for prio, msg in bl.get_msgs(self.msg_joiner):
				msg = self.subst_code(msg, code)
				self.network.send_data_meta(address, msg, prio, True)
				sent.append((prio, len(msg)))
		else:
			for start,size in offsets:
				l = bl.range_msgs(self.metadata_always, expected_start, start, size, self.buffer.part_size, code == QDATA_ID)
				for pos,n,msg in l:
					msg = self.subst_code(msg, code)
					self.network.send_data_meta(address, msg, pos, True)
					sent.append((pos, n))
		if sent:
			Logger.dbg(8, address, 'reply', i, sent)
	
	def __call__(self):
		if not self.generator:
			self.generator = self.generator_function()
		try:
			self.generator.next()
		except StopIteration:
			self.generator = None

	def generator_function(self):
		while self.when <= time():
			limit = new_limit()
			while self.nacks:
				x = self.nacks.pop(0)
				if self.buffer.get(x[1]).has_anything():
					self.reply_nack(x[0], x[1], x[2], x[3])
				else:
					Logger.dbg(8, x[0], 'reply failed, missing', x[1], self.buffer.get(x[1]).full_info(self.buffer, x[1]))
				if time() >= limit:
					yield
					limit = new_limit()
			all_todo = set([])
			order = self.network.partners()
			order.sort(key=lambda x: len(x.requested))
			sent = False
			for host in order:
				if time() >= limit:
					yield
					limit = new_limit()
				host.sent = [x for x in host.sent if x in host.requested]
				todo = [x for x in host.requested if x not in host.sent]
				if host.has_req_changed():
					Logger.dbg(8, host.address, 'requested', len(host.requested), host.requested, 'not yet', todo)
					self.cancel_rescheduled(host)
				lsent = []
				all_todo = all_todo.union(todo)
				for i in todo:
					if time() >= limit:
						yield
						limit = new_limit()
					bl = self.buffer.get(i)
					psent = []
					for msg in bl.get_msgs(self.msg_joiner):
						self.network.send_data_meta(host.address, msg[1], msg[0])
						psent.append(msg[0])
					if psent:
						lsent.append((i, psent))
						host.sent.append(i)
					elif i < self.buffer.window_limits()[0]:
						host.sent.append(i)
					else:
						host.sent.append(i)
						Logger.info(5, host.address, 'not sent', bl.full_info(self.buffer, i))
				if lsent:
					Logger.dbg(8, host.address, 'sent', lsent)
					sent = True
			if not sent:
				self.when = time() + DEFAULT_TIMEOUT
			self.check_todo(all_todo)

	def check_todo(self, todo):
			todo = sorted(todo)
			if cmp(self.todo, todo):
				self.todo = todo
				if todo:
					Logger.dyn(2, 'todo', self.todo)
	
	def cancel_rescheduled(self, hi):
		rngs = set([self.buffer.block_range(i) for i in hi.requested])
		dest = self.network.myself.destination(hi.address)
		l = []
		for x in dest.queue:
			if x[0] > 0:
				for rng in rngs:
						if rng[0] <= x[0] - 1 < rng[1]:
							break
				else:
					l.append(x)
		n = len(dest.queue)
		for x in l:
			if x in dest.queue: # sent because of yield
				try:
					dest.queue.remove(x)
				except ValueError:
					pass # illogic !!!
		if l:
			Logger.dbg(8, hi.address, 'rescheduled', [x[0] - 1 for x in l], n, len(dest.queue))

def new_limit():
	return time() + SOFT_DELAY
