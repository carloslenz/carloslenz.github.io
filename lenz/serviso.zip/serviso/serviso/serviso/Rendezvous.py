# Carlos Eduardo Lenz - PPGCC - UFSC
from time import time

from Config import DEFAULT_MAX_THROUGHPUT
from Destination import DEFAULT_RENDEZVOUS_PORT
from Host import Host
from Logger import Logger
from Network import Network
from Message import decode_msg, enter_msg, leave_msg, nodes_msg, ENTER_ID, LEAVE_ID, NODES_ID, PARTNER_ID
from ProcessGroup import DEFAULT_CPU_TM

DEFAULT_TIMEOUT = 0.1

class Rendezvous(Network):
	def __init__(self, myself):
		Network.__init__(self, myself, self, False, (0, 0))
	
	def server(self):
		self.myself.bind()
		while True:
			self()
	
	def __call__(self):
		for s, address in self.myself(DEFAULT_CPU_TM, DEFAULT_TIMEOUT):
			self.tick(address)
			msg = decode_msg(s)
			if msg[0] == ENTER_ID:
				already = self.knows(address)
				self.add_node(address)
				self.be_deputy(address)
				if not already:
					Logger.info(1, address, 'enter', self.count_nodes())
			elif msg[0] == LEAVE_ID:
				if self.knows(msg[1]):
					self.remove_node(msg[1], 'leave from ' + str(address))
			elif msg[0] == NODES_ID and len(msg[1]) == 0:
				self.be_deputy(address)
				self.add_node(address)
			elif msg[0] == PARTNER_ID:
				Logger.maniac(8, 'ignore partnership', address)
		self.myself.check_feedback(None)
		self.expire_nodes()
	
	def enter(self, host):
		host.send(self.myself, enter_msg(), 0) # accessing rendezvous
	
	def leave(self, host, address):
		host.send(self.myself, leave_msg(address), 0)
	
	def stop(self):
		pass

	@staticmethod
	def for_hostname(name, port):
		return Rendezvous(Host((name, port), DEFAULT_MAX_THROUGHPUT))
