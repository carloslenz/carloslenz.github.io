# Carlos Eduardo Lenz - PPGCC - UFSC
from time import time

from Host import host_addresses, DEFAULT_BANDWIDTH
from Node import DEFAULT_BMAP
from Logger import Logger
from Message import leave_msg

from util import safe_div

DEFAULT_MAX_TRIES = 5
PENDING_EXPIRED = 1
RESEND_PERIOD = 2

MIN_RTT = -0.05

class PartnershipManager:
	def __init__(self, network, buffer, limits, maxRTT, leavesHost, maxLeaves):
		self.network = network
		self.buffer = buffer
		self.limits = limits
		self.maxRTT = maxRTT
		self.leavesHost = leavesHost
		self.maxLeaves = maxLeaves
		self.pending = {}
		self.pending_expired = PENDING_EXPIRED
		self.maxTries = DEFAULT_MAX_TRIES
		self.nodeCount = -1
		self.max_loss_rate = 0.12
		self.current_loss_rate = self.last_resend = 0
		self.resend_period = RESEND_PERIOD
		self.partners = set([])
		self.left = {}

	def loss_info(self, loss, total):
		self.current_loss_rate = safe_div(loss, total)

	def leaving(self, address, msg, rtt=0.0):
		key, v = str(address), 1
		if rtt:
			if key in self.left:
				v = self.left[key] + 1
			self.left[key] = v
			Logger.info(1, key, 'leave', v, msg)
		else:
			Logger.info(1, key, 'leave', msg)
		hi = self.network.node(address)
		hi.bad_rtt = rtt
		hi.avoid_msg = msg
		self.avoid(hi)

	def check_left(self):
		left2 = set([key for key in self.left if self.left[key] > self.leavesHost])
		n = len(left2)
		if n > self.maxLeaves and self.current_loss_rate > self.max_loss_rate:
			Logger.quitter('Too many leaves %f %s' % (self.current_loss_rate, ' '.join(left2)), 2)
		for hi in self.network.no_partners():
			if str(hi.address) in left2:
				self.network.remove_node(hi.address, 'leaving a lot')

	def __call__(self):
		self.check_left()
		partners = self.network.partners()
		partners.sort(key=lambda x: x.address)
		self.expire_pending()
		self.request_nodes()
		self.make_partnerships(partners)
		self.resend_partnerships(partners)
		silent = self.avoid_silent()
		if self.maxRTT:
			self.check_avoided()
			self.avoid_slow(partners, silent)

	def avoid_silent(self):
		l = self.network.silent_nodes()
		for hi in l:
			self.leaving(hi.address, 'silent')
			self.avoid(hi)
			self.network.leave_network(hi.address)
		return l

	def avoid_slow(self, partners, silent):
		for p in partners:
			dest = self.network.myself.destination(p.address)
			if not (MIN_RTT < dest.round_trip_time < self.maxRTT) and p not in silent:
				self.leaving(p.address, 'slow %f' % dest.round_trip_time, dest.round_trip_time)

	def avoid(self, node):
		self.network.send_info(node.address, leave_msg(self.network.myself.address, node.bad_rtt))
		if node.avoid_it():
			self.network.remove_node(node.address, node.avoid_msg)

	def check_avoided(self):
		for node in self.network.avoided():
			self.avoid(node)

	def resend_partnerships(self, partners):
		now = time()
		if self.last_resend + self.resend_period <= now:
			inactive = []
			for x in partners:
				if not cmp(x.bmap, DEFAULT_BMAP): # partnership really established?
					inactive.append(x.address)
					if x.tick + self.network.timeout < now:
						self.network.remove_node(x.address, 'failed partnership')
					else: # resend partnership, doesnt expect confirmation
						self.network.request_partnership(x.address, self.buffer.mdat_index, False)
			if inactive:
				Logger.dbg(5, x.address, 'inactive partnerships', inactive)
			self.last_resend = now
	
	def expire_pending(self):
		now = time()
		expired = [x for x in self.pending if self.pending[x] + self.pending_expired < now]
		for x in expired:
			node = self.network.node(x)
			node.tried_partnerships = node.tried_partnerships + 1
			if node.tried_partnerships > self.maxTries:
				self.network.remove_node(x, 'partnership request expired')
			else:
				dest = self.network.myself.destination(x)
				if not dest.packet_count:
					self.network.myself.remove_messages_for(x)
			del self.pending[x]
	
	def make_partnerships(self, partners):
		missing = self.limits[0] - len(partners)
		other = [x for x in host_addresses(self.network.no_partners()) if x not in self.pending]
		if missing > 0:
			now = time()
			for x in self.network.select_some_nodes_from(missing, other):
				self.network.request_partnership(x, self.buffer.mdat_index)
				self.pending[x] = now
		partners = set(partners)
		if self.partners != partners:
			for x in self.partners - partners:
				Logger.statPartner(x.address, False)
			for x in partners - self.partners:
				Logger.statPartner(x.address, True)
			self.partners = partners
			idx = 0
			nodes = list(self.network.nodes)
			if nodes and len(nodes) > len([1 for x in nodes if x[0] == nodes[0][0]]):
				idx = 1
			Logger.dyn(9, 'partners', sorted([x.address[idx] for x in partners]), 'missing', missing, 'pending', [x[idx] for x in self.pending], 'other', [x[idx] for x in other])
	
	def request_nodes(self):
		count = self.network.count_nodes()
		if count != self.nodeCount:
			self.nodeCount = count			
			Logger.dbg(5, 'node count', count)
		if self.network.need_nodes():
			self.network.request_more_nodes()
	
	def request(self, address, mdat_index, req):
		bandwidth = DEFAULT_BANDWIDTH
		if address in self.pending:
			self.network.add_partner(address, bandwidth)
			del self.pending[address]
		if not self.network.node(address).is_partner() and self.limits[1] > self.network.count_partners():
			self.network.add_partner(address, bandwidth)
		if self.network.node(address).is_partner() and req: # confirms it
			self.network.request_partnership(address, self.buffer.mdat_index, False)
		if self.network.node(address).is_partner() and mdat_index != None and self.buffer.mdat_index == None:
			self.buffer.mdat_index = mdat_index
			Logger.high('mdat_index', mdat_index, 'header_size', self.buffer.header_size())
			for x in self.network.partners():
				self.network.request_partnership(x.address, mdat_index, False)
