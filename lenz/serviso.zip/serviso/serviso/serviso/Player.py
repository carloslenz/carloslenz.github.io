# Carlos Eduardo Lenz - PPGCC - UFSC
from os import getpid, kill
from os.path import expanduser
from signal import SIGINT
from subprocess import Popen, PIPE, STDOUT
from sys import argv, stdin
from threading import Thread
from time import sleep

from Buffer import Buffer
from Logger import Logger
from Pager import restrict_access
from Window import Window

EMPTY = 'EMPTY'

THREADED_PLAYER_IO_TIMEOUT = 0.3

class Player:
	def __init__(self, buffer, header_factor, player=None):
		self.buffer = buffer
		self.sec_pos = None
		self.running = False
		self.items = []
		self.reader = self.read_start
		self.header_factor = header_factor
		if player:
			if isinstance(player, str):
				player = player.split(' ')
			self.player = player
			self.writer = self.write_one
			self.really_read = True
		else:
			self.player = player
			self.writer = self.write_none
			self.really_read = True
		self.thread = Thread(target=self.keep_writing, name='PLAYER')
		self.thread.setDaemon(True)
		self.thread.start()

	def stop(self):
		def none0():
			self.items.insert(0, None)
			return None
		restrict_access(none0)
		if self.player:
			sleep(0.3)
			Logger.high('killing player', self.player.pid)
			kill(self.player.pid, SIGINT)

	def keep_writing(self):
		item = self.pop_block()
		if self.player:
#			if self.sec_pos:
#				self.player = self.player + ['-ss', str(self.sec_pos)]
			player = self.player
			logpath = expanduser('~/tmp/player%d.txt' % getpid())
			if isinstance(player, list):
				player = '"%s > %s"' % (' '.join(player), logpath)
			Logger.high('player:', player)
			f = open(logpath, 'w')
			self.player = Popen(self.player, stdin=PIPE, stdout=f, stderr=STDOUT)
		while item:
			self.writer(item())
			item = self.pop_block()

	def push_block(self, q):
		def append():
			self.items.append(q)
			return None
		return restrict_access(append)

	def pop_block(self):
		def pop0():
			if not self.items:
				return EMPTY
			return self.items.pop(0)
		val = restrict_access(pop0)
		while val == EMPTY:
			sleep(THREADED_PLAYER_IO_TIMEOUT)
			val = restrict_access(pop0)
		return val

	def __call__(self):
		is_jump = self.inside_jump()
		if is_jump and self.running and self.last_jump != self.buffer.jump_index:
			Logger.high('rush from', self.buffer.read_index, 'to', self.buffer.jump_index)
		self.last_jump = self.buffer.jump_index
		b = self.buffer(self.really_read, is_jump)
		if b:
			self.reader(b)
			return True
		return False

	def header_jump_index(self):
		return self.buffer.header_size() - self.buffer.window.distance * self.header_factor

	def inside_jump(self):
		index = max(self.buffer.jump_index, self.header_jump_index())
		return index > self.buffer.read_index

	def read_start(self, b):
		self.running = True
		self.reader = self.push_block
		self.reader(b)
		if self.buffer.jump_index:
			Logger.high('jump from', self.buffer.read_index, 'to', self.buffer.jump_index)

	def write_one(self, b):
		if self.player.poll() != None:
			Logger.panic('player returned:', self.player.returncode)
			kill(getpid(), SIGINT)
			exit(1)
		self.player.stdin.write(b)
	
	def write_none(self, b):
		pass
	
	def jump_to(self, i):
		if i != self.buffer.jump_index and i > self.buffer.read_index + self.buffer.window.distance * 1.5:
			self.sec_pos, self.buffer.jump_index = i - self.buffer.header_size(), i
