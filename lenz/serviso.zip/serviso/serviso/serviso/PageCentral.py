# Carlos Eduardo Lenz - PPGCC - UFSC
from select import select
from time import time

from Host import HOSTIP
from Logger import Logger

from util import tcp_non_blocking_socket, udp_non_blocking_socket, ANY_NIC

RENDEZVOUS_KEY = str((HOSTIP, 15418))

DEFAULT_CENTRAL_PORT = 14530
DEFAULT_PAGE_PORT = DEFAULT_CENTRAL_PORT + 1
DEFAULT_CENTRAL_ADDRESS = (ANY_NIC, DEFAULT_CENTRAL_PORT)

MAX_RECEIVE = 8 * 1024

#from random import random
#CHANCE = 1.0 / 30

class PageCentral:
	def __init__(self, local):
		self.local = local
		self.nodes = {}
		from PageServer import PageServer
		self.stop = lambda : self.server.stop()
		self.server = PageServer(True)
		self.do_page = self.server.__call__

	def __call__(self, key, msg):
		if key:
#			if random() < CHANCE: # testing repage!
#				return None
			node = self.node(key)
			self.store(key, node, msg)
			self.send_all(key, node)
			missing = self.missing(key, node)
			if missing:
				return key, self.request_msg(missing)
		return None
	
	def check_yourself(self):
		msgs = self.local('')
		node = self.node(RENDEZVOUS_KEY)
		for x in msgs:
			self.store(RENDEZVOUS_KEY, node, x)
		self.send_all(RENDEZVOUS_KEY, node)
	
	def store(self, key, node, msg):
		node[4] = node[4] + msg
		self.extract(key, node)
	
	def send_all(self, key, node):
		dict = node[0]
		before = i = node[1]
		while i in dict:
			page = dict[i][1]
			self.proc_page(i, key, page)
			del dict[i]
			i = i + 1
		if before != i:
			node[1] = i
			Logger.maniac(6, key, 'sent pages', (before, i))

	def make_msg(self, i, key, page):
		return 'node %d %d %s\n%s' % (len(page), i, key, page)

	def proc_page(self, i, key, page):
		self.do_page(self.make_msg(i, key, page))

	def send_to_stop(self):
		self.local.pager.new_page()
		self.check_yourself() # send last page
		for key in self.nodes:
			node = self.node(key)
			dict, before = node[:2]
			if dict:
				l = sorted(dict)
				Logger.maniac(6, key, 'sending remaining pages')
				if l and before != l[0]:
					page = 'COMPLETE BEFORE %s\nPAGES %s\n' % (before, l)
					self.proc_page(before, key, page)
				for i in l:
					page = dict[i][1]
					self.proc_page(i, key, page)
		self.stop
	
	def node(self, key):
		if key not in self.nodes:
			self.nodes[key] = [{}, 0, 0, 0, '', ''] # msgs, complete_before, n, i, buffer
		return self.nodes[key]

	def extract(self, key, node):
		dict = node[0]
		before, n, i, msg, last = node[1:]
		stored = False
		while True:
			if not n and len(msg) > 50:
				header, nn, rest = msg.partition('\n')
				assert nn == '\n'
				parts = header.split()
				if 'page' != parts.pop(0):
					Logger.quitter(6, key, 'PageCentral error %d n %d %s buf %s' % (i, n, (len(msg), len(last)), (last[-30:], msg[0:150])), 1)
#				else:
#					Logger.maniac(6, key, 'PageCentral header', header, (len(rest), len(last)), 'buf', (last[-150:], rest[0:150]))
				try:
					n, i, msg = int(parts.pop(0)), int(parts.pop(0)), rest
				except:
					Logger.maniac(6, 'central', header)
					raise
			if 0 < n <= len(msg):
				page, msg = msg[:n], msg[n:]
				dict[i] = [ time(), page ]
				Logger.maniac(6, key, 'PageCentral store', i, len(msg))
				i = n = 0
				last = page
				stored = True
			else:
				break
		if not stored:
			Logger.maniac(6, key, 'PageCentral none', i, 'n', n, (len(msg), len(last)), 'buf', (last[-150:], msg[0:150]))
		node[2:] = n, i, msg, last
	
	def missing(self, key, node): # does not check other nodes
		limit = time() - 1
		dict = node[0]
		l = sorted(dict, reverse=True)
		for x in l:
			if dict[x][0] < limit:
				return self.missing_range(key, dict, node[1], x)
		return []
	
	def missing_range(self, key, dict, a, b):
		l = []
		now = time()
		for x in range(a, b):
			if x in dict:
				dict[x][0] = now
			else:
				l.append(x)
		dict[b][0] = now
		if l:
			Logger.maniac(6, key, 'recover pages', l)
		return l
	
	def request_msg(self, missing):
		return 'repage ' + ' '.join([str(x) for x in missing])

class TcpPageCentral(PageCentral):
	def __init__(self, local):
		PageCentral.__init__(self, local)
		self.rsocket = tcp_non_blocking_socket()
		self.rsocket.bind(DEFAULT_CENTRAL_ADDRESS)
		self.rsocket.listen(5)
		self.socks = {}
		Logger.info(1, 'TcpPageCentral listening', DEFAULT_CENTRAL_ADDRESS)

	def __call__(self, key, msg):
		self.accept_connections()
		l = self.select_sockets()
		while l:
			x = l.pop()
			key, msg = self.receive_data(x)
			missing = PageCentral.__call__(self, key, msg)
			if missing:
				Logger.panic(key, 'TcpPageCentral missing', list(self.node(key)[0]), missing)
			if not l:
				l = self.select_sockets()
		return ''
	
	def accept_connections(self):
		try:
			sock, addr = self.rsocket.accept()
			key = str(addr)
			self.socks[sock] = key
			Logger.info(1, 'TcpPageCentral accepted', key)
		except:
			pass # non-blocking accept() raises error when there're no connections
	
	def select_sockets(self):
		l = list(self.socks)
		return select(l, [], [], 0)[0]

	def receive_data(self, sock):
		key, msg = self.socks[sock], sock.recv(MAX_RECEIVE)
		if not msg:
			Logger.info(1, 'TcpPageCentral close', key)
			del self.socks[sock]
			return '', ''
		return key, msg

class UdpPageCentral(PageCentral):
	def __init__(self, local):
		PageCentral.__init__(self, local)
		self.sock = udp_non_blocking_socket()
		self.sock.bind(DEFAULT_CENTRAL_ADDRESS)
		Logger.info(1, 'UdpPageCentral listening', DEFAULT_CENTRAL_ADDRESS)

	def __call__(self, key, msg):
		while select([self.sock], [], [], 0)[0]:
			key, msg = self.receive_data()
			missing = PageCentral.__call__(self, key, msg)
			if missing:
				Logger.idbg(5, key, 'UdpPageCentral has', sorted(self.node(key)[0]), 'missing', missing[1])
				return key, missing[1]
		return None

	def receive_data(self):
		msg, addr = self.sock.recvfrom(MAX_RECEIVE)
		return (str(addr), msg)

class EmptyPager:
	def new_page(self):
		pass

class EmptyPageNodeOrCentral:
	def __init__(self, local=None):
		self.pager = EmptyPager()

	def __call__(self, *args):
		return []

	def send_to_stop(self):
		pass

	def check_yourself(self):
		pass
