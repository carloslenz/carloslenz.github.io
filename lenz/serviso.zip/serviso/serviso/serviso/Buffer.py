# Carlos Eduardo Lenz - PPGCC - UFSC
from math import ceil
from time import time

from Block import Block, PARTS_PER_BLOCK
from Logger import Logger
from Part import Part, HEADER_TYPE, MISSING_BIT
from Window import Window

DEFAULT_BLOCK_SIZE = 60000

class Buffer:
	def __init__(self, map_size, window_distance, acceptable_ratio, acceptable_rate, isSmart, loader, jumper, metadata_always, select_algo, check_ahead):
		self.blocks = {}
		self.size_drop = self.rate_drop = 0
		self.acceptable_ratio = acceptable_ratio
		if acceptable_ratio < 0:
			self.size_drop = - acceptable_ratio
			self.acceptable_ratio = 0
		self.acceptable_rate = acceptable_rate
		if acceptable_rate < 0:
			self.rate_drop = - acceptable_rate
			self.acceptable_rate = 0
		self.set_block_size(DEFAULT_BLOCK_SIZE)
		self.set_nalulen(4)
		self.ignored = self.jump_index = self.read_index = self.seek_distance = self.offset_index = self.append_index = self.sum_lost = self.sum_late = 0
		self.startable = self.played_something = False
		self.ignorable = True
		self.window = Window(map_size, window_distance)
		# not where it starts but where there's no header anymore:
		self.mdat_index = None
		self.late = set([])
		self.dirty()
		self.stopped = 0
		self.loader = loader
		self.jumper = jumper
		self.metadata_always = metadata_always
		self.select_algo = select_algo
		if not loader:
			self.around = self.no_around # self.loader.around
		self.rate_start = self.size_start = 1.0
		self.check_ahead = check_ahead
		if isSmart:
			self.is_enough = self.smart_is_enough
			self.is_missing = self.smart_is_missing
			self.empty_block = self.smart_empty_block
			self.process_block = self.smart_process_block
			self.block_missing = self.smart_missing
			self.block_is_complete = self.smart_is_complete
			self.create_msgs = self.smart_create_msgs
			self.block_joined = self.smart_joined
			self.header_size1 = self.smart_header_size1
			self.stat_lost = self.smart_lost_stat
			self.block_range = self.expected_start_stop
		else:
			self.is_enough = self.trad_is_enough
			self.is_missing = self.trad_is_missing
			self.empty_block = self.trad_empty_block
			self.append = self.trad_append
			self.process_block = self.trad_process_block
			self.block_missing = self.trad_missing
			self.block_is_complete = self.trad_is_complete
			self.create_msgs = self.trad_create_msgs
			self.block_joined = self.trad_joined
			self.header_size1 = self.trad_header_size1
			self.stat_lost = self.trad_lost_stat
			self.block_range = self.trad_range

	def no_around(self, pos):
		return pos, pos

	def index(self):
		return max(self.read_index, self.jump_index)

	def seek_to(self, index, partners):
		if not self.index() and len(self.blocks) < self.window.distance:
			return # ignore it this time, let the jump happen first
		new_seek = index - self.index()
		if new_seek > self.seek_distance:
			if new_seek < self.window.map_size * 2:
				Logger.high('seek_to', index, 'distance', new_seek, 'from', self.seek_distance)
				self.seek_distance = new_seek
				self.dirty()
			else:
				Logger.panic('SEEEEK', (index, new_seek), [(x.address, x.available, x.bmap) for x in partners])

	def guess_index(self, available):
		return min(sum(available) / len(available), max(available) - self.window.distance)

	def set_nalulen(self, size):
		self.nalulen = size
		if size != 4:
			Logger.high('nalulen', size)

	def set_block_size(self, size, shouldLog=True):
		self.block_size = size
		self.part_size = self.block_size / PARTS_PER_BLOCK
		if self.part_size * PARTS_PER_BLOCK != self.block_size:
			self.part_size = self.part_size + 1
			self.block_size = self.part_size * PARTS_PER_BLOCK
		self.available_size = int(self.acceptable_ratio * self.block_size)
		if size != DEFAULT_BLOCK_SIZE and shouldLog:
			Logger.high('block_size', self.block_size, 'part_size', self.part_size, 'available', self.available_size, 'max_miss', self.block_size - self.available_size)

	def get_acceptable_rate(self, nacks):
		if self.acceptable_rate:
			return self.acceptable_rate
		return min(1.0, self.rate_start - nacks * self.rate_drop)

	def get_available_size(self, nacks):
		if self.available_size:
			return self.available_size
		return int(min(1.0, self.size_start - nacks * self.size_drop) * self.available_size)

	def nack(self, i):
		if self.window.near(i, self.read_index):
			self.get(i).nacked()

	def trad_lost(self, ignorable, i, j):
		start = i * self.block_size + j * self.part_size
		stop = start + self.part_size
		start1 = self.around(start)[0]
		stop1 = self.around(stop)[1]
		size = stop1 - start1
		if size:
			lost, stat, logf, msg, stop = self.common_lost(ignorable, start1, size)
			logf(0, msg, stat, 'sum', float(lost) / self.part_size, 'i', i, 'part', j)

	def common_lost(self, ignorable, start, size):
		bl, msg, logf = self.get(start // self.block_size), 'lost', Logger.dyn
		if not bl.is_last or start <= max(bl.parts):
			self.sum_lost = self.sum_lost + size
			if ignorable:
				self.ignore_loss(size)
				logf = Logger.idbg
		else:
			msg = msg + '?'
		Logger.statLost(start, size, ignorable)
		stop, lost = start + size, self.sum_lost - self.ignored
		return lost, float(lost) / stop, logf, msg, stop

	def smart_lost(self, ignorable, start, size, dataType=None, weight=None):
		if size:
			lost, stat, logf, msg, stop = self.common_lost(ignorable, start, size)
			logf(0, msg, stat, 'sum', lost, 'start', start, 'size', size, 'stop', stop, 'T', dataType, 'W', weight)

	def ignore_loss(self, n):
		self.ignored = self.ignored + n
	
	def trad_lost_stat(self, n=-1): # merge/replace with smart_lost_stat?
		if n == -1:
			n = self.read_index
		return (self.sum_lost - self.ignored, n * self.block_size)

	def smart_lost_stat(self, idx=-1):
		return (self.sum_lost - self.ignored, self.offset_index)
	
	def missing_parts(self, i):
		return self.block_missing(self.get(i), i)
	
	def trad_missing(self, bl, i):
		return bl.trad_missing()
	
	def smart_missing(self, bl, i):
		return bl.smart_missing(self, i)

	def trad_is_missing(self, i):
		return i >= self.read_index and i not in self.blocks
	
	def smart_is_missing(self, i):
		return i >= self.read_index and not self.get(i).has_anything()

	def is_complete(self, i):
		return self.block_is_complete(self.get(i), i)
	
	def trad_is_complete(self, bl, i):
		return bl.trad_is_complete(self, i)
	
	def smart_is_complete(self, bl, i):
		return bl.smart_is_complete(self, i)
	
	def trad_is_enough(self, i, bl=None):
		if not bl:
			bl = self.get(i)
		return bl.trad_is_complete(self, i)
	
	def smart_is_enough(self, i, bl=None):
		if not bl:
			bl = self.get(i)
		if not bl.got_meta:
			return False
		missing = bl.smart_missing(self, i)
		return not bl.select_offsets(missing, self, i, self.select_algo)

	def is_available(self, i):
		return self.get(i).is_available()

	def trad_empty_block(self, i):
		bl = self.smart_empty_block(i)
		start = bl.stop - self.block_size
		bl.make_trad(start)
		return bl

	def smart_empty_block(self, i):
		stop = (i + 1) * self.block_size
		return Block(stop)
	
	def make_available(self, i, extra='', bl=None, completeIt=False):
		if i in self.blocks:
			if not bl:
				bl = self.blocks[i]
			if not bl.is_available():
				Logger.dbg(0, 'available', bl.full_info(self, i), extra)
			self.create_msgs(bl, i, completeIt)
		else:
			Logger.panic('AVAILABLE WHY', i)
		if not self.startable and not self.is_header(i) and self.has_header():
			self.startable = True
			return True
		return False

	def smart_create_msgs(self, bl, i, completeIt):
		bl.smart_create_msgs(self.metadata_always, i, self.expected_start_stop(i)[0], self.part_size, completeIt)
	
	def trad_create_msgs(self, bl, i, completeIt):
		bl.trad_create_msgs(self.metadata_always, i, self.part_size)
	
	def offset(self, i, offset):
		return self.get(i).part(offset)
	
	def block(self, i, ignorable):
		return self.block_joined(self.get(i), i, ignorable)
		
	def trad_joined(self, bl, i, ignorable):
		return bl.trad_joined(self, i, ignorable)
	
	def smart_joined(self, bl, i, ignorable):
		return bl.smart_joined(self, i, ignorable, self.metadata_always)

	def get(self, i, canCreate=False):
		if i not in self.blocks:
			bl = self.empty_block(i)
			if canCreate:
				assert i >= 0
				Logger.dbg(7, 'block', i)
				self.blocks[i] = bl
				self.dirty()
			return bl
		return self.blocks[i]

	def trad_range(self, i):
		first = i * PARTS_PER_BLOCK
		return first, first + PARTS_PER_BLOCK

	def expected_start_stop(self, i):
		start = i * self.block_size
		return (start, start + self.block_size)
	
	def trad_set(self, i, b):
		block = self.get(i, True)
		block.data = b
		block.start = self.expected_start_stop(i)[0]
		size = 0
		for j in range(0, PARTS_PER_BLOCK):
			if size > len(b):
				break
			block.trad_set(j)
			size = size + self.part_size
		if size == self.block_size:
			Logger.dbg(7, 'set', i, len(b))		
		else:
			Logger.high('set incomplete', i, len(block.parts), size)

	def trad_set_offset(self, i, j, b, wasNacked=False):
		block = self.get(i, True)
		block.trad_set(j, b, self, wasNacked, i)
	
	def set_data(self, i, offset, b, info, wasNacked=False):
		sizes, info_before, info_after = info
		bl = self.get(i, True)
		stop = bl.stop
		sumsizes = sum([abs(x) for x in sizes])
		if len(b) != sumsizes:
			Logger.panic('LEN (%d) != %d msg %d %s bl %s msg %s' % (len(b), sumsizes, offset, info, bl.full_info(self, i), b))
			assert False
		if sizes:
			bl.replace(b, offset)
			otherType = 0
			if self.is_header(i):
				otherType = HEADER_TYPE
			l = self.sizes_to_offsets_info(offset, sizes)
			try:
				bl.set_offsets(l, bl.check_mapper(self.nalulen, otherType), True)
			except:
				print 'dbg', otherType, i, self.header_size(), self.is_header(i)
				raise
		if info_before or info_after:
			orig = bl.full_info(self, i)
			bl.enter_infos(i, offset, info_before, len(b), info_after, self.metadata_always)
			if max(bl.parts) >= stop:
				Logger.quitter('OUT-OF-RANGE orig %s msg %d %s after %s' % (orig, offset, info, bl.full_info(self, i)), 1)

	def sizes_to_offsets_info(self, start, sizes):
		l = []
		for x in sizes:
			isVid = True
			if x <= 0:
				x, isVid = -x, False
			l.append((start, x, isVid))
			start = start + x
		return l
	
	def last_block(self):
		if self.blocks:
			return max(self.blocks)
		else:
			return -1
	
	def trad_append(self, b):
		i = self.last_block() + 1
		self.trad_set(i, b)
		self.make_available(i)
	
	def smart_append(self, b):
		self.get(self.last_block()).is_last = False
		data, start, offsets, otherType = b
		block = self.get(self.append_index, True)
		block.start = start
		block.data = data
		block.set_offsets(offsets, block.check_mapper(self.nalulen, otherType), True)
		stop = start + len(data)
		if block.stop > stop:
			block.stop = stop
		self.make_available(self.append_index, completeIt=block.stop > stop)
		self.append_index = self.append_index + 1
	
	def mark_end(self):
		i = self.last_block()
		block = self.get(i)
		if not block.is_last:
			Logger.high('mark-end', i)
			block.is_last = True
			self.dirty()
	
	def clear(self, i):
		if i in self.blocks:
			if self.is_available(i):
				Logger.statAvail(i, False, True)
			del self.blocks[i]
		self.late.discard(i)
	
	def purge_erasable(self):
		if self.mdat_index != None:
			for i in range(self.header_size(), self.first_map_block_number()):
				self.clear(i)
	
	def trad_header_size1(self):
		return self.mdat_index

	def smart_header_size1(self):
		for i in sorted(self.blocks):
			if self.blocks[i].stop >= self.mdat_index:
				return i + 1
		return (self.mdat_index / self.block_size) + 1

	def header_size(self):
		if self.mdat_index == 0:
			return 0
		elif self.mdat_index:
			return self.header_size1()
		return self.window.map_size

	def has_header(self):
		return not self.missing_header()
	
	def missing_header(self):
		if self.mdat_index == None:
			return [0]
		return [i for i in range(0, self.header_size())	if not self.is_complete(i)]
	
	def is_header(self, i):
		return 0 <= i < self.header_size()
	
	def is_ahead(self, i):
		return i >= self.read_index

	def is_within_limits(self, i):
		a, b = self.window_limits()
		return a <= i < b or self.is_header(i)

	def trad_process_block(self, b, *extra):
		Logger.dbg(7, 'read', self.read_index, 'n', len(b))
		self.offset_index = self.offset_index + len(b)
		return b

	def smart_process_block(self, x, ignorable):
		start, b = x
		blanks = start - self.offset_index
		i = self.read_index
		bl = self.get(i)
		if blanks > 0:
			Logger.dyn(0, 'blanks', blanks, self.offset_index, start)
			self.smart_lost(ignorable, start, blanks, self.offset_index)
			blank = chr(0) * blanks
			b = blank + b
			start = self.offset_index
		elif blanks < 0:
			blanks = -blanks
			Logger.panic(i, 'OVERLAPING', blanks, self.offset_index, start, self.get(i-1).full_info(self, i-1), bl.full_info(self, i))
			b = b[blanks:]
		self.offset_index = start + len(b)
		Logger.dbg(7, 'start', start, 'n', len(b), 'read')
	
		dif = self.offset_index - bl.stop
		if bl.stop and dif > 0:
			Logger.panic('FOLAP', dif, self.offset_index, bl.stop, bl.full_info(self, i))
		
		return b

	def ok_to_run(self):
		last = self.last_block()
		if self.read_index >= last or not self.check_ahead:
			return False
		indexes, minBlks = self.window.check_ahead_params(self.read_index)
		l = [i for i in indexes if not self.is_missing(i)]
		if len(l) >= minBlks:
			return True
		Logger.idbg(1, 'check_ahead', self.read_index, 'only', l)
		self.jumper()
		return False

	def __call__(self, really_read, insideJump):
		b = ''
		if self.ok_to_run():
			self.stopped = 0
			after_index, this_index = self.read_index + 1, self.read_index
			before = self.stat_lost()
			is_header = self.is_header(this_index)
			if self.ignorable and not insideJump and not is_header:
				ignorable = self.ignorable = False
			else:
				ignorable = insideJump and self.ignorable and not is_header
			bl = self.get(this_index)
			def proc():
				if really_read:
					x = self.block_joined(bl, this_index, ignorable)
					b = self.process_block(x, ignorable)
					after = self.stat_lost(after_index)
					lost = after[0] - before[0]
					total = after[1] - before[1]
					if lost and not ignorable and not bl.is_available():
						if not self.is_enough(this_index, bl):
							lost_msg = 'LOST'
							if this_index in self.late:
								lost_msg = lost_msg + '-LATE'
							Logger.info(0, lost_msg, lost, bl.full_info(self, this_index))
						else:
							self.make_available(this_index, 'greedy', bl)
				return b
			self.read_index = after_index
			self.purge_erasable()
			self.dirty()
			return proc
		else:
			if not self.stopped:
				Logger.high('stopped')
				self.stopped = time()
			elif time() - self.stopped > self.window.map_size:
				Logger.quitter('stopped for too long', 2)
		return b

	def set_late(self, i, isAdd):
		if isAdd:
			self.late.add(i)
		else:
			self.late.discard(i)
	
	def check_late(self, i):
		return i in self.late or self.is_missing(i)
	
	def dirty(self):
		self.status = None
	
	def get_status(self):
		if self.status == None:
			self.status = self.window(self)
		return self.status
	
	def block_map(self):
		return self.get_status()[0]
	
	def missing(self):
		return self.get_status()[1]
	
	def window_limits(self):
		return self.block_map()[0]

	def missing_limits(self):
		return self.get_status()[2]

	def server_available(self):
		return self.get_status()[3]

	def first_map_block_number(self):
		return self.block_map()[0][0]

	def read_limits(self):
		return self.get_status()[4]
