# Carlos Eduardo Lenz - PPGCC - UFSC
from struct import pack

from Logger import Logger

SINGLE_BITS = [1 << x for x in range(0, 8)]

NONE_AVAILABLE = (0, 0)

AHEAD_RATE = 0.8

class Window:
	def __init__(self, map_size, distance):
		self.map_size = map_size
		self.distance = distance
		self.size = map_size / 2

	def near(self, i, read_index):
		return i - read_index <= 2 * self.distance

	def check_ahead_params(self, read_index):
		return list(range(read_index, read_index + 2 * self.distance)), AHEAD_RATE * self.distance

	def __call__(self, buffer):
		# buffer bitmap
		stop = buffer.index() + self.size
		start = max(stop - self.map_size, 0)
		stop = start + self.map_size
		bools = [buffer.is_available(i) for i in range(start, stop)]
		first = last = 0
		if bools:
			for i in range(len(bools) -1, -1, -1):
				if bools[i]:
					x = i + start
					if not last:
						last = x
					first = x
		server_available = (first, last)
		bmap = ((start, stop), Window.bools_to_bmap(bools))
		# window around read_index
		if buffer.read_index < buffer.jump_index:
			stop = buffer.read_index + self.size
			start = max(stop - self.map_size, 0)
			stop = start + self.map_size
		read_win = (start, stop)
		# missing packets inside the window
		size = self.size
		h = buffer.header_size()
		if buffer.index() < h:
			size = max(size, h)
		start = base = buffer.jump_index
		if buffer.read_index >= base:
			base = buffer.read_index + buffer.seek_distance
			start = self.findStart(buffer.read_index)
		stop = size + base
		if not buffer.is_ahead(start):
			Logger.quitter('WINDOW %d %d %d %d' % (start, self.distance, buffer.index(), self.buffer.header_size()), 1)
		missing = [i for i in range(start, stop) if buffer.is_missing(i)]
		wanted = sorted(set(missing + buffer.missing_header()))
		return (bmap, wanted, (start, stop), server_available, read_win)
	
	def findStart(self, index):
		if index >= self.distance:
			return index + self.distance
		return 2 * index

	@staticmethod
	def bools_to_bmap(bools):
		args = []
		for i in range(0, len(bools), 8):
			b = 0
			for j in range(0, 8):
				try:
					b = b + abs(bools[i+j] << (7 - j))
				except IndexError:
					pass
			args.append(b)
		format = '!' + ('B' * len(args))
		args.insert(0, format)
		return apply(pack, args)
	
	@staticmethod
	def bmap_to_list(i, bmap):
		l = []
		for j in range(0, len(bmap)):
			l1 = Window.byte_to_list(i + j * 8, ord(bmap[j]))
			l = l + l1
		return l
	
	@staticmethod
	def byte_to_list(i, b):
		l = []
		for x in range(0, 8):
			if b & SINGLE_BITS[7 - x]:
				l.append(i + x)
		return l
		
	@staticmethod
	def list_to_bmap(missing, first=None):
		s = []
		if missing:
			missing = sorted(set(missing))
			if first == None:
				first = missing.__iter__().next()
			else:
				first = min(first, missing.__iter__().next())
		start = first
		next = start + 8
		c = 0
		for i in missing:
			while next <= i:
				append_as_char(s, c, missing, i, next, start)
				start = next
				next = next + 8
				c = 0
			else:
				try:
					c = c + SINGLE_BITS[7 - (i - start)]
				except:
					Logger.panic('MISSING 2 BMAP', missing, first)
					raise
		append_as_char(s, c, missing, None, next, start)
		return (first, ''.join(s))

def append_as_char(s, c, missing, i, next, start):
	if c > 255:
		Logger.panic('not byte', c, 'mis', missing, 'i', i, 'next', next, 'start', start, 's', s)
	s.append(chr(c))	
