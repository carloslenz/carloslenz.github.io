# Carlos Eduardo Lenz - PPGCC - UFSC
from copy import copy
from math import ceil

from Logger import Logger
from Message import data_msg, data_msg2, data_from_msg2, metadata_msg, multi_msg, MAX_DESL
from Part import Part, compare_part_size, compare_datatype, MISSING_BIT, FIL_TYPE, HEADER_TYPE, NONE_TYPE
from util import flat

PARTS_PER_BLOCK = 8

MAX_INFO = 255

DEFAULT_SELECT_ALGO = [0, 0, 0]

class Block:
	def __init__(self, stop = 0):
		self.start = self.stop = stop
		self.parts = { stop : Part(stop, 0, 0) }
		self.msgs = []
		self.got_meta = self.is_last = False
		self.meta_msg = self.data = ''
		self.nack_count = 0

	def encoded(self, start):
		assert self.start == start
		l = self.sorted()
		ls = []
		while l:
			part = l.pop(0)
			assert part.start == start
			start, s = part.encoded(start)
			assert s
			ls.append(s)
		return start, ''.join(ls)

	def full_info(self, buffer, i):
		expected_start, expected_stop = buffer.expected_start_stop(i)
		return (i, self.start, self.stop, len(self.data), self.is_available(), expected_start, expected_stop, self.parts_info())
	
	def parts_info(self):
		l = [self.part_info(x) for x in self.parts.items()]
		l.sort()
		return l

	def part_info(self, x):
		if isinstance(x[1], int):
			return x[0]
		return x[1].info()
			
	def sorted(self):
		l = self.parts.values()
		l.sort(key=lambda x: x.start)
		return l
	
	def has_anything(self):
		return bool([p for p in self.parts.values() if isinstance(p, int) or not p.is_missing()])
		
	def part(self, i):
		if i not in self.parts:
			return None
		return self.parts[i]
	
	def make_trad(self, start):
		self.start = start
		size = self.stop - start
		self.data = chr(0) * size
		self.parts = {}
	
	def trad_set(self, j, b='', buffer=None, wasNacked=False, i=0):
		if j in self.parts and wasNacked:
			Logger.info(4, 'ALREADY HAVE', i, j)
		self.parts[j] = j
		if b:
			ignoreFailure = False
			if buffer.part_size != len(b):
				lastb = buffer.last_block()
				postParts = [q for q in self.parts if q > j]
				ignoreFailure = lastb == i and not postParts
				if not ignoreFailure:
					Logger.quitter('SIZE %d %d %d %d %s' % (i, j, len(b), buffer.last_block(), postParts), 1)
			start = self.start + j * buffer.part_size
			stop = start + buffer.part_size
			self.replace(b, start, stop, ignoreFailure)

	def replace(self, b, start, stop=None, ignoreFailure=False):
		if not stop:
			stop = start + len(b)
		pos = start - self.start
		if pos < 0: # before
			self.data, self.start = chr(0) * (-pos) + self.data, start
			pos = 0
		if stop > self.stop:
			self.data, self.stop = self.data + chr(0) * (stop - self.stop), stop
		last = stop - self.start
		before, after = self.data[:pos], self.data[last:]
		n = len(self.data)
		self.data = before + b + after
		if n != len(self.data) and not ignoreFailure:
			Logger.quitter('REPLACE %d %d %s bl %s pos %s rel %s' % (n, len(self.data), (len(before), len(b), len(after)), (self.start, self.stop), (start, stop), (pos, last)), 1)

	def check_mapper(self, nalulen, otherType):
		def f(start, size, isVid):
			dataType = otherType
			if isVid and otherType != HEADER_TYPE:
				dataType = 0
			p = Part(start, size, dataType)
			p.checkDataType(nalulen, self.data, self.start)
			return p
		return f
	
	def info_mapper(self, start, size, dataType):
		return Part(start, size, dataType)
	
	def set_offsets(self, l, mapper, overwrite=False):
		if l:
			for start, size, x in l:
				if start not in self.parts or overwrite:
					if start >= self.stop:
						Logger.quitter('>STOP %d %d %d %d %s' % (start, size, self.start, self.stop, self.parts_info()), 1)
						return False
					self.parts[start] = mapper(start, size, x)
			for x in self.parts.values():
				if x.size <= 0:
					del self.parts[x.start]
			stop = sum(l[-1][:2])
			self.stop = max(self.stop, stop)
		return True
	
	def expand_info(self, start, infos):
		l = []
		for dataType,size in infos:
			l.append((start, size, dataType))
			start = start + size
		return l

	def solve_info(self, it, el, offsets, l, overlapping):
		start, v = it[0], compare_datatype(it[2], el[2])
		if v == 0:
			v = compare_part_size(it[1], el[1])
			overlapping.append((v, it, el))
			assert v != 0
		if v < 0:
			l.remove(el)
			del offsets[start]
		elif v > 0:
			if start in self.parts:
				del self.parts[start]
		return v

	def between(self, a, b, start, size):
		stop = start + size
		return (start <= a < stop) or (start < b <= stop) or (a < start and b > stop)

	def prepare_infos(self, l):
		offsets, overlapping = {}, []
		for x in l:
			offsets[x[0]] = x
		i, items = 0, self.parts.items()
		while i < len(items):
			start,p = items[i]
			if p.size < 1:
				del self.parts[start]
			elif start in offsets:
				el = offsets[start]
				if el[1] == p.size:
					if p.is_missing():
						p.set_dataType(el[2])
					l.remove(el)
					del offsets[start]
				elif self.solve_info(p.short_info(), el, offsets, l, overlapping) < 0:
					continue
			i = i + 1
		i = 0
		while i < len(l):
			el = l[i]
			start, stop = el[0], sum(el[:2])
			conflict = [p.short_info() for p in self.sorted() if self.between(start, stop, p.start, p.size)]
			if conflict:
				v = self.solve_info(conflict[0], el, offsets, l, overlapping)
				if len(conflict) > 1 or v < 0:
					continue # ie, dont increment the index: i
			i = i + 1
		if overlapping:
			overlapping.sort()
			Logger.panic('overlapping prepare info', overlapping)

	def parts_incl_missing(self, fix=False):
		l = self.sorted()
		self.include_missing(l, fix)
		return l

	def enter_infos(self, i, offset, info_before, size, info_after, metadata_always):
		def inf():
			return self.start, self.stop, [x.info() for x in self.sorted()]
		orig = inf()
		sum_before = sum([x[1] for x in info_before])
		start = offset - sum_before
		self.replace('', start) # expand if necessary
		sum_after = sum([x[1] for x in info_after])
		stop = offset + size + sum_after
		self.replace('', stop) # expand if necessary
		before = self.expand_info(start, info_before)
		after = self.expand_info(offset + size, info_after)
		offsets = before + after
		assert offsets
		self.prepare_infos(offsets)
		if not self.set_offsets(offsets, self.info_mapper):
			Logger.panic(i, 'INFO-OFFSETS', offset, size, info_before, info_after, 'orig', orig, 'after', inf())
			assert False
		l = self.sorted()
		last = l[0].start
		for p in l:
			if last > p.start:
				Logger.panic('INFO PREPARE', orig, before, after, offsets, inf())
				assert False
			last = p.start + p.size
		l = self.parts_incl_missing()
		mysz, sz = self.stop - self.start, l[-1].start + l[-1].size - l[0].start
		if mysz != sz:
			Logger.panic('block size mismatch', i, mysz, sz, inf(), orig, info_before, offset, size, info_after)
		assert mysz == sz
	
	def make_missing(self):
		for p in self.parts.values():
			if p.is_pending():
				p.make_missing()

	def split_groups(self, limit):
		groups, group, size, n = [], [], 0, 0
		for p in self.parts_incl_missing(fix=True):
			if group and (group[0].is_missing() != p.is_missing() or size >= limit):
				groups.append(group)
				n = n + size
				group, size = [], 0
			group.append(p)
			size = size + p.size
		if group:
			groups.append(group)
			n = n + size
		return (groups, n)
		
	def make_size(self, p):
		size = p.size
		if not p.is_video():
			size = - size
		return size
	
	def make_info(self, p):
		return (p.dataType_status(), p.size)
		
	def make_before_after_info(self, before, after):
		if len(before) > MAX_INFO:
			Logger.panic('MAX_INFO before', len(before))
			before = before[max(0, len(before) - MAX_INFO):]
		info_before = [self.make_info(p) for p in before]
		if len(after) > MAX_INFO:
			Logger.panic('MAX_INFO after', len(after))
			after = after[:MAX_INFO]
		info_after = [self.make_info(p) for p in after]
		return info_before, info_after

	def smart_msg_info(self, metadata_always, j, groups, start):
		group = groups[j]
		offset = group[0].start
		last = group[-1]
		stop = last.start + last.size
		size = stop - offset
		sizes = [self.make_size(p) for p in group]
		sz = sum([abs(x) for x in sizes])
		if sz != size:
			Logger.panic('MSG INFO SIZE', size, sz, sizes, j, [[self.part_info([0, x]) for x in grp] for grp in groups], start, self.parts_info())
		assert sz == size
		if not metadata_always: # dont always include metadata
			header = data_msg2(start, offset, '', sizes)
		else:
			if len(groups) > j + 1:
				next = groups[j + 1]
				next_start = next[0].start
				assert stop <= next_start
				if next_start > stop:
					next.insert(0, Part(stop, next_start - stop, NONE_TYPE))
			before = flat(groups[:j])
			after = flat(groups[j+1:])
			info_before, info_after = self.make_before_after_info(before, after)
			# prio, header, data_start, size
			header = data_msg2(start, offset, '', sizes, info_before, info_after)
		pos = offset - self.start
		return (offset, header, pos, size)

	def smart_create_msgs(self, metadata_always, i, start, limit, completeIt):
		self.make_missing()
		groups, size = self.split_groups(limit)
		grps_info = [(g[0].start, sum([x.size for x in g])) for g in groups]
		extra = 'first time'
		if self.msgs:
			extra = 'again'
		else:
			Logger.statAvail(i, True, True)
		Logger.dbg(1, start, 'parts', len(self.parts), 'msgs', len(groups), 'size', size, 'groups', grps_info, extra)
		self.msgs = [self.smart_msg_info(metadata_always, j, groups, start) for j in range(0, len(groups))]
		self.multi_msg_join(limit)
		self.metadata_only_msgs(metadata_always, self.msgs, self.sorted(), start, completeIt)

	def multi_msg_join(self, limit):
		def item_len(x, l, current):
			if not isinstance(x[3], int):
				Logger.panic('UNEXPECTED', x, l, self.msgs, current)
			return len(x[1]) + x[3]
		if len(self.msgs) > 10:
			l = [self.msgs.pop(0)]
			all = [l]
			while self.msgs:
				msgs = self.msgs.pop(0)
				if not isinstance(msgs, list):
					msgs = [msgs]
				for current in msgs:
					if sum([item_len(x, l, current) for x in l]) < limit:
						l.append(current)
					else:
						l = [current]
						all.append(l)
			self.msgs = all

	def trad_msg_info(self, i, j, part_size):
		header = data_msg(i, j, '')
		return (i * PARTS_PER_BLOCK + j, header, j * part_size, part_size)

	def trad_create_msgs(self, metadata_always, i, part_size):
		if self.msgs:
			Logger.dbg(1, 'create_msgs again', i)
		else:
			Logger.statAvail(i, True, True)
		self.msgs = [self.trad_msg_info(i, j, part_size) for j in sorted(self.parts)]
	
	def seek_offset_size(self, metadata_always, offset, size):
		stop = offset + size
		before = [x for x in self.sorted() if x.start < stop]
		parts = [x for x in before if offset <= x.start]
		l = []
		if not parts:
			infos = self.parts_info()
			if not metadata_always or (before and before[-1].start + before[-1].size > offset):
				Logger.maniac(8, 'ignore failed seek', offset, size, infos)
			else:
				Logger.panic('seek fail', offset, size, infos)
			return l
		self.include_missing(parts)
		first = last = n = 0
		for p in parts:
			if not p.is_blank() and p.start in self.parts:
				if p.start == last:
					n, last = n + p.size, last + p.size
				else:
					if n:
						l.append((first, n))
					n, first, last = p.size, p.start, p.start + p.size
			elif n:
				l.append((first, n))
				n = last = first = 0
		if n:
			l.append((first, n))
		if offset in self.parts and not self.parts[offset].is_missing() and (not l or l[0][0] != offset):
			Logger.panic('OFFSET', offset, l, [p.info() for p in parts])
			assert False
		return l

	def data_msg_without_meta(self, start, first, s, sizes, all_parts):
		return data_msg2(start, first, s, sizes)

	def data_msg_with_meta(self, start, first, s, sizes, all_parts):
		last = first + len(s)
		before = [p for p in all_parts if p.start < first]
		after = [p for p in all_parts if p.start >= last]
		info_before, info_after = self.make_before_after_info(before, after)
		return data_msg2(start, first, s, sizes, info_before, info_after)

	def range_msgs(self, metadata_always, start, offset, size, limit, isQnack):
		assert size
		if not self.has_anything():
			Logger.dbg(8, 'reply', (offset, size), 'empty', (start, self.stop))
			return []
		if offset + size > self.stop and metadata_always:
			Logger.panic('overflow', start, offset, size, self.stop, isQnack)
			assert isQnack
		f, all_parts = self.data_msg_without_meta, self.parts_incl_missing()
		if metadata_always:
			f = self.data_msg_with_meta
		offsets = self.seek_offset_size(metadata_always, offset, size)
		def each_offset(first, sz):
			pos = first - self.start
			s = self.data[pos : pos + sz]
			assert len(s) == sz
			a, n, sizes = first, sz, []
			while n > 0:
				if a not in self.parts:
					Logger.panic(a, sz, 'RANGE', (offset, size), offsets, self.parts_info())
				p = self.parts[a]
				sizes.append(p.size)
				a, n = a + p.size, n - p.size
			assert sum(sizes) == sz
			msg = f(start, first, s, sizes, all_parts)
			try:
				data_from_msg2(msg, hack=False)
			except:
				Logger.panic('RANGE_MSGS', start, first, (s,), sizes, sz, [self.part_info([0, x]) for x in all_parts])
				raise
			return (first, size, msg)
		l = [each_offset(first, sz) for first, sz in offsets]
		if l and (isQnack or l[0][0] != offset):
			if self.meta_msg:
				l.insert(0, (None, 0, self.meta_msg))
#			else:
#				self.metadata_only_msgs(metadata_always, l, all_parts, start)
		return l

	def include_missing(self, l, fix=False):
		orig = [p.resume() for p in l]
		i = 1
		while i < len(l):
			lastp, p = l[i - 1 : i + 1]
			stop = lastp.start + lastp.size
			missing = p.start - stop
			if missing > 0:
				l.insert(i, Part(stop, missing, MISSING_BIT))
			elif fix and missing < 0:
				el = p.short_info()
				v = self.solve_info(lastp.short_info(), el, {lastp.start : p}, [el], [])
				if v > 0:
					l.remove(p)
				elif v < 0:
					if lastp.start in self.parts:
						del self.parts[lastp.start]
				continue
			i = i + 1
		if l:
			ini = l[0].start
			last = l[-1].start + l[-1].size
			if last < self.stop:
				l.append(Part(last, self.stop - last, MISSING_BIT))
				last = self.stop
			n = sum([x.size for x in l])
			if n != last - ini:
				Logger.panic('include missing', [p.resume() for p in l], orig)
			assert n == last - ini

	def metadata_only_msgs(self, metadata_always, l, all_parts, start, completeIt):
		if l and not metadata_always:
			mid = (self.start + self.stop) / 2
			if completeIt:
				last = all_parts[-1]
				stop = last.start + last.size
				dif = bl.stop - stop
				if dif > 0:
					all_parts.append(Part(stop, dif, FIL_TYPE))
			self.include_missing(all_parts)
			before = [p for p in all_parts if p.start < mid]
			after = [p for p in all_parts if p.start >= mid]
			if after:
				mid = after[0].start
#				mid = after[0].start
#				while [1 for x in l if x[0] == mid] and before:
					# avoid discarding messages as repeated
#					after.insert(0, before.pop())
#					mid = after[0].start
#				assert before
			else:
				mid = before[-1].start + before[-1].size
			info_before, info_after = self.make_before_after_info(before, after)
			self.test_metadata(mid, all_parts, info_before, info_after)
			if [1 for x in info_before + info_after if not (0 <= x[0] <= 255)]:
				Logger.panic('META LEN', self.parts_info(), start, mid, info_before, info_after)
			msg = metadata_msg(start, mid, info_before, info_after)
			if l == self.msgs:
				tple =  (None, msg, 0, 0)
				self.meta_msg = msg
			else:
				tple = (None, 0, msg)
			l.insert(0, tple)
#			for i in range(1, len(l), 7):
#				l.insert(i, tple) # medatadata >= 1/6 data mgs
		return l

	def test_metadata(self, mid, all_parts, info_before, info_after):
		bl = Block(mid)
		bl.enter_infos(0, mid, info_before, 0, info_after, False)
		p1 = [(p.start, p.size) for p in all_parts]
		p2 = [(p.start, p.size) for p in bl.sorted()]
		if p1 != p2:
			Logger.quitter('metadata starts %d %d stops %d %d parts %s %s mid %d before %s after %s' % (self.start, bl.start, self.stop, bl.stop, p1, p2, mid, info_before, info_after), 1)

	def get_msgs(self, joiner, msgs=None):
		if msgs == None:
			msgs = self.msgs
		return [self.join_multi_msg(x, joiner) for x in msgs]
	
	def join_multi_msg(self, x, joiner):
		if isinstance(x, tuple):
			return self.join_msg(x, joiner)
		msgs = [m[1] for m in self.get_msgs(joiner, x)]
		prio = x[0][0]
		return (prio, multi_msg(msgs))
	
	def join_msg(self, x, joiner):
		prio, header, a, size = x
		s = self.data[a : a + size]
		return (prio, joiner(header, s))

	def trad_missing(self):
		return [x for x in range(0, PARTS_PER_BLOCK) if x not in self.parts]

	def smart_empty(self):
		start, l = self.start, []
		for p in self.sorted():
			if p.start > start:
				l.append((start, p.start - start))
			start = p.start + p.size
		if self.stop > start:
			l.append((start, self.stop - start))
		return l

	def smart_missing(self, buffer, i, generate=True):
		if len(self.parts) == 1 and not self.parts.values()[0].size and generate:
			start, stop = buffer.expected_start_stop(i)
			return [(start, stop - start)]
		l = [x.resume() for x in self.sorted() if x.is_missing()]
		if generate:
			l = l + self.smart_empty()
		return l

	def trad_is_complete(self, buffer, i):
		return not self.trad_missing()

	def smart_is_complete(self, buffer, i):
		return not self.smart_missing(buffer, i)

	def is_available(self):
		return not not self.msgs

	def trad_joined(self, buffer, i, ignorable):
		for j in self.trad_missing():
			buffer.trad_lost(ignorable, i, j)
		return self.data

	def smart_joined(self, buffer, i, ignorable, metadata_always):
		parts = self.sorted()
		if parts[0].start != self.start:
			Logger.panic('start doesnt match', self.full_info(buffer, i))
		if metadata_always:
			assert parts[0].start == self.start
		else:
			assert parts[0].start == self.start or not self.got_meta
		removed = []
		while parts and parts[0].start < self.start:
			p = parts.pop()
			removed.append(p.info())
			del self.parts[p.start]
		if removed:
			Logger.panic(i, self.start, 'unproper parts', removed)
		safe2generate = False # len(self.parts) > 1 or self.parts.values()[0].size
		for start,size in self.smart_missing(buffer, i, safe2generate):
			if start in self.parts:
				p = self.parts[start]
			else:
				assert size
				p = Part(start, size, 0)
			buffer.smart_lost(ignorable, start, size, p.dataType, p.weight())
		return (self.start, self.data)

	def full_weight(self):
		return sum([x.weight() for x in self.parts.values()])

	def select_offsets(self, offsets, buffer, i, params):
		if buffer.is_header(i):
			return offsets
		if params == DEFAULT_SELECT_ALGO:
			return self.serviso_select(offsets, buffer, i)
		# ADAPTIVE: process params according to self.nack_count
		return self.mkfirm_select(offsets, buffer, i, params)

	def element_w_weight(self, x):
		if isinstance(x, tuple):
			start, size = x[:2]
		else:
			start, size = x.start, x.size
		p = self.part(start)
		if not p:
			p = Part(start, size, 0)
		return start, size, p.weight()

	def groups_of_size(self, l, size):
		res = []
		while l:
			res.append(l[:size])
			l = l[size:]
		return res

	def mkfirm(self, all, offsets, top, bottom, size):
		selected = []
		some = [x for x in all if bottom <= x[2] < top]
		groups = self.groups_of_size(some, size)
		for grp in groups:
			missing = [x for x in grp if x[:2] in offsets]
			if len(missing) > 1:
				missing.pop()
				selected = selected + missing
		return selected

	def mkfirm_select(self, offsets, buffer, i, grpsz):
		if not self.got_meta:
			return offsets
		all = [self.element_w_weight(x) for x in self.parts_incl_missing()]
		always = [x for x in offsets if self.element_w_weight(x)[2] >= 3]
		# ignore grpsz[0], since Is are always NACKed
		mid = self.mkfirm(all, offsets, 3, 2, grpsz[1])
		low = self.mkfirm(all, offsets, 2, 1, grpsz[2])
		return [x[:2] for x in always + mid + low]

	def serviso_select(self, offsets, buffer, i):
		l = []
		candidates = []
		w_tot = w_got = self.full_weight()
		bytes_missing = 0
		before = [w_tot]
		for x,size in offsets:
			p = self.part(x)
			if not p:
				while size > MAX_DESL:
					p = Part(x, MAX_DESL, 0)
					w1 = p.weight()
					w_got = w_got - w1
					candidates.append((p.start, p.size, w1))
					bytes_missing = bytes_missing + MAX_DESL
					x,size = x + MAX_DESL, size - MAX_DESL
				p = Part(x, size, 0)
			w1 = p.weight()
			w_got = w_got - w1
			if w1 < 3: #1 <= w1 < 3: # 100% playback requires 0-weight-NALUs
				candidates.append((p.start, p.size, w1))
				bytes_missing = bytes_missing + size
			else:
				w_got = w_got + w1
				if w1 >= 3:
					l.append((x, size))
		candidates.sort(key=lambda x: x[2])
		before = before + [w_got, w_tot, bytes_missing]
		while candidates and ((w_got / w_tot < buffer.get_acceptable_rate(self.nack_count)) or (buffer.block_size - bytes_missing < buffer.get_available_size(self.nack_count))):
			x = candidates.pop()
			l.append((x[0], x[1]))
			w_got = w_got + x[2]
			bytes_missing = bytes_missing - x[1]
		if candidates:
			candidates.sort(key=lambda x: x[0])
			Logger.dbg(6, i, 'acceptable', w_got / w_tot, 'missing', bytes_missing, 'before', before, 'ignoring', candidates)
#		overflow = [x for x in l if sum(x[:2]) > self.stop]
#		for x in overflow:
#			l.remove(x)
#			l.append((x[0], self.stop - x[0]))
		return l

	def nacked(self):
		self.nack_count = self.nack_count + 1
