# Carlos Eduardo Lenz - PPGCC - UFSC
from copy import copy
from random import choice
from time import time

from Logger import Logger
from Message import metadata_msg, nack_msg, nack_msg2, qnack_msg, MAX_DESL, METADATA_ID, QDATA_ID, QNACK_ID
from Network import CONTROL_MSG_LIMIT
from Part import Part
from Scheduler import DEFAULT_TIMEOUT
from Window import Window, SINGLE_BITS
from util import group_offsets, join_offsets, split_offset
	
DEFAULT_ELAPSED = DEFAULT_TIMEOUT * 1.8 # 720 ms

class NackControl:
	def __init__(self, buffer, network, starter, isSmart, doNack, metadata_always):
		self.buffer = buffer
		self.network = network
		self.starter = starter
		self.elapsed_time = DEFAULT_ELAPSED
		self.available = set([])
		self.timeout = DEFAULT_TIMEOUT
		self.do_nack = doNack
		self.metadata_always = metadata_always
		if doNack:
			self.next = 0
		else:
			self.next = time() + 7 * 24 * 60 * 60 # in 1 week (disabled)
		if isSmart:
			self.request_metadata = self.request_metadata_smart
			self.sender = self.smart_send_nack
			self.desperate_nack = self.smart_desperate
			self.selector = self.select_offsets
		else:
			self.request_metadata = lambda hi,i: None
			self.sender = self.trad_send_nack
			self.desperate_nack = self.trad_desperate
			self.selector = self.select_all
	
	def __call__(self, tm):
		if tm >= self.next:
			target = self.find_target()
			available = self.check_all(target)
			self.check_available(available, tm)

	def find_target(self):
		target = self.buffer.missing_limits()[1]
		missing = self.buffer.missing()
		if missing:
			target = missing[-1] # max(sorted list) => last
			if len(missing) == 1:
				target = target + 1
		return target
	
	def check_all(self, target):
		available = []
		tm = time()
		for hi in self.network.partners():
			self.check(hi, target, tm)
			available = available + hi.available
		return available
	
	def check_available(self, l, tm):
		available = set(l)
		if available  != self.available:
			for x in sorted(self.available - available):
				Logger.statAvail(x, False, False) # not anymore
			for x in sorted(available - self.available):
				Logger.statAvail(x, True, False) # new
			self.available = available
			Logger.dbg(4, 'reachable', sorted(available))
		self.next = tm + self.timeout

	def complete(self, hi, i):
		if self.buffer.make_available(i):
			self.starter()
	
	def clear_read_partials(self, hi):
		for q in range(max(0, self.buffer.index() - 5), self.buffer.index()):
			if q in hi.partial_transfers or q in hi.nacked:
				self.rm_partial('past', hi, q)

	def request_metadata_smart(self, hi, i):
		if not self.metadata_always and not self.buffer.get(i).got_meta and self.buffer.is_within_limits(i):
			start = self.buffer.expected_start_stop(i)[0]
			msg = metadata_msg(start, start)
			return self.network.request_metadata(hi, i, msg)
		return False

	def rm_partial(self, msg, hi, i, sureComplete=False):
		if self.request_metadata(hi, i):
			return
		hi.remove_partial(i)
		if sureComplete or self.buffer.is_enough(i):
			if self.buffer.is_within_limits(i):
				self.complete(hi, i)
			elif i < self.buffer.window_limits()[0] - 1 < self.buffer.read_index:
				Logger.panic('cant complete', i, self.buffer.window_limits(), msg)
		Logger.dbg(2, hi.address, 'rm_partial', i, sureComplete, msg)

	def incoming(self, hi, i, offset, kind, info):
		is_qdata = kind == QDATA_ID
		self.request_metadata(hi, i)
		tm = time()
		if self.buffer.is_complete(i) and not kind == METADATA_ID:
			self.rm_partial('incoming complete', hi, i, True)
		else:
			if i >= self.buffer.read_index:
				self.buffer.get(i).msgs = []
			if hi.is_partner() and not is_qdata:
				hi.partial_transfers[i] = tm
			elif self.buffer.is_enough(i):
				self.rm_partial('enough', hi, i, True)

	def check_previous(self, hi, tm):
		current_sched = set(hi.sched)
		recent = self.next - 0.8 * self.timeout
		elder = self.next - self.elapsed_time
		for i in sorted(current_sched.intersection(hi.prev_sched)):
			if i not in hi.partial_transfers:
				ahead = [j for j in hi.partial_transfers if j > i]
				if not ahead or [1 for j in ahead if hi.partial_transfers[j] > recent] or len([1 for j in ahead if hi.partial_transfers[j] < elder]) == ahead:
					# none ahead, something new, all antique
					Logger.maniac(3, hi.address, 'segment entirely lost', i)
					hi.partial_transfers[i] = 0
					break
		hi.prev_sched = current_sched
	
	def check_not_available(self, hi):
		removed = []
		header_size = self.buffer.header_size()
		window_size = self.buffer.window.size
		for i in sorted(hi.partial_transfers):
			if not hi.has_it(i, header_size, window_size):
				self.rm_partial('hasnt anymore', hi, i)
				removed.append(i)
		if removed:
			Logger.maniac(8, hi.address, 'unavailable', removed)
				
	def check(self, hi, i, tm):
		self.clear_read_partials(hi)
		self.check_not_available(hi)
		self.check_previous(hi, tm)
		self.check_partial(hi, i, tm)

	def remove_late(self, hi):
		index = self.buffer.index()
		for j in sorted(hi.partial_transfers):
			if j < index:
				self.rm_partial('too late %s' % self.buffer.missing_parts(j), hi, j)
			else:
				break

	def remove_old_nacks(self, hi, limit):
		old_nack = []
		def when(x):
			if x in hi.partial_transfers:
				hi.nacked[x] = max(hi.nacked[x], hi.partial_transfers[x])
			return hi.nacked[x]
		for j in [x for x in hi.nacked if when(x) < limit]:
			if j in hi.partial_transfers:
				del hi.nacked[j]
				if not self.buffer.is_available(j) and self.buffer.is_ahead(j):
					hi.partial_transfers[j] = 0
					old_nack.append(j)
				else:
					self.rm_partial('available_or_behind', hi, j)
		if old_nack:
			Logger.maniac(8, 'old nacks', old_nack)

	def elapsed_partials(self, hi, top, limit):
#		return [x for x in range(self.buffer.index(), top) if x in hi.partial_transfers and hi.partial_transfers[x] < limit]
		most_recent, l = 0, []
		for i in sorted(hi.partial_transfers, reverse=True):
			t = hi.partial_transfers[i]
			if t > most_recent:
				most_recent = t
				if t > limit:
					continue
			l.append(i)
		return l

	def find_elapsed(self, hi, i, limit):
		r = self.elapsed_partials(hi, i, limit)
		elapsed = []
		for j in [x for x in r if x not in hi.nacked]:
			if not self.buffer.is_available(j):
				msg = 'bug: why did I go into the logs?'
				if self.buffer.is_ahead(j):
					parts = self.buffer.missing_parts(j)
					if parts:
						elapsed.append((j, parts))
						continue
					else:
						msg = 'no missing parts'
				else:
					msg = 'not ahead'
				self.rm_partial(msg, hi, j, True)
		elapsed.sort()
		return elapsed

	def check_partial(self, hi, i, tm):
		self.remove_late(hi)
		delay = self.elapsed_time
#		rtt = self.network.myself.destination(hi.address).round_trip_time
#		if rtt:
#			delay = min(delay, max(10 * rtt, self.elapsed_time / 2))
		limit = tm - delay
		self.remove_old_nacks(hi, limit)
		elapsed = self.find_elapsed(hi, i, limit)
		block_nums = self.sender('partial %d' % i, hi, elapsed, self.selector)
		for q in block_nums:
			Logger.statNack(q)
			self.buffer.nack(q)
		self.mark(hi, block_nums, tm)

	def trad_send(self, node, elapsed, f=nack_msg):
		l = []
		q = elapsed[0][0]
		block_nums = []
		for x in elapsed:
			base = (x[0] - q) * 8 + q
			for y in x[1]:
				l.append(base + y)
			if x[1]:
				block_nums.append(x[0])
		_, bmap = Window.list_to_bmap(l, q)
		self.network.send_info(node.address, f(q, bmap))
		return block_nums

	def smart_send(self, node, offsets, f=nack_msg2, i=None):
		self.fix_overlapping(offsets)
		if sum([x[1] for x in offsets]) > 2 * self.buffer.block_size:
			Logger.panic('NACK', offsets)
			# return False
		msg = f(offsets)
		if len(msg) > CONTROL_MSG_LIMIT:
			info = None
			if i:
				info = self.buffer.get(i).full_info(self.buffer, i)
			Logger.panic('BIG CTRL', offsets, info)
			assert False
		self.network.send_info(node.address, msg)
		return True

	def fix_overlapping(self, l):
		i = 1
		while i < len(l):
			prev, this = l[i - 1 : i + 1]
			stop, start, size = sum(prev[:2]), this[0], this[1]
			if stop > start: # should check Block.parts
				size = size - (stop - start)
				del l[i : i + 1]
				i = i - 1
				if size > 0:
					l[i] = (prev[0], prev[1] + size)
			i = i + 1

	def trad_send_nack(self, reason, hi, elapsed, *ignore):
		if elapsed:
			# to reuse list_to_bmap first you need to convert parts-list to the similar block-list
			Logger.dbg(6, hi.address, 'elapsed', elapsed, reason)
			return self.trad_send(hi, elapsed)
		return []
	
	def detect_abnormalities(self, i, offsets, other, code, f=Logger.quitter):
		if [1 for x in offsets if not (0 <= x[1] <= MAX_DESL)]:
			bl = self.buffer.get(i)
			f('ERROR: offset size %d %s %s %s %s' % (i, offsets, bl.full_info(self.buffer, i), other, code), 1)
			return True
		return False
	
	def smart_send_nack(self, reason, hi, elapsed, f):
		block_nums, ignored = [], []
		for i,offsets in elapsed:
			rm_msg, sureComplete = 'none selected', True
#			self.detect_abnormalities(i, offsets, None, 'straight missing parts', Logger.high)
			if sum([x[1] for x in offsets]) > 2 * self.buffer.block_size:
				Logger.panic('ELAPSED', offsets, self.buffer.get(i).full_info(self.buffer, i))
				assert False
			selected = f(i, offsets)
			selected.sort(cmp=lambda a,b: cmp(a[0], b[0]))
			if selected:
				if self.buffer.is_available(i):
					Logger.panic('NACK or available?', i, offsets)
				if sum([x[1] for x in selected]) > 2 * self.buffer.block_size:
					Logger.panic('SELECT', selected, offsets, self.buffer.get(i).full_info(self.buffer, i))
					assert False
				if self.detect_abnormalities(i, selected, offsets, 'after selection'):
					return []
				present, marked, missing = self.missing_or_not(i, selected)
				if missing:
					if sum([x[1] for x in missing]) > 2 * self.buffer.block_size:
						Logger.panic('MISSING', missing, (marked, present), selected, offsets, self.buffer.get(i).full_info(self.buffer, i))
						assert False
					self.smart_send(hi, missing, i=i)
				target = None
				if marked:
					if sum([x[1] for x in marked]) > 2 * self.buffer.block_size:
						Logger.panic('MARKED', marked, (missing, present), selected, offsets, self.buffer.get(i).full_info(self.buffer, i))
						assert False
					l = [x for x in self.network.partners() if i in x.available]
					if l:
						otherhi = choice(l)
						self.smart_send(otherhi, marked, qnack_msg)
						target = otherhi.address
				if missing or (marked and target):
					self.request_metadata(hi, i)
					block_nums.append(i)
				Logger.dbg(6, hi.address, 'elapsed', i, 'missing', missing, 'present', present, 'marked', marked, 'target', target, reason)
				continue
			self.rm_partial(rm_msg, hi, i, sureComplete)
			ignored.append(i)
		if ignored:
			Logger.dbg(6, 'ignore past', ignored)
		return block_nums
	
	def missing_or_not(self, i, selected):
		bl = self.buffer.get(i)
		def is_marked(j):
			p = bl.part(j[0])
			return p and p.marked_missing()
		lmarked = [j for j in selected if is_marked(j)]
		def is_present(j):
			p = bl.part(j[0])
			return p and not p.is_missing()
		lnot = [j for j in selected if is_present(j)]
		tmp = lnot + lmarked
		lmissing = [j for j in selected if j not in tmp]
		return lnot, lmarked, lmissing
	
	def mark(self, hi, block_nums, tm):
		for i in block_nums:
			hi.nacked[i] = tm

	def select_all(self, i, offsets):
		return offsets

	def select_offsets(self, i, offsets):
		bl = self.buffer.get(i)
		return bl.select_offsets(offsets, self.buffer, i, self.buffer.select_algo)

	def desperate(self, i):
		parts = self.buffer.missing_parts(i)
		selected = self.selector(i, parts)
		header_size = self.buffer.header_size()
		window_size = self.buffer.window.size
		partners = [node for node in self.network.partners() if node.has_it(i, header_size, window_size)]
		if selected and partners:
			sent = self.desperate_nack(i, selected, partners)
			Logger.dbg(6, 'desperate', i, parts, sent)

	def nack_msg_to_q(self, q, bmap):
		s = nack_msg(q, bmap)
		return chr(QNACK_ID) + s[1:]

	def trad_desperate(self, i, parts, partners):
		sent = []
		for j in parts:
			p = choice(partners)
			self.trad_send(p, [(i,[j])], self.nack_msg_to_q) # could be optimized
			sent.append((p.address, j))

	def smart_desperate(self, i, parts, partners):
		if len(parts) == 1:
			start, size = parts[0]
			grouped, offsets = split_offset(start, size, self.buffer.part_size), []
		else:
			offsets = join_offsets(parts, self.buffer.part_size)
			if not offsets:
				Logger.panic('parts', parts, 'offsets', offsets)
			grouped = group_offsets(offsets, self.buffer.part_size)
			if not offsets:
				Logger.panic('offsets', offsets, 'grouped', grouped)
		sent = []
		for l in grouped:
			if not l:
				Logger.panic('parts', parts, 'offsets', offsets, 'grouped', grouped)
			else:
				p = choice(partners)
				l.sort()
				self.smart_send(p, l, qnack_msg)
				sent.append((p.address, l))
		if sent:
			p = choice(partners)
			self.request_metadata(p, i)
			Logger.statNack(i)
			self.buffer.nack(i)
		return sent

	@staticmethod
	def decode(s):
		for c in s:
			q = ord(c)
			yield [i for i in range(0, 8) if SINGLE_BITS[7 - i] & q]
	
	@staticmethod
	def decode2(offsets, buffer):
		l = []
		while offsets:
			i = offsets[0][0] // buffer.block_size
			nxt = (i + 1) * buffer.block_size
			tmp = [x for x in offsets if x[0] < nxt]
			offsets = [x for x in offsets if x not in tmp]
			l.append((i, tmp))
		return l
