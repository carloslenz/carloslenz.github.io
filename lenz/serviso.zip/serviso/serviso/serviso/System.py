# Carlos Eduardo Lenz - PPGCC - UFSC
from copy import copy
from sys import argv
from threading import Thread
from time import time, sleep

from Block import Block
from Buffer import Buffer
from Delivery import Delivery
from FileLoader import FileLoader
from Logger import Logger
from Message import DATA_ID, METADATA_ID
from Network import Network
from NackControl import NackControl
from Partnership import PartnershipManager
from Player import Player
from ProcessGroup import ProcessGroup
from Reception import Reception
from Scheduler import Scheduler
from Speaker import Speaker

INFO_TOPS = 3

class System:
	def __init__(self, host, port, config, isServer, isSmart, isTest):
		Logger.high('seconds', config.seconds)
		Logger.high('extraSecs', config.extraSecs)
		self.isSmart = isSmart
		self.isTest = isTest
		self.gossip_chance = config.gossip_chance
		self.path = config.path
		self.playCmd = config.player
		self.network = Network.for_hostname(host, port, config.max_throughput, config.node_limits, config.generous_reply)
		self.network.myself.drop_rate = config.drop_rate
		self.buffer = Buffer(config.map_size, config.window_distance, config.acceptable_ratio, config.acceptable_rate, isSmart, config.make_loader(), self.jumper, config.metadata_always, config.select_algo, config.check_ahead)
		self.buffer.set_block_size(config.block_size)
		self.buffer.set_nalulen(config.nalulen)
		self.delivery = Delivery(self.network, self.buffer, isSmart, config.metadata_always)
		self.speaker = Speaker(self.buffer, self.network, isServer)
		self.nackControl = NackControl(self.buffer, self.network, self.start_player, isSmart, config.do_nack, config.metadata_always)
		self.scheduler = Scheduler(self.network, self.buffer, self.nackControl.desperate, config.desperate_distance)
		self.partnershipManager = PartnershipManager(self.network, self.buffer, config.partner_limits, config.maxRTT, config.leaves_host, config.max_leaves)
		if isServer:
			self.make_a_server()
		else:
			self.make_a_client()
		self.__call__ = self.pGroup
	
	def stats(self, srv_when=0):
		read_index = self.buffer.read_index
		last_block = self.buffer.last_block()
		lost_info = self.buffer.stat_lost()
		apply(self.partnershipManager.loss_info, lost_info)
		todo = self.todo_info()
		sched = self.sched_info()
		self.network.myself.log_stats(read_index, last_block, self.buffer.sum_late, lost_info, todo, sched, srv_when, self.network.count_partners())

	def todo_info(self):
		todo = self.delivery.todo
		if len(todo) > INFO_TOPS:
			todo = len(todo)
		return todo

	def client_sched_info(self):
		sel = self.scheduler.selected
		if len(sel) > INFO_TOPS:
			sel = len(sel)
		return sel

	def make_a_server(self):
		self.loader = FileLoader(self.buffer, self.path, self.isSmart, self.isTest)
		self.player = Player(self.buffer, 4.0)
		self.bmaper = self.set_bmap
		self.dataFun = self.server_data
		self.prepare(self.server_start)
		self.pGroup.set_alt(self.speaker)
		self.sched_info = lambda : []
		self.stop = self.stop_server

	def server_data(self, address, i, offset, b, info, kind):
		self.check_meta(self.network.node(address), i, len(b), kind, info)
		return True

	def server_start(self, srv_when, address):
		self.pGroup.set_loader(self.loader)
		self.start_player()
		self.client_start(srv_when, address)

	def make_a_client(self):
		self.player = Player(self.buffer, 0.33, self.playCmd)
		self.bmaper = self.client_set_bmap
		self.dataFun = self.client_data
		if self.isSmart:
			self.got_data = self.smart_data
		else:
			self.got_data = self.trad_data
		self.prepare(self.client_start)
		self.pGroup.set_alt(self.scheduler, self.nackControl, self.speaker)
		self.sched_info = self.client_sched_info
		self.stop = self.stop_client

	def jump_index(self):
		indexes = [(x.at, x.available) for x in self.network.partners()]
		started = [x for x in indexes if x[0]]
		if len(started) > 2:
			indexes = started
		indexes.sort(reverse=True)
		if len(indexes) == 1:
			indexes.append((indexes[0][0] - 1, []))
		for i in range(1, len(indexes)):
			target, avail = indexes[i - 1]
			if len([1 for q in avail if q > target]) > self.buffer.window.distance / 3:
				return target
		return 0

	def jumper(self):
		if self.buffer.has_header():
			self.player.jump_to(self.jump_index())
	
	def client_data(self, address, i, offset, b, info, kind):
#		self.stats(True)
		l = self.offsets(offset, info[0])
		Logger.dbg(3, address, kind, 'incoming', i, len(b), l)
		if not self.validate(i):
#			if not self.buffer.is_ahead(i):
#				Logger.dbg(3, address, 'not ahead', i, len(b))
#				return True
			node = self.network.node(address)
			is_partial = i in node.partial_transfers or i in node.nacked
			if is_partial:
				is_partial = sorted(set(list(node.partial_transfers) + list(node.nacked)))
			if kind != METADATA_ID:
				Logger.panic(i, is_partial, 'LIMITS', self.buffer.missing_limits(), self.buffer.index(), self.buffer.is_ahead(i), 'r', self.buffer.read_limits(), self.buffer.read_index)
			return not is_partial
		if self.buffer.is_within_limits(i):
			if kind != METADATA_ID and not self.buffer.is_ahead(i) and not self.buffer.get(i).part(offset):
				self.buffer.sum_late = self.buffer.sum_late + len(b)
			self.got_data(address, i, offset, b, info)
			x = self.network.node(address)
			if not self.check_meta(x, i, len(b), kind, info):
				self.nackControl.incoming(x, i, offset, kind, info)
		return True

	def check_meta(self, hi, i, n, kind, info):
		is_meta = kind == METADATA_ID
		if is_meta:
			assert n < 1 and not self.buffer.metadata_always
			if len(info) >= 3 and (info[1] or info[2]):
				Logger.dyn(8, hi.address, 'got Metadata', i, info)
				self.buffer.get(i).got_meta = True
			else:
				msg = self.buffer.get(i).meta_msg
				if msg:
					self.network.send_metadata(hi, i, msg)
				else:
					Logger.dyn(8, hi.address, 'no Metadata', i, info)
		else:
			assert n
		return is_meta

	def client_start(self, srv_when, address):
		self.stats(srv_when)
		self.network.remove_node(address, 'got START')

	def validate(self, i):
		a, b = self.buffer.missing_limits()
		before_dist = 2 * self.buffer.window.distance
		after_dist = 2 * self.buffer.window.map_size
		a, b = a - before_dist, b + after_dist
		c, d = self.buffer.read_limits()
		c, d = c - before_dist, d + after_dist
		return a < i < b or self.buffer.is_header(i) or c < i < d

	def offsets(self, start, sizes):
		l = [start]
		for x in sizes:
			if x < 0:
				x = - x
			start = start + x
			l.append(start)
		return l

	def start_player(self):
		self.pGroup.start_soon(10, self.player)

	def stop_server(self):
		self.network.myself.stop()

	def stop_client(self):
		self.stop_server()
		self.player.stop()

	def was_nacked(self, i, address):
		return self.buffer.get(i).nack_count > 0
		hi = self.network.node(address)
		return i in hi.nacked and (i not in hi.partial_transfers or hi.nacked[i] > hi.partial_transfers[i])

	def trad_data(self, address, i, offset, b, *extra):
		self.buffer.trad_set_offset(i, offset, b, self.was_nacked(i, address))

	def smart_data(self, address, i, offset, b, info):
		self.buffer.set_data(i, offset, b, info, self.was_nacked(i, address))

	def set_bmap(self, address, first, i, bmap):
		self.network.node(address).set_bmap(first, i, bmap)

	def client_set_bmap(self, address, first, i, bmap):
		self.set_bmap(address, first, i, bmap)
		if not self.player.running:
			self.jumper()

	def prepare(self, starter):
		receptionBuffer = None
		if self.isSmart:
			receptionBuffer = self.buffer
		self.reception = Reception(self.network,receptionBuffer, self.dataFun, self.delivery, self.scheduler, self.partnershipManager, starter, self.bmaper, self.gossip_chance)
		self.pGroup = ProcessGroup([self.partnershipManager, self.stats], self.reception, self.delivery, self.buffer)
		self.network.enter_network()
		Logger.high('rendezvous', self.network.rendezvous.myself.address)
		Logger.high('max_throughput', self.network.myself.max_throughput)
		Logger.high('drop_rate', self.network.myself.drop_rate)
		Logger.high('map_size', self.buffer.window.map_size)
		Logger.high('distance', self.buffer.window.distance)
		Logger.high('acceptable_rate', self.buffer.acceptable_rate)
		Logger.high('acceptable_ratio', self.buffer.acceptable_ratio)
		Logger.high('rate_drop', self.buffer.rate_drop)
		Logger.high('size_drop', self.buffer.size_drop)
		Logger.high('metadata_always', self.buffer.metadata_always)
		Logger.high('log_levels', Logger.DEFAULT.levels)
		Logger.high('dbg_levels', Logger.DEFAULT.dbg_levels)
		Logger.high('maniac_levels', Logger.DEFAULT.maniac_levels)
		Logger.high('node_limits', self.network.nodeLimits)
		Logger.high('partner_limits', self.partnershipManager.limits)
		Logger.high('generous_reply', self.network.generousReply)
		Logger.high('do_nack', self.nackControl.do_nack)
		Logger.high('desperate_distance', self.scheduler.desperate_distance)
		Logger.high('maxRtt', self.partnershipManager.maxRTT)
		Logger.high('leavesHost', self.partnershipManager.leavesHost)
		Logger.high('maxLeaves', self.partnershipManager.maxLeaves)
		Logger.high('select_algo', self.buffer.select_algo)
	
	def close(self):
		self.network.leave_network()
		self.__call__ = lambda : None
