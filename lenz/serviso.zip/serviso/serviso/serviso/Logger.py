# Carlos Eduardo Lenz - PPGCC - UFSC
from datetime import datetime
from os import listdir, remove
from os.path import expanduser, isfile, getmtime, join
from sys import stdout
from time import sleep, time

import re

DEFAULT_LOG_LEVELS = range(0,4)
DEFAULT_DBG_LEVELS = range(0,10)
DEFAULT_MANIAC_LEVELS = range(0,10)

DEFAULT_PANICS = 50

class Logger:
	def __init__(self, file, levels, dbg_levels, maniac_levels, statFile, quitter):
		self.panics_countdown = DEFAULT_PANICS
		self.file = file
		self.levels = set(levels)
		self.dbg_levels = set(dbg_levels)
		self.maniac_levels = set(maniac_levels)
		self.inittm = time()
		self.statFile = statFile
		self.quitter = quitter
		if not quitter:
			self.quitter = self.assert_quit
		if statFile:
			self.statSummary = self.statFile.summary
			self.statPartner = self.statFile.partner
			self.statNack = self.statFile.nack
			self.statAvail = self.statFile.avail
			self.statLost = self.statFile.lost
			self.statLate = self.statFile.late
	
	def assert_quit(self, s, ret):
		self.panic(s)
		assert False

	def time(self):
		return time() - self.inittm

	def __call__(self, n, *args):
		tm = self.time()
		if len(args) == 1:
			args = args[0]
		s = '%.4f %d!' % (tm, n)
		if args:
			if n == 5 and args[0] not in self.dbg_levels:
				return
			if n == 6 and args[0] not in self.maniac_levels:
				return
			for x in args:
				if isinstance(x, float):
					x = '%.3f' % x
				s = s + ' ' + str(x)
		self.printit(n, s)
	
	def printit(self, n, s):
		s = s + '\n'
		if self.file:
			self.file.write(s)
			self.file.flush()
		if n in self.levels:
			stdout.write(s)
			stdout.flush()
		if n == 0:
			self.panics_countdown = self.panics_countdown - 1
			if self.panics_countdown < 0:
				self.quitter('Too many panics', 1)

	def close(self):
		if self.file:
			Logger.high('closing...', datetime.now())
			self.file.close()
			self.file = None
		if self.statFile:
			self.statFile.close()

	@staticmethod
	def closeit():
		return Logger.DEFAULT.close()
	
	@staticmethod
	def doit(n, *args):
		return Logger.DEFAULT(n, args)
	
	@staticmethod
	def panic(*args):
		return Logger.DEFAULT(0, args)
	
	@staticmethod
	def high(*args):
		return Logger.DEFAULT(1, args)

	@staticmethod
	def info(*args):
		return Logger.DEFAULT(2, args)

	@staticmethod
	def dyn(*args):
		return Logger.DEFAULT(3, args)

	@staticmethod
	def idbg(*args):
		return Logger.DEFAULT(4, args)
		
	@staticmethod
	def dbg(*args):
		return Logger.DEFAULT(5, args)

	@staticmethod
	def maniac(*args):
		return Logger.DEFAULT(6, args)

	@staticmethod
	def stat(*args):
		return apply(Logger.DEFAULT.statSummary, args)

	@staticmethod
	def statNack(*args):
		return apply(Logger.DEFAULT.statNack, args)

	@staticmethod
	def statPartner(*args):
		return apply(Logger.DEFAULT.statPartner, args)

	@staticmethod
	def statLost(*args):
		return apply(Logger.DEFAULT.statLost, args)

	@staticmethod
	def statAvail(*args):
		return apply(Logger.DEFAULT.statAvail, args)

	@staticmethod
	def statLate(*args):
		return apply(Logger.DEFAULT.statLate, args)

	@staticmethod
	def quitter(*args):
		return apply(Logger.DEFAULT.quitter, args)

def init_time():
	return Logger.DEFAULT.inittm

def reset_time(when=0):
	tm = time() - when
	Logger.high('reset_time', tm, 'before', init_time(), 'now', when)
	Logger.DEFAULT.inittm = tm

def adjust_logger(file, levels, dbg_levels, maniac_levels, port, quitter):
	if not Logger.DEFAULT.file:
		from StatFile import StatFile
		name = ''
		if port:
			name = str(port)
		stat = StatFile(name=name)
		Logger.DEFAULT = Logger(file, levels, dbg_levels, maniac_levels, stat, quitter)
		Logger.high('StatFile', stat.fname)

def file_logger(name, gz=True):
	if Logger.DEFAULT.file:
		return Logger.DEFAULT.file
	try:
		fname, f = expanduser('~/tmp/%s.txt' % name), open
		if gz:
			import gzip
			f = gzip.open
			fname = fname + '.gz'
		clean_dir(expanduser('~/tmp'))
		return f(fname, 'wb')
	except IOError:
		Logger.DEFAULT.panic('log directory missing or not writable')
		exit()

Logger.DEFAULT = Logger(None, DEFAULT_LOG_LEVELS, DEFAULT_DBG_LEVELS, DEFAULT_MANIAC_LEVELS, None, None)

TMP_REMOVABLE_FILES_REX = re.compile('.*.\.(txt|dat).*')

def clean_dir(path):
	now = time()
	for x in listdir(path):
		fname = join(path, x)
		if isfile(fname) and TMP_REMOVABLE_FILES_REX.match(x) and now - getmtime(fname) > 300: # older than 5 min
			remove(fname)
