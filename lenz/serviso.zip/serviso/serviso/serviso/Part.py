# Carlos Eduardo Lenz - PPGCC - UFSC
from math import log10
from struct import pack, unpack

from Logger import Logger
from Message import MAX_DESL

HEADER_TYPE = 255

NONE_TYPE, NON_IDR_TYPE, PARTA_TYPE, PARTB_TYPE, PARTC_TYPE, IDR_TYPE, SEI_TYPE, SPS_TYPE, PPS_TYPE, AU_DELIM_TYPE, END_SEQ_TYPE, END_STR_TYPE, FIL_TYPE, SPSE_TYPE, I_TYPE, P_TYPE, B_TYPE, OTHER_TYPE = range(0, 18)

MISSING_BIT = 1 << 7

SELECTED_BITS = [sum([1 << j - 1 for j in range(1, i)]) for i in range(1, 34)]

NONE_ST, MISSING_ST, HAS_ST = range(0, 3)

ENCODE_FMT = '!HB'

VLOK = VLNT = 0

def valid(kind, s=''):
	if kind != HEADER_TYPE and kind not in range(0, 18):
		global VLNT
		VLNT = VLNT + 1
#		print kind
#		assert False
	else:
		global VLOK
		VLOK = VLOK + 1
#		assert (not s or kind == unpack(ENCODE_FMT, s)[1])

def okrate():
	return VLNT, VLOK, float(VLOK) / (VLOK + VLNT)

class Part:
	def __init__(self, start, size, dataType):
		self.start = start
		self.size = size
		self.status = NONE_ST
		self.set_dataType(dataType)
		if not (0 <= size <= MAX_DESL):
			Logger.panic('PARTSIZE', size, start, dataType)
			raise 'd'

	def set_dataType(self, dataType):
		if dataType != HEADER_TYPE and (dataType & MISSING_BIT):
			dataType = dataType & ~MISSING_BIT
			self.status = MISSING_ST
#		valid(dataType)
		self.dataType = dataType

	def encoded(self, start):
		assert self.start == start
		kind = self.dataType
		if kind != HEADER_TYPE:
			kind = kind & 31
#		valid(kind)
		return start + self.size, pack(ENCODE_FMT, self.size, kind)

	def short_info(self):
		return (self.start, self.size, self.dataType_status())

	def info(self):
		return (self.start, self.size, self.status, self.dataType)
	
	def resume(self):
		return (self.start, self.size)
	
	def dataType_status(self):
		dataType = self.dataType
		if self.status == MISSING_ST:
			dataType = dataType & MISSING_BIT
		return dataType
	
	def make_missing(self):
		self.status = MISSING_ST

	def is_video(self):
		return NON_IDR_TYPE <= self.dataType <= B_TYPE

	def is_blank(self):
		return self.dataType == NONE_TYPE

	def not_yet(self):
		return self.status == NONE_ST

	def is_missing(self):
		return self.status in (NONE_ST, MISSING_ST)
	
	def is_pending(self):
		return self.status == NONE_ST

	def marked_missing(self):
		return self.status == MISSING_ST
		
	def data_at(self, data, x, start):
		return ord(data[x - start])

	def checkDataType(self, nalulen, data, start):
		self.status = HAS_ST
		if self.dataType == HEADER_TYPE:
			return
		importance = 0
		nalu = self.dataType
#		print 'a', nalu, self.start
		if not self.dataType:
			if data:
				header = self.data_at(data, start + nalulen, start)
				nalu = header & 31
				importance = (header >> 5) & 3
#				print 'b', nalu
			else:
				nalu = OTHER_TYPE
		if nalu == 1 or nalu == 5:
			nalu = self.sliceType(nalulen, data, start)
#			print 'c', nalu
			if 9 < nalu < HEADER_TYPE:
				Logger.maniac(8, 'slice?', nalu, self.start)
			if 5 <= nalu < 10: # P* -> P, ...
				nalu = nalu - 5
			if 3 <= nalu < 5: # SP -> P, ...
				nalu = nalu - 3
#			print 'd', nalu
		if 0 <= nalu < 3:
			nalu = nalu + I_TYPE
#			print 'e', nalu
#		if nalu < OTHER_TYPE or nalu > B_TYPE and nalu != HEADER_TYPE:
#			Logger.maniac(8, 'nalu?', nalu, self.start)
		valid(nalu)
		self.dataType = nalu + (importance << 5)
		if not (0 <= self.dataType <= 255):
			Logger.panic('DATA-TYPE', self.dataType, self.start, self.size)
			assert False

	def sliceType(self, nalulen, data, start):
		self.pos = 8 * (start + nalulen + 1)
		def getIt():
			return self.data_at(data, self.pos // 8, start)
		def advance(n):
			self.pos = self.pos + n
		def ignoreReadBits(v, n):
			if 0 < n < 8:
				return v & SELECTED_BITS[8 - n]
			elif -8 < n < 0:
				return v >> (8 + n)
			else:
				return v
		def readBits(n):
			usingBits = self.pos % 8
			if usingBits:
				usingBits = 8 - usingBits
			else:
				usingBits = 8
			value = ignoreReadBits(getIt(), 8 - usingBits)
			advance(usingBits)
			if usingBits < n:
				usingBits = n - usingBits
				while usingBits > 8:
					value = (value << 8) | getIt()
					advance(8)
					usingBits -= 8
				value = (value << usingBits) | ignoreReadBits(getIt(), -usingBits)
				advance(usingBits)
			elif usingBits > n:
				leftBits = usingBits - n
				value = value >> leftBits
				advance(-leftBits)
			return value & SELECTED_BITS[n]
 		def readUev():
			zeroesRead = 0
			while readBits(1) == 0:
				zeroesRead = zeroesRead + 1
			return (1 << zeroesRead) - 1 + readBits(zeroesRead)
		readUev()
		return readUev()

	def weight(self):
		return min(self.size_weight() + self.data_type_weight(), 3)
	
	def data_type_weight(self):
		tp = self.dataType & 31
		if tp == HEADER_TYPE:
			return 3
		elif tp == NON_IDR_TYPE or tp == PARTB_TYPE or tp == PARTC_TYPE or tp == B_TYPE:
			return 1
		elif tp == PARTA_TYPE:
			return 3
		elif tp == IDR_TYPE or tp == I_TYPE:
			return 3
		elif SEI_TYPE <= tp <= PPS_TYPE or tp == SPSE_TYPE: # includes SPS_TYPE
			return 3
		elif AU_DELIM_TYPE <= tp <= FIL_TYPE: # includes END_SEQ_TYPE, END_STR_TYPE
			return 0
		elif tp == P_TYPE:
			return 2
		else: # OTHER_TYPE or unknown
		 return 1.5
	
	def size_weight(self):
		size = max(self.size, 1)
		w = max(10 - log10(size), 0) / 10
		#if w != w: # NaN
		#	Logger.maniac(8, 'NaN', w, size)
		return w

def compare_datatype(a, b):
	missA = missB = False
	if a != HEADER_TYPE and (a & MISSING_BIT):
		a = a & ~MISSING_BIG
#		missA = True
	if b != HEADER_TYPE and (b & MISSING_BIT):
		b = b & ~MISSING_BIG
#		missB = True
	if b == NONE_TYPE:
		return -1
	elif a == NONE_TYPE:
		return 1
	return 0

def compare_part_size(a, b):
	return a - b
