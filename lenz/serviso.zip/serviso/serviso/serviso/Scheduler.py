# Carlos Eduardo Lenz - PPGCC - UFSC
from random import choice
from time import time

from Logger import Logger
from Message import request_msg

DEFAULT_TIMEOUT = 0.4

class Scheduler:
	def __init__(self, network, buffer, desperate, desperate_distance):
		self.network = network
		self.buffer = buffer
		self.desperate = desperate
		self.desperate_distance = desperate_distance
		self.next = 0
		self.selected = []
		self.filter_past_selected = True
		self.filter_past_partial = True

	def heads(self):
		hds = {}
		for hi in self.network.partners():
			if hi.sched:
				for q in hi.sched:
					if not self.buffer.is_available(q):
						hds[hi] = q
						break
		return hds

	def algorithm(self):
		supplier = {}
		target = self.buffer.missing_limits()[1]
		heads = self.heads()
		missing = self.buffer.missing()
		for q in heads.values():
			if q in missing:
				missing.remove(q)
		partners = self.network.partners()
		tm = time()
		if missing:
			target = missing[-1] # max(sorted list) => last
			if len(missing) == 1:
				target = target + 1
			seg_size = self.buffer.block_size
			for x in partners:
				x.time_to_transmit = {}
				i, bmap = x.bmap
				for i in missing:
					x.time_to_transmit[i] = i - self.buffer.read_index
			dup_set = {}
			for i in missing:
				n = 0
				node = None
				header_size = self.buffer.header_size()
				window_size = self.buffer.window.size
				l = [x for x in partners if x.has_it(i, header_size, window_size)]
				n = len(l)
				if n == 1:
					x = supplier[i] = l[0]
					dest = self.network.myself.destination(x.address)
					for j in [q for q in missing if q > i]:
						x.time_to_transmit[j] = x.time_to_transmit[j] - seg_size / x.get_bandwidth(dest)
				elif n != 0:
					entry = (i,l)
					if n in dup_set:
						dup_set[n][i] = l
					else:
						dup_set[n] = { i : l }
#					if n in supplier:
#						del supplier[n]
			for n in sorted(dup_set):
				for i in sorted(dup_set[n]):
					l = [x for x in dup_set[n][i] if x.time_to_transmit[i] > seg_size / x.get_bandwidth(self.network.myself.destination(x.address))]
					if l:
						l.sort(key=lambda a:a.get_bandwidth(self.network.myself.destination(a.address)))
						dest = self.network.myself.destination(l[0].address)
						band = l[0].get_bandwidth(dest)
						l = [x for x in l if x.get_bandwidth(self.network.myself.destination(x.address)) == band]
						x = choice(l)
						dest = self.network.myself.destination(x.address)
						supplier[i] = x
						for j in [q for q in missing if q > i]:
							x.time_to_transmit[j] = x.time_to_transmit[j] - seg_size / x.get_bandwidth(dest)
		for hi in heads:
			supplier[heads[hi]] = hi
		return supplier
	
	def send_bmaps(self, supplier):
		header_size = self.buffer.header_size()
		window_size = self.buffer.window.size
		index = self.buffer.index()
		sel = set([])
		nr_reqs = 0
		partners = self.network.partners()
		allwrong = []
		for x in partners:
			selected = sorted([y for y in supplier if supplier[y] == x])
			if self.filter_past_selected:
				selected = [q for q in selected if q >= index]
			sel = sel.union(selected)
			partial = sorted(x.partial_transfers)
			if self.filter_past_partial:
				partial = [q for q in partial if q >= index]
			got = [q for q in partial if self.buffer.is_available(q)]
			def rm_partial(q):
				if q in x.partial_transfers:
					del x.partial_transfers[q]
					if q in x.nacked:
						del x.nacked[q]
			if got:
				Logger.dbg(2, 'partial or available?', got)
				for q in got:
					rm_partial(q)
				partial = [q for q in partial if q not in got]
			if partial:
				incomplete = [(i, x.partial_transfers[i], self.buffer.missing_parts(i)) for i in partial]
				Logger.maniac(3, x.address, 'expecting', incomplete)
			missing = sorted(set(partial + selected))
			incorrect = []
			for y in missing:
				if not x.has_it(y, header_size, window_size):
					missing.remove(y)
					if y in partial:
						rm_partial(y)
					else:
						x.remove_partial(y)
						incorrect.append(y)
			if incorrect:
				allwrong.append([x.address, incorrect, x.available, [(y, [z.address for z in partners if z.has_it(y, header_size, window_size)]) for y in incorrect]])
			if cmp(missing, x.missed):
				x.scheduled(missing)
				nr_reqs = nr_reqs + len(selected)
				Logger.dbg(4, x.address, 'still', partial, selected)
			msg = apply(request_msg, x.sched_bmap)
			self.network.send_info(x.address, msg)
		if allwrong:
			Logger.panic('INCORRECT', allwrong)
		return nr_reqs, sorted(sel)

	def check_scheduled(self, nr_reqs, sel):
		if cmp(sel, self.selected):
			self.selected = sel
			if sel:
				Logger.dyn(2, 'schedule', nr_reqs, sel)

	def check_stuck_mode(self, nr_reqs):
		if nr_reqs <= self.buffer.window.size * 0.3: # stuck mode
			partners = [p for p in self.network.partners() if p.available]
			maxes = [max(p.available) for p in partners]
			greater = [q for q in maxes if q > self.buffer.missing_limits()[1]]
			# maybe use the greatest of all instead, if it is not too far
			if greater:
				index = sum(greater) / len(greater)
				self.buffer.seek_to(index, partners)

	def mark_unscheduled(self, sel):
		if sel:
			index = self.buffer.index()
			for i in sel:
				self.buffer.set_late(i, False)
			for i in range(index, sel[0]):
				if not self.buffer.is_available(i) and self.buffer.check_late(i):
					self.buffer.set_late(i, True)
					if i > index + self.desperate_distance:
						self.desperate(i)

	def __call__(self, tm):
		if tm >= self.next:
			supplier = self.algorithm()
			nr_reqs, sel = self.send_bmaps(supplier)
			self.check_scheduled(nr_reqs, sel)
			self.mark_unscheduled(sel)
			self.check_stuck_mode(nr_reqs)
			self.next = tm + DEFAULT_TIMEOUT
