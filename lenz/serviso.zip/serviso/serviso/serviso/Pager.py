# Carlos Eduardo Lenz - PPGCC - UFSC
from util import APPLICATION_LOCK

PAGE_SIZE = 5000

class Pager:
	def __init__(self):
		self.pages = {}
		self.current = -1
		self.new_page()
	
	def write(self, line):
		def action():
			l, before = self.pages[self.current], self.current
			l.append(line)
			if sum([len(x) for x in l]) > PAGE_SIZE:
				self.new_page()
			assert self.current in (before, before + 1)
		restrict_access(action)
	
	def flush(self):
		pass

	def new_page(self):
		def action():
			self.current = self.current + 1
			self.pages[self.current] = []
		restrict_access(action)

	def remove(self, i):
		def action():
			if i in self.pages:
				del self.pages[i]
		restrict_access(action)

	def get(self, i):
		def action():
			if i in self.pages:
				return ''.join(self.pages[i])
			return ''
		return restrict_access(action)

def restrict_access(fun, v=None):
	locked = False
	try:
		locked = APPLICATION_LOCK.acquire() # almost instantaneous
		v = fun()
	finally:
		if locked:
			APPLICATION_LOCK.release()
	return v
