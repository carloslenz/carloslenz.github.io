# Carlos Eduardo Lenz - PPGCC - UFSC
from copy import copy
from heapq import heappop, heappush
from math import sqrt
from random import random, Random
from struct import calcsize, pack, unpack
from time import time

from Block import PARTS_PER_BLOCK
from Logger import Logger
from Message import s_format, unpack_s_format, DATA_HEADER2_SIZE, METADATA_ID
from util import correct_time, div_or_zero, joined, not_zero, safe_div, safe_sqrt

SEND_DATA = 1
SEND_FEEDBACK = 2

FEEDBACK_FMT = '!BdffBB'
SEND_DATA_HEADER_FMT = '!BIdH'
SEND_DATA_HEADER_SIZE = calcsize(SEND_DATA_HEADER_FMT)

DEFAULT_PACKET_SIZE = 70000

MAX_TRANSFER_MEMORY = 12000

DEFAULT_RENDEZVOUS_PORT = 14519

BIG_R_SAMPLE = 0.5
BIG_QUEUE = 5

Q = 0.9
Q2 = Q
T_MBI = 64
W = [1.0 for x in range(0, 4)] + [1 - (i - 3) / 5 for i in range(4, 8)]

SPEEDUP_FACTOR = 1

def fp(p):
	return sqrt(2.0 * p / 3) + (12 * sqrt(3.0 * p / 8)) * p * (1 + 32 * pow(p, 2))

FP = [fp(p / 100.0) for p in range(0, 101)]

TOO_LONG = 0.07

# implements the TRFC protocol
class Destination:
	def __init__(self, address):
		self.address = address
#		self.rnd = Random()
		self.next_transfer = self.initial = self.mark = time()
		self.r_sqmean = self.r_sample = 1
		self.throughput = default_packet_size()
		self.receiver_history = {}
		self.time_last_doubled = self.first_packet = self.last_packet = -1
		self.lost_detected = []
		self.loss_history_events = []
		self.packets_per_interval = []
		self.p = self.nofeedback_limit = self.received_packet_size = None
		self.got_data_packets = False
		self.transfered = set([])
		self.x_recv = self.accepted = self.dropped = self.lost50_report = self.lost50 = self.byte_count_stat = self.byte_count = self.recent_count = self.round_trip_time = self.packet_count_stat = self.packet_count = self.throughput_receive = self.loss_rate = self.overhead = self.control = self.clock_diff = 0
		self.queue = []
		self.drops = []

	def wants_to_send(self):
		return self.next_transfer < time() and self.queue

	def push_msg(self, msg, prio):
		if prio and [x[1] for x in self.queue if x[0] == prio]:
			Logger.idbg(7, self.address, 'repeated', prio - 1)
		else:
			if not prio and ord(msg[0]) == METADATA_ID:
				s = msg[:DATA_HEADER2_SIZE]
				l = [x for x in self.queue if x[:DATA_HEADER2_SIZE] == s]
				if l:
					for x in l:
						self.queue.remove(x)
					Logger.idbg(7, self.address, 'meta repeat', len(l))
			heappush(self.queue, (prio, msg))

	def pop_msg(self):
		return heappop(self.queue)

	def queue_size(self):
		n = len([1 for prio,msg in self.queue if prio])
		n0 = len(self.queue) - n
		return (n0, n)
	
	def queue_info(self):
		return 'queue %d %d' % self.queue_size()

	def stats(self):
		l1, l2 = self.net_loss(), self.total_loss()
		recent_x = int(self.recent_throughput())
		Logger.dbg(9, 'dtat', self.address, correct_time(self.next_transfer), 'x', int(self.throughput), int(self.throughput_inst()), int(self.session_throughput()), recent_x, 'ps', self.packet_size_stat(), 'rtt', self.round_trip_time, 'p', self.loss_rate, 'bc', self.byte_count_stat, 'overhead', self.overhead, 'control', self.control, self.queue_info(), 'loss50', l1, l2)
		self.mark = time()
		self.recent_count = 0
		return (l1, l2, self.address, self.round_trip_time, self.queue_size()[1], self.loss_rate, recent_x)

	def percentile_loss(self, a):
		return 0 # disabled: broken and dont have time to fix
		if not self.packet_count:
			return 0
		denom = min(50, self.packet_count)
		num = max(0, a)
		if num > denom or num < 0:
			Logger.panic(self.address, 'LOSS PERCNT', a, self.packet_count, self.drops, self.lost50_report)
			num = denom
		x = float(num) / denom
		x = int(round(100 * x))
		if not (0 <= x <= 100):
			Logger.quitter('%s %d NOT IN [0, 100]' % (self.address, x, a, self.packet_count, self.drops, self.lost50_report), 1)
		return x

	def net_loss(self):
		return 0 #self.percentile_loss(self.lost50_report - len(self.drops))

	def total_loss(self):
		return div_or_zero(self.dropped, self.accepted + self.dropped) #self.percentile_loss(self.lost50_report)

	def drop_control(self, rate, isTFRC):
		if rate > 0:
#			rate = rate + 1.1 * (rate - self.total_loss())
			#2 * rate - self.total_loss()
			#self.net_loss() / 100
#			first = self.packet_count - 50
#			self.drops = [x for x in self.drops if x >= first]
			if rate > random(): #self.rnd.random():
#				if isTFRC:
#					self.drops.append(self.packet_count - 1)
#				self.dropped = self.dropped + 1
				return True
#		self.accepted = self.accepted + 1
		return False

	def receiver_guess_rtt(self):
		if len(self.receiver_history) < 10:
			return 0
		halves = []
		# doesnt work because timestamps are generated in different machines w/out clock synchronization
		for s_m in self.receiver_history:
			timestamp, _, _, receive_timestamp = self.receiver_history[s_m]
			halves.append(receive_timestamp - timestamp)
		return 2 * sum(halves) / len(halves)

	def receive(self, msg, receive_timestamp, buffer):
		msgType = ord(msg[0])
		n = len(msg)
		if msgType == SEND_DATA:
			Logger.maniac(5, self.address, 'TFRC in', n - SEND_DATA_HEADER_SIZE)
			msg = self.decode_data_msg(msg)
			self.receive_data(receive_timestamp, msg[0], msg[1], msg[2] / 1000.0, len(msg[3]), buffer)
			msg = msg[3]
		elif msgType == SEND_FEEDBACK:
			msg = self.decode_feedback_msg(msg)
			self.receive_feedback(receive_timestamp, msg[0], msg[1], msg[2], msg[3], msg[4])
			return None
		return msg, self.address

	def decode_data_msg(self, s):
		return unpack_s_format('!BIdH', s)[1:]

	def decode_feedback_msg(self, s):
		return unpack(FEEDBACK_FMT, s)[1:]
	
	def clock(self):
		return time() + self.clock_diff
	
	def record_transfer(self, pos, n):
		self.packet_count = self.packet_count + 1
		self.byte_count = self.byte_count + n
		self.packet_count_stat = self.packet_count_stat + 1
		self.byte_count_stat = self.byte_count_stat + n
		self.recent_count = self.recent_count + n
		if pos != 0:
			if pos in self.transfered:
				self.overhead = self.overhead + n
				return n
			else:
				self.transfered.add(pos)
				if len(self.transfered) > MAX_TRANSFER_MEMORY:
					self.transfered.remove(min(self.transfered))
		return 0
	
	def inst_delay(self, n):
		inst = self.throughput_inst()
		return safe_div(n, inst)
	
	def reply_len(self, n):
		n = n + SEND_DATA_HEADER_SIZE
		delay = self.inst_delay(n)
		self.next_transfer = self.next_transfer - delay
		#self.overhead = self.overhead + n

	def encode_data_msg(self, s, pos, max_throughput):
		fmt = SEND_DATA_HEADER_FMT + s_format(s)
		tstamp = time()
		rtt = int(self.round_trip_time * 1000) # up to 64 sec
		msg = pack(fmt, SEND_DATA, self.packet_count, tstamp, rtt, s)
		n = len(msg)
		overhead = self.record_transfer(pos, n)
		delay = self.inst_delay(n) / SPEEDUP_FACTOR
		if not self.next_transfer:
			self.next_transfer = tstamp
		inst = self.throughput_inst()
		delay = safe_div(n, min(inst, max_throughput))
		self.next_transfer = min(tstamp + 0.9, max(tstamp - 0.5, self.next_transfer + delay))
		if not self.nofeedback_limit:
			self.nofeedback_limit = time() + 2
		return msg, overhead

	def send_feedback(self, seq_num, timestamp, receive_timestamp, host):
		self.calculate_lost50()
		if seq_num < self.lost50:
			Logger.quitter('FEEBACK %d %d %s' % (seq_num, self.lost50, list(self.receiver_history)), 1)
		msg = self.encode_feedback_msg(timestamp, receive_timestamp)
		self.packet_count_stat = self.packet_count_stat + 1
		self.byte_count_stat = self.byte_count_stat + len(msg)
		host.send_encoded(self, msg, False)
		self.got_data_packets = False

	def encode_feedback_msg(self, timestamp, receive_timestamp):
		delay = time() - receive_timestamp
		Logger.maniac(2, self.address, 'send feedback', delay, 'tstamp', (timestamp, receive_timestamp), 'X_RECV', self.x_recv, 'P', self.p, 'lost50', self.lost50)
		return pack(FEEDBACK_FMT, SEND_FEEDBACK, timestamp, delay, self.x_recv, self.p, self.lost50)
	
	def receive_data(self, receive_timestamp, seq_num, timestamp, round_trip_time, bytes, host):
		self.got_data_packets = True
		self.clock_diff = receive_timestamp - (timestamp + round_trip_time / 2)
		if seq_num > self.last_packet:
			self.last_packet = seq_num
		if seq_num > self.first_packet:
			self.receiver_history[seq_num] = (timestamp, round_trip_time, bytes, receive_timestamp)
		if self.p == None:
			self.p = 0
			self.x_recv = 0
			self.send_feedback(seq_num, timestamp, receive_timestamp, host)
			self.feedback_timer = receive_timestamp + round_trip_time
		p_prev = self.p
		self.update_p() 
		if self.p > p_prev:
			self.expire_feedback_timer(host)
		
	def update_p(self):
		tm1 = time()
		self.detect_lost()
		tm2 = time()
		self.calculate_events()
		tm3 = time()
		self.clean_up_old_info()
		tm4 = time()
		self.calculate_packets_per_interval()
		tm5 = time()
		self.calculate_p()
		tm6 = time()
#		self.calculate_lost50()
		tm7 = time()
		tm1, tm2, tm3, tm4, tm5, tm6, tm7 = tm2 - tm1, tm3 - tm2, tm4 - tm3, tm5 - tm4, tm6 - tm5, tm7 - tm6, tm7 - tm1
		if tm6 > TOO_LONG:
			Logger.maniac(1, 'UPDATE_P', tm7, 'lost', tm1, 'events', tm2, 'cleanup', tm3, 'interval', tm4, 'calculate', tm5, 'lost50', tm6)
	
	def detect_lost(self):
		# doesnt check wrapped seq_nums
		tm1 = time()
		self.lost_detected = []
		received = sorted(self.receiver_history)
		all_received = set(received)
		if received:
			check_before = 0
			a = received.pop()
			while received:
				b = received.pop()
				if a == b + 1 and received:
					c = received.pop()
					if b == c + 1:
						check_before = c
						break
					else:
						a = c
				else:
					a = b
			first = self.first_packet + 1
			s_before = None
			s_after_pair = []
			tm2 = time()
			for s_loss in range(first, check_before):
				if s_loss not in self.receiver_history:
					while s_after_pair:
						if s_after_pair[0] <= s_loss:
							s_after_pair.pop(0)
						else:
							break
					if len(s_after_pair) < 2:
						for j in xrange(s_loss + 1, check_before + 2):
							if j in self.receiver_history:
								s_after_pair.append(j)
								if len(s_after_pair) > 1:
									break
					t_after, rtt = self.receiver_history[s_after_pair[0]][0:2]
					if s_before != None:
						t_before = self.receiver_history[s_before][0]
						t_loss = t_before + ((t_after - t_before) *  (s_loss - s_before) / (s_after_pair[0] - s_before))
					else:
						t_after_more = self.receiver_history[s_after_pair[1]][0]
						dx = (t_after_more - t_after) / (s_after_pair[1] - s_after_pair[0])
						t_loss = t_after - dx * (s_after_pair[0] - s_loss)
					self.lost_detected.append((s_loss, t_loss, rtt))
				else:
					s_before = s_loss
			tm3 = time()
			tm1, tm2, tm3 = tm2 - tm1, tm3 - tm2, tm3 - tm1
			if tm3 > TOO_LONG / 2:
				Logger.maniac(1, 'DETECT', tm3, 'for', tm2, 'range', (first, check_before), 'history', list(self.receiver_history), 'ini', tm1)
	
	def s_before(self, i, all_received):
		for j in xrange(i - 1, self.first_packet - 1, -1):
			if j in all_received:
				return j
		return None
	
	def s_after_pair(self, i, before, all_received):
		l = []
		for j in xrange(i + 1, before + 2):
			if j in all_received:
				l.append(j)
				if len(l) > 1:
					break
		return l
	
	def calculate_events(self):
		self.loss_history_events = []
		if self.lost_detected:
			l = copy(self.lost_detected)
			s_old, t_old, _ = l.pop(0)
			self.loss_history_events.append(s_old)
			while l:
				s_new, t_new, rtt = l.pop(0)
				if t_old < t_new - rtt:
					s_old, t_old = s_new, t_new
					self.loss_history_events.append(s_old)
	
	def clean_up_old_info(self):
		evts = copy(self.loss_history_events)
		del self.loss_history_events[0: len(self.loss_history_events) - 9]
		if len(self.loss_history_events) == 9:
			first = self.loss_history_events[0]
			s_before = self.s_before(first, self.receiver_history)
			if s_before != None and s_before != self.first_packet:
				for x in range(self.first_packet, s_before):
					if x in self.receiver_history:
						del self.receiver_history[x]
				Logger.maniac(7, 'cleaning receiver_history', self.first_packet, 'upto', s_before, 'events', self.loss_history_events)
				self.first_packet = s_before
	
	def calculate_packets_per_interval(self):
		self.packets_per_interval = []
		if not self.process_first_loss() and self.loss_history_events:
			events = copy(self.loss_history_events)
			b = a = events.pop(0)
			while events:
				b = events.pop(0)
				self.packets_per_interval.append(b - a)
				a = b
			self.packets_per_interval.append(self.last_packet - b)
			self.packets_per_interval.reverse()

	def process_first_loss(self):
		return False
		# this code is disabled because it does not work very well due to
		# small RTT vs. small initial upload rate, resulting in a hi loss estimate
		if len(self.loss_history_events) == 1:
			rtt = self.receiver_history[self.last_packet][1]
			self.calculate_x_recv(rtt)
			limits = (0.95 * self.x_recv, 1.05 * self.x_recv)
			a, b = 0.0001, 1
			p_a = self.throughput_equation(self.received_packet_size, rtt, a)
			p_b = self.throughput_equation(self.received_packet_size, rtt, b)
			Logger.maniac(7, 'limits', limits, 'a', (a, p_a), 'b', (b, p_b))
			if limits[0] <= p_a <= limits[1]:
				c, p_c = a, p_a
			elif limits[0] <= p_b <= limits[1]:
				c, p_c = b, p_b
			elif p_a < limits[0]:
				Logger.maniac(7, 'below limits')
				c, p_c = a, p_a
			elif p_b > limits[1]:
				Logger.maniac(7, 'above limits')
				c, p_c = b, p_b
			else:
				# OBS: throughput_equation is a decrescent function of the loss_rate:p!
				while True:
					c = (a + b) / 2.0
					p_c = self.throughput_equation(self.received_packet_size, rtt, c)
					Logger.maniac(7, 'try', c, p_c)
					if p_c < limits[0]:
						b = c
					elif p_c > limits[1]:
						a = c
					else:
						break
			self.packets_per_interval = [int(round(1 / c))]
			Logger.maniac(7, 'first-loss', self.address, 'rtt', rtt, 'X_RECV', self.x_recv, 'P', (c, p_c), 'n', self.packets_per_interval[0])
			return True

	def calculate_lost50(self):
		first = max(0, self.last_packet - 49)
		self.lost50 = len([1 for x in range(first, self.last_packet) if x not in self.receiver_history])

	def calculate_p(self):
		i_tot0 = i_tot1 = w_tot0 = w_tot1 = 0
		if self.packets_per_interval:
			for i in range(0, min(8, len(self.packets_per_interval))):
				i_tot0 = i_tot0 + self.packets_per_interval[i] * W[i]
				w_tot0 = w_tot0 + W[i]
			i_mean = i_tot0 / w_tot0
			for i in range(1, min(8, len(self.packets_per_interval))):
				i_tot1 = i_tot1 + self.packets_per_interval[i] * W[i - 1]
				w_tot1 = w_tot1 + W[i]
			if w_tot1:
				i_mean = max(i_mean, i_tot1 / w_tot1)
			self.p = int(100 / i_mean) # 0..100
		else:
			self.p = 0
	
	def expire_feedback_timer(self, host):
		s_m = self.last_packet
		timestamp, r_m, _, receive_timestamp = self.receiver_history[s_m]
		if self.got_data_packets:	
			self.update_p()
			self.calculate_x_recv(r_m)
			self.send_feedback(s_m, timestamp, receive_timestamp, host)
		self.feedback_timer = time() + r_m
	
	def calculate_x_recv(self, r_m):
		# calculate x_recv for the packets received on the last r_m seconds
		tm = time()
		a, b = tm - r_m, tm
		self.received_packet_size, self.x_recv, n = self.x_recv_for_range(r_m, a, b)
		if r_m < 0.01: # too small
			ps, xr, nn = self.received_packet_size, self.x_recv, n
			for x in range(0, 4): # try higher rates on the last 4 RTT periods
				a, b = a - r_m, b - r_m
				v = self.x_recv_for_range(r_m, a, b)
				if (v[1] > self.x_recv and v[2] != 0): # or n == 0:
					self.received_packet_size, self.x_recv, n = v
			if n > 0:
				Logger.maniac(7, self.address, 'nr_packets', nn, n, 'rec_ps', ps, self.received_packet_size, 'x_recv', xr, self.x_recv)
		
	def x_recv_for_range(self, r_m, a, b):
		last_ones = [x[2] for x in self.receiver_history.values() if a <= x[0] < b]
		if last_ones:
			bytes = sum(last_ones)
			return (bytes / len(last_ones), bytes / r_m, len(last_ones))
		else: # if none, assume 1 packet/s
			return (default_packet_size(), default_packet_size(), 0)

	def receive_feedback(self, receive_timestamp, timestamp, delay, throughput, loss_rate, lost50):
		self.r_sample = time() - timestamp - delay
		if self.r_sample < 0 or self.r_sample > BIG_R_SAMPLE:
			if self.address[1] != DEFAULT_RENDEZVOUS_PORT:
				Logger.maniac(0, self.address, 'ignoring r_sample', self.r_sample, timestamp, delay)
			self.r_sample = self.round_trip_time
		if self.round_trip_time:
			#self.nofeedback_limit = receive_timestamp + 2 * self.round_trip_time
			self.round_trip_time = Q * self.round_trip_time + (1 - Q) * self.r_sample
			self.r_sqmean = Q2 * self.r_sqmean + (1 - Q2) * safe_sqrt(self.r_sample)
		else:
			self.round_trip_time = self.r_sample
			self.r_sqmean = safe_sqrt(self.r_sample)
		Logger.maniac(2, self.address, 'feedback', timestamp, 'delay', delay, 'r_sample', self.r_sample, 'rtt', self.round_trip_time, 'r_sqmean', self.r_sqmean, 'lost50', lost50)
		self.loss_rate = float(loss_rate) / 100
		self.lost50_report = lost50
		self.throughput_receive = throughput
		self.update_throughput(receive_timestamp)
		self.update_feedback_limit(receive_timestamp)
	
	def throughput_inst(self):
		# preventing oscilations
		return safe_div(self.throughput * self.r_sqmean, safe_sqrt(self.r_sample))

	def update_throughput(self, tnow):
		inst0 = self.throughput_inst()
		ps = self.packet_size()
		if self.loss_rate > 0:
			x_calc = self.tcp_throughput()
			self.throughput = max(min(x_calc, 2 * self.throughput_receive), ps / T_MBI)
			Logger.maniac(9, self.address, 'throughput', int(self.throughput), 'tcp', x_calc, 'receive', self.throughput_receive, 'ps', ps, 'rtt', self.round_trip_time, 'loss', self.loss_rate, 'bc', self.byte_count)
		elif tnow - self.time_last_doubled >= self.round_trip_time:
			self.throughput = max(min(2 * self.throughput, 2 * self.throughput_receive), safe_div(ps, self.round_trip_time))
			self.time_last_doubled = tnow
			Logger.maniac(9, self.address, 'doubled throughput', int(self.throughput), 'receive', self.throughput_receive, 'ps', ps, 'rtt', self.round_trip_time, 'bc', self.byte_count)
		inst1 = self.throughput_inst()
		period0 = self.next_transfer - tnow
		n = period0 * inst0
		period1 = safe_div(n, inst1)
		if period1 < period0: # accelerate next_transfer
			self.next_transfer = tnow + period1
			Logger.maniac(0, self.address, 'inst before', inst0, 'now', inst1, 'gain', period0 - period1)
	
	def packet_size(self):
		if self.packet_count:
			return int(self.byte_count / self.packet_count)
		return default_packet_size()

	def packet_size_stat(self):
		if self.packet_count_stat:
			return int(self.byte_count_stat / self.packet_count_stat)
		return 0
	
	def tcp_throughput(self):
		return self.throughput_equation(self.packet_size(), self.round_trip_time, self.loss_rate)
	
	def session_throughput(self):
		return self.byte_count / (time() - self.initial)
	
	def recent_throughput(self):
		return self.recent_count / (time() - self.mark)
	
	def throughput_equation(self, s, rtt, p):
		rtt,p = not_zero(rtt), not_zero(p)
		return safe_div(s, rtt * self.fp(p))
	
	def fp(self, p):
		return FP[int(p * 100)]
	
	def check_feedback(self, tnow, host):
		self.check_feedback_sender(tnow)
		self.check_feedback_receiver(tnow, host)
	
	def check_feedback_sender(self, tnow):
		if self.nofeedback_limit and tnow > self.nofeedback_limit:
			if self.round_trip_time:
				x_calc = self.tcp_throughput()
				if self.throughput_receive and x_calc > 2 * self.throughput_receive:
					self.throughput_receive = max(self.throughput_receive / 2, self.packet_size() / 2 * T_MBI)
				else:
					self.throughput_receive = x_calc / 4
				self.update_throughput(tnow)
			else:
				self.throughput = max(self.throughput / 2, self.packet_size() / T_MBI)
			self.update_feedback_limit(tnow)
	
	def update_feedback_limit(self, tnow):
		if self.throughput <= 0:
			self.nofeedback_limit = tnow + 4 * self.round_trip_time
			Logger.maniac(9, 'x==0 bc', self.byte_count, 'rtt', self.round_trip_time, 'x_recv', self.throughput_receive)
		else:
			self.nofeedback_limit = tnow + max(4 * self.round_trip_time, safe_div(2 * self.packet_size(), self.throughput))
	
	def check_feedback_receiver(self, tnow, host):
		if self.receiver_history and tnow > self.feedback_timer:
			self.expire_feedback_timer(host)

def default_packet_size():
	return DEFAULT_PACKET_SIZE / PARTS_PER_BLOCK
