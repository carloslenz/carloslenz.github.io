# Carlos Eduardo Lenz - PPGCC - UFSC
from copy import copy
from email.encoders import encode_base64
from email.message import Message
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from math import sqrt
from mimetypes import guess_type
from os import getuid
from os.path import basename, expanduser, isdir
from pwd import getpwuid
from random import uniform
from select import select
from smtplib import SMTP
from socket import error, gethostname, socket, AF_INET, SOCK_DGRAM, SOCK_STREAM, SO_REUSEADDR, SOL_SOCKET, SO_SNDBUF
from subprocess import Popen, PIPE
from sys import argv
from threading import RLock
from time import time
from traceback import format_exc

from Logger import Logger, init_time

APPLICATION_LOCK = RLock()

ANY_NIC = '0.0.0.0'

MSG_LIMIT = 200000 # 200KB

ENV_PYNAME = 'serviso/serviso/environment.py'

MULTI = False

def set_multi():
	global MULTI
	MULTI = True

def not_multi():
	return not MULTI

def not_zero(x):
	return max(x, 0.0001)

def safe_div(a, b):
	return a / not_zero(b)

def safe_sqrt(x):
	if x < 0:
		return 0
	try:
		return sqrt(x)
	except:
		Logger.panic('SQRT', x)
		return 0

def div_or_zero(a, b):
	if b:
		return float(a) / b
	return 0

def joined(l):
	return ' '.join([str(x) for x in l])

def flat(lol):
	l = []
	for x in lol:
		l = l + x # reverses
	return l

def select_one_index(l):
	return int(uniform(0,len(l)))

def correct_time(tm=None):
	if not tm:
		tm = time()
	return tm - init_time()

def join_offsets(offsets, part_size):
	l, offsets = [], copy(offsets)
	start, size = offsets.pop(0)
	for x in offsets:
		if size < part_size and x[0] == start + size:
			size = size + x[1]
		else:
			l.append((start, size))
			start, size = x
	if size:
		l.append((start, size))
	return l

def split_offset(start, size, part_size):
	l = []
	while size > part_size:
		l.append([(start, part_size)])
		start = start + part_size
		size = size - part_size
	if size:
		l.append([(start, size)])
	return l

def group_offsets(offsets, part_size):
	current = []
	l, sum = [], 0
	for start,size in offsets:
		if size > part_size:
			l.append([(start, size)])
		else:
			assert size
			current.append((start, size))
			sum = sum + size
			if sum > part_size:
				l.append(current)
				current, sum = [], 0
	if current:
		l.append(current)
	return l

def strip_nl(line):
	if line and line[-1] == '\n':
		line = line[0:-1]
	return line

def read_file_lines(path):
	path = expanduser(path)
	f = open(path, 'r')
	lines = f.readlines()
	f.close()
	return lines

def non_blocking_socket(kind):
	sock = socket(AF_INET, kind)
	sock.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
	sock.setblocking(0)
	return sock

def tcp_non_blocking_socket():
	return non_blocking_socket(SOCK_STREAM)

def udp_non_blocking_socket():
	sock = non_blocking_socket(SOCK_DGRAM)
	sock.setsockopt(SOL_SOCKET, SO_SNDBUF, 64 * 1024)
	return sock

def bind_socket(sock, port, msg='binding', canChangePort=False):
	while True:
		try:
			Logger.high(msg, port)
			sock.bind((ANY_NIC, port))
			break
		except error:
			if not canChangePort:
				raise
			port = port + 1
	return port

def sendto(sock, msg, address, block=False):
	if block:
		select([], [sock], []) # blocks until it is writable
	try:
		sock.sendto(msg, address)
	except error, v:
		Logger.maniac(1, 'socket error', v)

def mail_error(info=None, l=[], skipl=[]):
	smtp = SMTP('localhost')
	if not info:
		info = format_exc()
	try:
		h = gethostname()
		u = getpwuid(getuid())[0]
		frm = '%s@%s' % (u, h)
		to = 'carlos.lenz@gmail.com'
		subj = 'Error at %s' % h
		cnts = 'CommandLine: "%s"\n%s' % (' '.join(argv), info)
		msg = 'Subject: %s\n%s\n' % (subj, cnts)
		if l:
			def attach(outer, path):
				# Guess the content type based on the file's extension.  Encoding
				# will be ignored, although we should check for simple things like
				# gzip'd or compressed files.
				ctype, encoding = guess_type(path)
				if ctype is None or encoding is not None:
				    # No guess could be made, or the file is encoded (compressed), so
				    # use a generic bag-of-bits type.
				    ctype = 'application/octet-stream'
				maintype, subtype = ctype.split('/', 1)
				fp = open(path)
				data = fp.read()
				fp.close()
				if not data:
					return None
				if len(data) > MSG_LIMIT:
					return 'Too big to send: %s' % path
				if maintype == 'text':
				    # Note: we should handle calculating the charset
				    msg = MIMEText(data, _subtype=subtype)
				else:
				    msg = MIMEBase(maintype, subtype)
				    msg.set_payload(data)
				    encode_base64(msg)
				# Set the filename parameter
				msg.add_header('Content-Disposition', 'attachment', filename=basename(path))
				outer.attach(msg)
				return ''
			msg = MIMEMultipart()
			msg['Subject'] = subj
			msg['From'] = frm
			msg['To'] = to
			for path in l:
				if path not in skipl:
					s = attach(msg, path)
					if s:
						cnts = '%s\n%s' % (cnts, s)
			body = Message()
			body.set_payload(cnts)
			msg.attach(body)
			msg = msg.as_string()
		smtp.sendmail(frm, to, msg)
	except:
		Logger.panic(format_exc())
	finally:
		smtp.quit()

def environment(force=False):
	if not force:
		try:
			from environment import env
			return env()
		except ImportError:
			pass
	cmds = [x.split() for x in ('git diff', 'git log -r -1', 'date')]
	l = []
	for x in cmds:
		l = l + ['> ', ' '.join(x), '\n'] + Popen(x, stdout=PIPE).stdout.readlines()
	return ''.join(l)

def cmd_output(*cmd):
	return Popen(cmd, stdout=PIPE).communicate()[0]

def make_environment():
	pre = 'def env():\n\treturn '
	post = '\n'
	f = open(ENV_PYNAME, 'w')
	f.write(pre)
	f.write(repr(environment(True)))
	f.write(post)
	f.close()

if __name__ == '__main__':
	make_environment()
