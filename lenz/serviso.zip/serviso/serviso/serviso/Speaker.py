# Carlos Eduardo Lenz - PPGCC - UFSC
from random import choice, random

from Host import host_addresses
from Logger import Logger
from Message import bmap_msg, nodes_msg
from Scheduler import DEFAULT_TIMEOUT
from Window import Window, NONE_AVAILABLE

class Speaker:
	def __init__(self, buffer, network, isServer):
		self.buffer = buffer
		self.network = network
		self.server_available = NONE_AVAILABLE
		self.avail = []
		self.next = 0
		self.fair = False # bad when late clients arrive
		if isServer:
			self.action = self.server
		else:
			self.action = self.client
	
	def __call__(self, tm):
		if tm >= self.next:
			self.action()
			self.next = tm + DEFAULT_TIMEOUT
		
	def client(self):
		pos, bmap = self.buffer.block_map()
		start = pos[0]
		msg = bmap_msg(self.buffer.read_index, start, bmap)
		for x in self.network.partners():
			self.network.send_info(x.address, msg)
		avail = Window.bmap_to_list(start, bmap)
		if cmp(avail, self.avail):
			self.avail = avail
			if avail:
				Logger.dbg(0, 'avail', pos, avail)

	def server(self):
		partners = self.network.partners()
		if partners:
			server_available = self.buffer.server_available()
			first = 0
			if server_available:
				first = server_available[0]
			for i in range(max(0, self.server_available[0] - 10), server_available[0]): # off limits
				for x in partners:
					if i in x.server_blk_avail:
						x.server_blk_avail.remove(i)
			avail = reduce(lambda a, b: a|b, [x.server_blk_avail for x in partners])
			for i in range(server_available[0], server_available[1]):
				if i not in avail: # new or orphan (eg: node left)
					if not self.fair:
						targets = [x for x in partners if i not in x.server_blk_avail]
						if len(targets) in (0, 1, 2):
							sel = targets
						else:
							sel = []
							for q in range(0, 2): # select 2 partners
								# don't select the weaker (< blocks) partner 'cause it might be a late client, hurting everyone
								srv = choice(targets)
								targets.remove(srv)
								sel.append(srv)
					else:
						partners.sort(key=lambda x: len(x.server_blk_avail))
						sel = partners[:2] # select 2 partners
					for x in sel:
						x.server_blk_avail.add(i)
			for x in partners:
				avail = sorted(x.server_blk_avail)
				Logger.dbg(0, x.address, 'avail', avail)
				first, bmap = Window.list_to_bmap(avail, first)
				msg = bmap_msg(self.buffer.read_index, first, bmap)
				self.network.send_info(x.address, msg)
			self.server_available = server_available
