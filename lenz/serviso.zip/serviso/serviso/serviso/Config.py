# Carlos Eduardo Lenz - PPGCC - UFSC
from math import ceil
from os.path import dirname, expanduser, getsize, isfile
from socket import gethostbyname

from Block import DEFAULT_SELECT_ALGO
from Buffer import DEFAULT_BLOCK_SIZE
from Host import HOSTNAME
from FileLoader import dummy_loader
from Logger import adjust_logger, file_logger, DEFAULT_LOG_LEVELS, DEFAULT_DBG_LEVELS, DEFAULT_MANIAC_LEVELS
from PageCentral import EmptyPageNodeOrCentral, PageCentral, TcpPageCentral, UdpPageCentral
from PageNode import PageNode, TcpPageNode, UdpPageNode
from Pager import Pager
from util import read_file_lines, strip_nl

VERSION = 'D'

FILE_LOGGER = 'file'
NET_LOGGER = 'net'
TCP_LOGGER = 'tcp'
UDP_LOGGER = 'udp'

DEFAULT_DROP_RATE = 0
DEFAULT_NALULEN = 4
DEFAULT_PATH = '~/samples/senate71c.mp4'
DEFAULT_PLAYER = 'delay 20 ffplay pipe://'
DEFAULT_ACCEPTABLE_RATE = 0.9
DEFAULT_ACCEPTABLE_RATIO = 0.7
DEFAULT_PAGE_CENTRAL = 'localhost'
DEFAULT_MODE = 'TRAD'
DEFAULT_PGSERVER = 'localhost'
DEFAULT_MAX_THROUGHPUT = 4000000 / 8 # 4 mbps
DEFAULT_NODE_LIMITS = (16,32)
DEFAULT_PARTNER_LIMITS = (8,16)
DEFAULT_GENEROUS_REPLY = True
DEFAULT_DO_NACK = True
DEFAULT_MAP_SIZE = 120
DEFAULT_WINDOW_DISTANCE = 5

DISABLE_DESPERATE = DEFAULT_WINDOW_DISTANCE * 2

DEFAULT_DESPERATE = DISABLE_DESPERATE # 2
DEFAULT_GOSSIP_CHANCE = 0.05
DEFAULT_MAX_RTT = 0.12
DEFAULT_LEAVES_PER_HOST = 1
DEFAULT_MAX_LEAVES = 70
DEFAULT_MAX_LEAVE_LOSS_RATE = 0.12
DEFAULT_SECONDS = 1800 # 30 min
DEFAULT_EXTRA_SECS = 60
DEFAULT_LOADER = False
DEFAULT_METADATA_ALWAYS = True
DEFAULT_CHECK_AHEAD = False

CFG_LINES = 31

REPLY = 'reply'

class Config:
	def __init__(self):
		self.load_defaults()
	
	def load_defaults(self):
		self.mode = DEFAULT_MODE
		self.page_server = DEFAULT_PGSERVER
		self.block_size = DEFAULT_BLOCK_SIZE
		self.player = DEFAULT_PLAYER
		self.nalulen = DEFAULT_NALULEN
		self.drop_rate = DEFAULT_DROP_RATE
		self.log_levels = DEFAULT_LOG_LEVELS
		self.dbg_levels = DEFAULT_DBG_LEVELS
		self.maniac_levels = DEFAULT_MANIAC_LEVELS
		self.path = DEFAULT_PATH
		self.acceptable_rate = DEFAULT_ACCEPTABLE_RATE
		self.acceptable_ratio = DEFAULT_ACCEPTABLE_RATIO
		self.logger = FILE_LOGGER
		self.page_central = DEFAULT_PAGE_CENTRAL # not configurable!
		self.max_throughput = DEFAULT_MAX_THROUGHPUT
		self.node_limits = DEFAULT_NODE_LIMITS
		self.partner_limits = DEFAULT_PARTNER_LIMITS
		self.generous_reply = DEFAULT_GENEROUS_REPLY
		self.do_nack = DEFAULT_DO_NACK
		self.map_size = DEFAULT_MAP_SIZE
		self.window_distance = DEFAULT_WINDOW_DISTANCE
		self.desperate_distance = DEFAULT_DESPERATE
		self.gossip_chance = DEFAULT_GOSSIP_CHANCE
		self.maxRTT = DEFAULT_MAX_RTT
		self.leaves_host = DEFAULT_LEAVES_PER_HOST
		self.max_leaves = DEFAULT_MAX_LEAVES
		self.seconds = DEFAULT_SECONDS
		self.extraSecs = DEFAULT_EXTRA_SECS
		self.loader = DEFAULT_LOADER
		self.metadata_always = DEFAULT_METADATA_ALWAYS
		self.select_algo = DEFAULT_SELECT_ALGO
		self.check_ahead = DEFAULT_CHECK_AHEAD

	def stop_delay(self):
		return self.seconds + self.extraSecs

	def load_from_file(self, path):
		lines = read_file_lines(path)
		assert VERSION == strip_nl(lines.pop(0)) # enforce cfg compatibility
		baselines = []
		basecfgfname = strip_nl(lines.pop(0))
		if basecfgfname:
			if basecfgfname[0] not in '/.~':
				d = dirname(path)
				if d:
					d = d + '/'
				basecfgfname = '%s%s' % (d, basecfgfname)
			baselines = read_file_lines(basecfgfname)
			assert VERSION == strip_nl(baselines.pop(0))
			baselines.pop(0) # no base-base-cfg ;)
		self.load_from_lines(lines, baselines)
		self.check_block_size()

	def load_from_lines(self, lines, baselines):
		lines = ensure_len(lines, CFG_LINES, '-')
		baselines = ensure_len(baselines, CFG_LINES, '')
		self.mode = select(lines, baselines)
		self.page_server = select(lines, baselines)
		self.block_size = int(select(lines, baselines)) / 8
		self.player = select(lines, baselines)
		self.nalulen = int(select(lines, baselines))
		self.drop_rate = float(select(lines, baselines))
		self.log_levels = intset(select(lines, baselines))
		self.dbg_levels = intset(select(lines, baselines))
		self.maniac_levels = intset(select(lines, baselines))
		self.path = select(lines, baselines)
		self.acceptable_rate = float(select(lines, baselines))
		self.acceptable_ratio = float(select(lines, baselines))
		self.logger = select(lines, baselines)
		self.max_throughput = int(select(lines, baselines)) // 8
		self.node_limits = tuple([int(x) for x in select(lines, baselines).split(' ')])
		self.partner_limits = tuple([int(x) for x in select(lines, baselines).split(' ')])
		self.generous_reply = select(lines, baselines) == REPLY
		self.do_nack = select(lines, baselines) == 'yes'
		self.map_size = int(select(lines, baselines))
		self.window_distance = int(select(lines, baselines))
		self.desperate_distance = int(select(lines, baselines))
		self.gossip_chance = float(select(lines, baselines))
		self.maxRTT = float(select(lines, baselines))
		self.leaves_host = int(select(lines, baselines))
		self.max_leaves = int(select(lines, baselines))
		self.seconds = float(select(lines, baselines))
		self.extraSecs = int(select(lines, baselines))
		self.loader = select(lines, baselines) == 'yes'
		self.metadata_always = select(lines, baselines) != 'no'
		self.select_algo = [int(x) for x in select(lines, baselines).split()]
		assert len(self.select_algo) == 3
		self.check_ahead = select(lines, baselines) == 'yes'

	def check_block_size(self):
		path = expanduser(self.path)
		if isfile(path) and self.seconds:
			fileLen = getsize(path)
			from FileLoader import header_length
			fileLen = fileLen - header_length(self.path)
			self.block_size = int(ceil(fileLen / self.seconds))

	def to_msg(self):
		generous = do_nack = do_metadata = do_loader = ''
		if self.generous_reply:
			generous = REPLY
		if self.do_nack:
			do_nack = 'yes'
		if self.loader:
			do_loader = 'yes'
		if not self.metadata_always:
			do_metadata = 'no'
		if self.check_ahead:
			do_check_ahead = 'yes'
		return '\n'.join([self.mode, self.page_server,
			str(self.block_size * 8), str(self.player), str(self.nalulen),
			str(self.drop_rate), ''.join([str(x) for x in self.log_levels]),
			''.join([str(x) for x in self.dbg_levels]),
			''.join([str(x) for x in self.maniac_levels]), self.path,
			str(self.acceptable_rate), str(self.acceptable_ratio), self.logger,
			str(self.max_throughput * 8), '%i %i' % self.node_limits,
			'%i %i' % self.partner_limits, generous, do_nack, str(self.map_size),
			str(self.window_distance), str(self.desperate_distance),
			str(self.gossip_chance), str(self.maxRTT), str(self.leaves_host),
			str(self.max_leaves), str(self.seconds), str(self.extraSecs),
			do_loader, do_metadata, ' '.join([str(x) for x in self.select_algo]),
			do_check_ahead])
	
	def adjust_logger(self, port, quitter, is_rendezvous=False):
		if self.logger == FILE_LOGGER:
			file = file_logger('%s_%d' % (HOSTNAME, port))
			pager = EmptyPageNodeOrCentral()
		else:
			file = Pager()
			if self.logger == NET_LOGGER or is_rendezvous:
				pager = PageNode(file)
			elif self.logger == TCP_LOGGER:
				pager = TcpPageNode(file, self.page_central)
			elif self.logger == UDP_LOGGER:
				pager = UdpPageNode(file, self.page_central)
		adjust_logger(file, self.log_levels, self.dbg_levels, self.maniac_levels, port, quitter)
		return pager
	
	def make_page_central(self, local):
		f = PageCentral
		if self.logger == TCP_LOGGER:
			f = TcpPageCentral
		elif self.logger == UDP_LOGGER:
			f = UdpPageCentral
		elif self.logger == FILE_LOGGER:
			return local
		return f(local)

	def make_loader(self):
		if self.loader == 'yes':
			return dummy_loader(self.path)
		return None

def ensure_len(l, n, s):
	return l + [s for x in range(len(l), n)]

def select(l1, l2):
	x1 = strip_nl(l1.pop(0))
	x2 = strip_nl(l2.pop(0))
	if x1 == '-':
		return x2
	return x1

def intset(s):
	return [int(x) for x in list(s) if x.isdigit()]
