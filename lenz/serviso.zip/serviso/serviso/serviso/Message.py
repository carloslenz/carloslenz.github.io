# Carlos Eduardo Lenz - PPGCC - UFSC
from copy import copy
import re
from socket import inet_aton, inet_ntoa
from struct import calcsize, pack, unpack

from Logger import Logger
from Window import SINGLE_BITS

ENTER_ID, LEAVE_ID, NODES_ID, PARTNER_ID, DATA_ID, BMAP_ID, REQUEST_ID, NACK_ID, GOSSIP_ID, QNACK_ID, QDATA_ID, MULTI_ID, START_ID, METADATA_ID = range(3, 17)

ENTER_FMT = '!B'
LEAVE_FMT = '!B4sHf'
PARTNER_FMT = '!BBI'

START_FMT = '!Bd'

DATA_HEADER_FMT = '!BIH'
DATA_BASE_FMT = DATA_HEADER_FMT + 'H'

DATA_HEADER_SIZE = calcsize(DATA_HEADER_FMT)

DATA_HEADER2_FMT = '!BIH'
DATA_SIZE_FMT = '!h'
DATA_INFO_FMT = '!BH'

DATA_HEADER2_SIZE = calcsize(DATA_HEADER2_FMT)
DATA_SIZE_SIZE = calcsize(DATA_SIZE_FMT)
DATA_INFO_SIZE = calcsize(DATA_INFO_FMT)

PART_MSG_SIZE = '!H'
PART_MSG_SIZE_SIZE = calcsize(PART_MSG_SIZE)

MULTI_HEADER = '!BB'
MULTI_HEADER_SIZE = calcsize(MULTI_HEADER)

DEFAULT_GOSSIP_TTL = 3

def s_format(s):
	return str(len(s)) + 's'

def decoding_s_format(fmt, s):
	return fmt + str(len(s) - calcsize(fmt)) + 's'

def unpack_s_format(fmt, s):
	return unpack(decoding_s_format(fmt, s), s)

def enter_msg():
	return pack(ENTER_FMT, ENTER_ID)

def start_msg(when):
	return pack(START_FMT, START_ID, when)

def leave_msg(address, rtt=0.0):
	host = inet_aton(address[0])
	port = address[1]
	return pack(LEAVE_FMT, LEAVE_ID, host, port, rtt)

def nodes_msg(addresses):
	fmt = '!BB'
	args = [NODES_ID, len(addresses)]
	for x in addresses:
		host = inet_aton(x[0])
		port = x[1]
		fmt = fmt + '4sH'
		args.append(host)
		args.append(port)
	args.insert(0, fmt)
	return apply(pack, args)

def partner_msg(req, mdat_index):
	if mdat_index == None:
		mdat_index = 0
	else:
		mdat_index = mdat_index + 1
	return pack(PARTNER_FMT, PARTNER_ID, int(req), mdat_index)

def data_msg(i, offset, s):
	fmt = DATA_BASE_FMT + s_format(s)
	x = pack(fmt, DATA_ID, i, offset, len(s), s)
#	args = (i, offset, s)
#	if cmp(data_from_msg(x)[1:], args):
#		Logger.quitter('CANT DECODE %s' % args, 1)
	return x

def join_data_msg(msg, s):
	return msg[:DATA_HEADER_SIZE] + pack('!H', len(s)) + s

def bmap_msg(at, i, s):
	fmt = '!BIIH' + s_format(s)
	return pack(fmt, BMAP_ID, at, i, len(s), s)

def request_msg(i, s):
	fmt = '!BIH' + s_format(s)
	return pack(fmt, REQUEST_ID, i, len(s), s)

def nack_msg(i, s):
	fmt = '!BIH' + s_format(s)
	return pack(fmt, NACK_ID, i, len(s), s)

def gossip_msg(s, ttl=DEFAULT_GOSSIP_TTL):
	fmt = '!BBH' + s_format(s)
	return pack(fmt, GOSSIP_ID, ttl, len(s), s)

def multi_msg(msgs):
	l = [pack(MULTI_HEADER, MULTI_ID, len(msgs))]
	i = data_from_msg2(msgs[0])[1]
	for x in msgs:
		assert data_from_msg2(x)[1] == i
		l.append(pack(PART_MSG_SIZE, len(x)))
		l.append(x)
	x = ''.join(l)
#	args, got = (MULTI_ID, msgs), multi_from_msg(x)
#	if cmp(got, args):
#		Logger.quitter('multi_msg failure %s %s' % (args, got), 1)
	return x

def enter_from_msg(s):
	return unpack(ENTER_FMT, s)

def start_from_msg(s):
	return unpack(START_FMT, s)

def leave_from_msg(s):
	x = unpack(LEAVE_FMT, s)
	return (x[0], (inet_ntoa(x[1]), x[2]), x[3])

def nodes_from_msg(s):
	fmt = '!BB'
	fmt = fmt + ('4sH' * ((len(s) - calcsize(fmt)) / 6))
	x = unpack(fmt, s)
	addresses = []
	for i in range(2, len(x), 2):
		addresses.append((inet_ntoa(x[i]), x[i+1]))
	assert x[1] == len(addresses)
	return (x[0], addresses)

def partner_from_msg(s):
	x = unpack(PARTNER_FMT, s)
	if x[2]:
		mdat = x[2] - 1
	else:
		mdat = None
	return (x[0], x[1], mdat)

def data_from_msg(s):
	x = unpack_s_format(DATA_BASE_FMT, s)
	assert x[0] in (DATA_ID, QDATA_ID)
	assert x[3] == len(x[4])
	return (x[0], x[1], x[2], x[4])

def bmap_from_msg(s):
	x = unpack_s_format('!BIIH', s)
	assert x[3] == len(x[4])
	return (x[0], x[1], x[2], x[4])

def request_from_msg(s):
	x = unpack_s_format('!BIH', s)
	assert x[2] == len(x[3])
	return (x[0], x[1], x[3])

def nack_from_msg(s):
	x = unpack_s_format('!BIH', s)
	assert x[2] == len(x[3])
	return (x[0], x[1], x[3])

def gossip_from_msg(s):
	x = unpack_s_format('!BBH', s)
	assert x[2] == len(x[3])
	return (x[0], x[1], x[3])

def multi_from_msg(s):
	l, start = [], MULTI_HEADER_SIZE
	code, n = unpack(MULTI_HEADER, s[:start])
	for x in range(0, n):
		stop = start + PART_MSG_SIZE_SIZE
		part = s[start : stop]
		if len(part) != PART_MSG_SIZE_SIZE:
			Logger.quitter('multi_from_msg %d %d %d %s' % (x, start, stop, (n, [len(q) for q in l], len(s))), 1)
		size, start = unpack(PART_MSG_SIZE, part)[0], stop
		stop = start + size
		l.append(s[start : stop])
		start = stop
	return (code, l)

def decode_f(s, dataf, nackf):
	assert s
	msg_type = ord(s[0])
	if msg_type == ENTER_ID:
		ret = (ENTER_ID,) #enter_from_msg(s)
	elif msg_type == START_ID:
		ret = start_from_msg(s)
	elif msg_type == LEAVE_ID:
		ret = leave_from_msg(s)
	elif msg_type == NODES_ID:
		ret = nodes_from_msg(s)
	elif msg_type == PARTNER_ID:
		ret = partner_from_msg(s)
	elif msg_type in (DATA_ID, QDATA_ID, METADATA_ID):
		ret = dataf(s)
	elif msg_type == BMAP_ID:
		ret = bmap_from_msg(s)
	elif msg_type == REQUEST_ID:
		ret = request_from_msg(s)
	elif msg_type in (NACK_ID, QNACK_ID):
		ret = nackf(s)
	elif msg_type == GOSSIP_ID:
		ret = gossip_from_msg(s)
	elif msg_type == MULTI_ID:
		ret = multi_from_msg(s)
	else:
		ret = (msg_type, s)
	return ret

def decode_msg(s):
	return decode_f(s, data_from_msg, nack_from_msg)

# SMART mode

MAX_DESL = (1 << 16) - 1
MAX_CODED = pack('!H', MAX_DESL)

def data_msg2(start, offset, s, sizes=[], info_before=[], info_after=[], code=DATA_ID):
#	assert start >= 0
#	assert offset >= 0
	l = data_sizes(sizes) + data_infos(info_before) + data_infos(info_after)
	pos = offset - start
#	if not (0 <= pos <= MAX_DESL):
#		Logger.panic('data msg offset', pos, start, offset)
	assert 0 <= pos <= MAX_DESL
	l.insert(0, pack(DATA_HEADER2_FMT, code, start, pos))
	l.append(s)
	x = ''.join(l)
#	args = (code, start, offset, s, (sizes, info_before, info_after))
#	got = data_from_msg2(x, False, False)
#	if cmp(got, args):
#		Logger.quitter('data_msg2 failure %s %s' % (args, got), 1)
	return x

def metadata_msg(start, offset, info_before=[], info_after=[]):
	return data_msg2(start, offset, '', [], info_before, info_after, METADATA_ID)

def qdata_msg(start, offset, s, sizes, info_before=[], info_after=[]):
	return data_msg2(start, offset, s, sizes, info_before, info_after, QDATA_ID)

MAX_SIZE = 32766
CODED_MAX_SIZE = pack('!h', MAX_SIZE)

def code_size(x):
	assert x
	l = []
	isNeg = x < 0
	if isNeg:
		x = -x
	while x >= MAX_SIZE:
		x = x - MAX_SIZE
		l.append(CODED_MAX_SIZE)
	x = x + 1 # as shorts they are the same: +0 and -0. Avoid it!
	if isNeg:
		x = -x		
	l.append(pack(DATA_SIZE_FMT, x))
	return ''.join(l)

def data_sizes(sizes):
	l = [code_size(x) for x in sizes]
	l.insert(0, pack('!B', len(sizes)))
	return l

def data_infos(infos):
	l = [pack(DATA_INFO_FMT, x[0], x[1]) for x in infos]
	l.insert(0, pack('!B', len(infos)))
	return l

def join_data_msg2(msg, s):
	return msg + s

def qnack_msg(offsets):
	return nack_msg2(offsets, QNACK_ID)

def nack_msg2(offsets, code=NACK_ID):
	l = copy(offsets)
	first = l.pop(0)
	parts = [pack('!BIH', code, first[0], first[1])]
	last = sum(first[:2])
	for x in l:
		desl = x[0] - last
		while desl >= MAX_DESL:
			parts.append(MAX_CODED)
			desl = desl - MAX_DESL
		if not (0 <= desl <= MAX_DESL and 0 <= x[1] <= MAX_DESL):
			Logger.panic('ERROR: nack_msg2', (desl, x[1]), offsets)
			raise 'a'
		parts.append(pack('!HH', desl, x[1]))
		last = x[0] + x[1]
	return ''.join(parts)

def decode_size(s, start):
	stop = start + DATA_SIZE_SIZE
	count, x, start = 0, unpack('!h', s[start : stop])[0], stop
	while x == MAX_SIZE:
		stop = start + DATA_SIZE_SIZE
		count, x, start = count + 1, unpack('!h', s[start : stop])[0], stop
	if x < 0:
		count = -count
		x = x + 1
	else:
		x = x - 1
	size = x + count * MAX_SIZE
	if not size:
		Logger.panic('not size', len(s), [ord(s[q]) for q in range(start, stop)])
	assert size
	return size, stop 

def sizes_from_msg(s, i):
	n = ord(s[i])
	i = i + 1
	l = []
	for j in range(0, n):
		size, i = decode_size(s, i)
		l.append(size)
	return l, i

def infos_from_msg(s, i):
	n = ord(s[i])
	i = i + 1
	def single_info(j):
		start = i + j * DATA_INFO_SIZE
		return s[start : start + + DATA_INFO_SIZE]
	return [unpack(DATA_INFO_FMT, single_info(j)) for j in range(0, n)]

NULS_REX = re.compile('\x00{10,}') # sequence of ten or more NULs

def dirty_hack_strip_nuls(s):
	s2 = ''.join(NULS_REX.split(s))
	if len(s) != len(s2):
		Logger.panic('NULs MSG', (s, s2))
	return s2

def data_from_msg2(s, check=True, hack=False):
	if hack:
		s = dirty_hack_strip_nuls(s)
	header = unpack(DATA_HEADER2_FMT, s[:DATA_HEADER2_SIZE])
	i = DATA_HEADER2_SIZE
	sizes, i = sizes_from_msg(s, i)
	info_before = infos_from_msg(s, i)
	i = i + 1 + len(info_before) * DATA_INFO_SIZE
	info_after = infos_from_msg(s, i)
	i = i + 1 + len(info_after) * DATA_INFO_SIZE
	data = s[i:]
	n = sum([abs(x) for x in sizes])
	if check and len(data) != n:
		Logger.panic('DT MSG LEN', len(data), n, sizes, (s,))
		assert False
	return (header[0], header[1], sum(header[1:3]), data, (sizes, info_before, info_after))

def arrange_nack(start, l):
	info = []
	while l:
		desl = val = l.pop(0)
		while val == MAX_DESL:
			val = l.pop(0)
			desl = desl + val
		start = start + desl
		sz = l.pop(0)
		info.append((start, sz))
		start = start + sz
	return info

def nack_from_msg2(s):
	x = unpack('!BI' + str((len(s) - 5)/2) + 'H', s)
	return (x[0], [(x[1], x[2])] + arrange_nack(x[1] + x[2], list(x[3:])))

def decode_msg2(s):
	return decode_f(s, data_from_msg2, nack_from_msg2)
