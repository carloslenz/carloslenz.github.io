# Carlos Eduardo Lenz - PPGCC - UFSC
from select import select
from socket import gethostbyname
from time import time

from Logger import Logger
from PageCentral import DEFAULT_CENTRAL_PORT, MAX_RECEIVE
from Pager import PAGE_SIZE

from util import sendto, tcp_non_blocking_socket, udp_non_blocking_socket

class PageNode:
	def __init__(self, pager):
		self.pager = pager
		self.all_sent_before = 0
		self.clear_before = 0

	def __call__(self, msg):
		indexes = msg.split()
		if indexes:
			assert indexes.pop(0) == 'repage'
			indexes = sorted([int(x) for x in indexes])
			Logger.idbg(5, 'repage', indexes)
			self.clear_until(indexes[0] - 15)
			lold = [self.msg_for(i) for i in indexes]
		else:
			lold = []
		current = self.pager.current
		lnew = [self.msg_for(i) for i in range(self.all_sent_before, current)]
		assert len(lnew) == current - self.all_sent_before
		l = lold + lnew
		if l:
			Logger.maniac(6, 'sending pages, old', indexes, 'new', (self.all_sent_before, current), 'n', len(l))
		self.all_sent_before = current
		return l

	def msg_for(self, i):
		page = self.pager.get(i)
		if len(page) < PAGE_SIZE:
			page = 'PGSIZE %d %d\n%s' % (i, len(page), page)
		return 'page %d %d\n%s' % (len(page), i, page)
	
	def clear_until(self, i):
		i = max(0, i)
		for x in range(self.clear_before, i):
			self.pager.remove(i)
		self.clear_before = i

class TcpPageNode(PageNode):
	def __init__(self, pager, host):
		PageNode.__init__(self, pager)
		self.socket = tcp_non_blocking_socket()
		addr = (host, DEFAULT_CENTRAL_PORT)
		self.socket.connect(addr)
		Logger.high('TcpPageNode connected', addr, self.socket.getsockname())
	
	def __call__(self, msg):
		l = PageNode.__call__(self, msg)
		for x in l:
			assert x
			self.socket.send(x)
		return []

class UdpPageNode(PageNode):
	def __init__(self, pager, host):
		PageNode.__init__(self, pager)
		self.socket = udp_non_blocking_socket()
		self.addr = (gethostbyname(host), DEFAULT_CENTRAL_PORT)
		Logger.high('UcpPageNode server', self.addr)

	def __call__(self, msg):
		l = PageNode.__call__(self, msg)
		while select([self.socket], [], [], 0)[0]:
			msg = self.receive_data()[1]
			l1 = PageNode.__call__(self, msg)
			l = l + l1
		for x in l:
			assert x
			sendto(self.socket, x, self.addr)
		return []

	def receive_data(self):
		msg, addr = self.socket.recvfrom(MAX_RECEIVE)
		return (str(addr), msg)
