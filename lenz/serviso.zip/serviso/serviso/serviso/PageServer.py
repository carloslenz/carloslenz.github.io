# Carlos Eduardo Lenz - PPGCC - UFSC
from os.path import expanduser
from socket import socket, AF_INET, SOCK_STREAM, SO_REUSEADDR, SOL_SOCKET
from sys import argv
from time import time

import gzip
import re

BINDING_REX = re.compile('binding[^,]*, (\d*)')

from Logger import Logger, reset_time
from PageCentral import DEFAULT_CENTRAL_PORT, DEFAULT_PAGE_PORT, MAX_RECEIVE

from util import correct_time, ANY_NIC

class PageServer:
	def __init__(self, gz):
		self.gz = gz
		self.files = {}
		self.buffer = ''
		self.size = 0

	def log(self, *args):
		apply(Logger.info, [2] + list(args))

	def __call__(self, data):
		self.push_data(data)
		self.process_page()
	
	def process_page(self):
		val = self.pop_page()
		while val:
			key, page = val
			if not key in self.files:
				self.new_node_file(key, page)
			node = self.files[key]
			self.write_page(node, page)
			val = self.pop_page()
	
	def push_data(self, data):
		self.buffer = self.buffer + data
	
	def pop_page(self):
		v = None
		if 0 < self.size <= len(self.buffer):
			page, self.buffer, self.size = self.buffer[0:self.size], self.buffer[self.size:], 0
			v = self.key, page
		if not self.size and len(self.buffer) > 50:
			self.pop_header()
		return v
	
	def pop_header(self):
		header, _, rest = self.buffer.partition('\n')
		try:
			const, size, i, key1, key2 = header.split(' ')
		except:
			self.log('problematic header:', header)
			raise
		self.log(key1, key2, i)
		self.size = int(size)
		assert const == 'node'
		self.buffer, self.key = rest, key1 + key2

	def find_binding_line(self, lines, default):
		for x in lines:
			match = BINDING_REX.search(x)
			if match:
				return match.group(1)
		return default

	def new_node_file(self, key, page):
		parts = key.split(',')
		host, port = parts[0][2:-1], parts[1][:-1]
		bind_port = self.find_binding_line(page.split('\n'), port)
		fname = '~/tmp/%s_%s.txt' % (host, bind_port)
		fname = expanduser(fname)
		if self.gz:
			fname = fname + '.gz'
			f = gzip.open(fname, 'w')
		else:
			f = open(fname, 'w')
		self.files[key] = f
		self.log('writing', fname, port)
	
	def write_page(self, file, page):
		file.write(page)
		file.flush

	def stop(self):
		self.process_page()
		for x in self.files.values():
			x.close()
