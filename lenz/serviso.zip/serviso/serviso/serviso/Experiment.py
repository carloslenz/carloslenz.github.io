# Carlos Eduardo Lenz - PPGCC - UFSC
from datetime import datetime
from select import select
from socket import socket, AF_INET, SOCK_DGRAM, SO_REUSEADDR, SO_SNDBUF, SOL_SOCKET
from sys import argv
from time import sleep, time

from Config import Config, strip_nl
from Destination import DEFAULT_RENDEZVOUS_PORT
from Host import DEFAULT_MAX_RECEIVE, HOSTIP
from Logger import Logger, init_time, reset_time
from Message import start_msg
from PageCentral import EmptyPageNodeOrCentral
from ProcessGroup import DEFAULT_CPU_TM
from Rendezvous import Rendezvous
from System import System

from util import bind_socket, correct_time, environment, not_multi, sendto, udp_non_blocking_socket

DEFAULT_CONTROL_PORT = DEFAULT_RENDEZVOUS_PORT - 1

IS_CLIENT = 'CLIENT'
IS_SERVER = 'SERVER'

LAST_PAGES_WAIT = 5

START_MSGS_DELAY = 0.5

INITIAL_COUNTDOWN = 20
INITIAL_PREP_COUNTDOWN = 300

CONFIG_MSG = 'SERVISO-CONFIG'

class Experiment:
	def __init__(self):
		self.load_defaults()
	
	def load_defaults(self):
		self.config = Config()
		self.mode = self.node
		self.port = DEFAULT_CONTROL_PORT
		self.manager = HOSTIP
		self.is_server = False
		self.dontStop = True
		self.sys = None
		self.start_time = None
		self.shall_start = False
		self.page_handler = EmptyPageNodeOrCentral()
		self.quitMsg = ''
		self.exitCode = self.last_start = self.stop_time = self.stop_delay = 0
		self.prep_countdown = INITIAL_PREP_COUNTDOWN

	def prepare_node(self):
		self.prep_countdown = self.prep_countdown - 1
		if self.prep_countdown < 0:
			self.dontStop = False
			return
		msg = 'prepare'
		if self.is_server:
			msg = msg + ' server'
		self.send_control(msg, (self.manager, DEFAULT_CONTROL_PORT))

	def log_now_cmd(self):
		Logger.high('now', datetime.now())
		Logger.high('cmd', ' '.join(argv))

	def load_file(self, path):
		Logger.high('loading', path)
		self.config.load_from_file(path)
		self.version = self.config.mode
		self.stop_delay = self.config.stop_delay()
		local_pager = self.config.adjust_logger(DEFAULT_RENDEZVOUS_PORT, self.quitter, True)
		self.log_now_cmd()
		Logger.high('stop delay', self.stop_delay)
		self.nodes = {}
		self.late_clients = []
		self.sys = Rendezvous.for_hostname(HOSTIP, DEFAULT_RENDEZVOUS_PORT)
		self.sys.myself.bind()
		self.page_handler = self.config.make_page_central(local_pager)
		self.mode = self.central
		self.log_environment()
		basic_cfg_msg = self.config.to_msg()
		self.server_msg = '\n'.join([CONFIG_MSG, self.version, 'server', basic_cfg_msg])
		self.client_msg = '\n'.join([CONFIG_MSG, self.version, 'client', basic_cfg_msg])
		self.version = self.version.split(' ')[0] # strip trailing 'test' if present
	
	def send_manager_start(self):
		addr, now = self.control_address(), time()
		if self.msg != 'start':
			if now - self.last_start > 1:
				Logger.info('manager start', addr)
				self.send_control('start', addr)
				self.last_start = now

	def node(self):
		if not self.dontStop:
			pass # send logs
		else:
			self.node_process_control()
		if self.sys:
			self.sys()
		else:
			self.prepare_node()
			sleep(1)
		
	def server_nodes(self):
		return [x for x in self.nodes if self.nodes[x][0] == IS_SERVER]
	
	def central(self):
		self.process_client_request()
		if not self.start_time and correct_time() > self.prep_countdown:
			self.dontStop = False
		if self.sys:
			if self.no_msgs_waiting():
				self.sys()
			if self.stop_time and self.stop_time < time():
				self.send_stop()
	
	def send_start_now(self):
		servers = self.server_nodes()
		if servers:
			if not self.start_time:
				self.start_msgs_countdown = INITIAL_COUNTDOWN
				reset_time()
				self.start_time = init_time()
				Logger.high('sending start...')
			when = time() - self.start_time
			self.next_start_msg = time() + 1
			self.start_msgs_countdown = self.start_msgs_countdown - 1
			msg = start_msg(when)
			for x in self.nodes:
				addr = str_to_address(x)
				addr = (addr[0], addr[1] + 1)
				self.sys.send_info(addr, msg)
			if self.stop_delay:
				self.stop_time = time() + self.stop_delay
		else:
			Logger.panic('cannot start: no server yet')

	def late_client(self, address, countdown):
		when = time() - self.start_time
		msg = start_msg(when)
		self.sys.send_info(address, msg)
		if countdown <= 1:
			return None
		return (address, countdown - 1)

	def send_stop(self):
		if self.mode == self.central:
			Logger.high('sending stop...')
			for x in self.nodes:
				self.send_control('stop', str_to_address(x))
			sleep(0.1)
			for x in self.nodes:
				self.send_control('stop', str_to_address(x))
			self.dontStop = False
			self.stop_delay = 0
	
	def run(self):
		self.prepare_network()
		try:
			while self.dontStop:
				self.receive_control()
				self.mode()
		finally:
			if self.mode == self.central:
				self.send_stop()
				limit = time() + LAST_PAGES_WAIT
				try: # central must continue processing page requests
					while time() < limit:
						self.receive_control()
						self.process_client_request()
				finally:
					self.page_handler.send_to_stop()
			else:
				self.page_handler.pager.new_page()
				self.send_pages() # send last page
			if self.sys:
				self.sys.stop()
			if self.quitMsg:
				Logger.panic('QUITTER', self.quitMsg)
		return self.exitCode
	
	def process_client_request(self):
		if self.start_time and self.next_start_msg <= time():
			if self.start_msgs_countdown > 0:
				self.send_start_now()
			elif self.late_clients:
				self.late_clients = [p for p in [self.late_client(a, b) for a,b in self.late_clients] if p]
				self.next_start_msg = time() + START_MSGS_DELAY
		if self.msg:
			key, prepare = str(self.address), False
			if self.msg == 'prepare server' or (key in self.nodes and self.msg == 'prepare' and self.nodes[key][0] == IS_SERVER):
				self.nodes[key], prepare = (IS_SERVER, True), True
				self.send_control(self.server_msg, self.address)
			elif self.msg == 'prepare':
				self.nodes[key], prepare = (IS_CLIENT, True), True
				self.send_control(self.client_msg, self.address)
			elif self.msg == 'start':
				Logger.info('got start')
				self.send_start_now()
				self.send_control('stop', self.address)
			elif self.msg.split()[0] == 'page':
				q = self.page_handler(key, self.msg)
				if q:
					apply(self.send_repage, q)
			if prepare and self.start_time:
				addr = (self.address[0], self.address[1] + 1)
				self.late_clients.append(self.late_client(addr, INITIAL_COUNTDOWN))
		else:
			q = self.page_handler('', '')
			if q:
				apply(self.send_repage, q)
		self.page_handler.check_yourself()

	def send_repage(self, key, msg):
		addr = str_to_address(key)
		self.send_control(msg, addr)

	def quitter(self, msg, exitCode):
		if self.quitMsg:
			self.quitMsg = '%s\n%s' % (self.quitMsg, msg)
			if not self.exitCode:
				self.exitCode = exitCode
		else:
			self.quitMsg = msg
			self.exitCode = exitCode
		self.dontStop = False

	def node_process_control(self):
		if self.msg:
			lines = self.msg.split('\n')
			first = lines.pop(0)
			if first == CONFIG_MSG:
				if self.sys:
					return
				q = lines.pop(0).split(' ')
				version, isTest = q[0], False
				if len(q) > 1:
					isTest = q[1] == 'test'
				option = lines.pop(0)
				self.config.load_from_lines(lines, [])
				port = self.port + 1
				self.config.page_central = self.manager
				self.page_handler = self.config.adjust_logger(port, self.quitter)
				self.log_now_cmd()
				self.sys = System(self.address[0], port, self.config, option == 'server', version == 'SMART', isTest)
				self.log_environment()
	 		elif first.split()[0] == 'repage':
	 			self.send_pages(self.msg)
	 		else:
	 			Logger.panic(self.address, 'MSG', self.msg)
		else:
			self.send_pages()

	def send_pages(self, msg=''):
		msgs = self.page_handler(msg)
		for x in msgs:
			self.send_control(x, self.control_address())
			
	def control_address(self):
		return (self.manager, DEFAULT_CONTROL_PORT)
	
	def prepare_network(self):
		self.socket = udp_non_blocking_socket()
		canChangePort = self.port != DEFAULT_CONTROL_PORT
		self.port = bind_socket(self.socket, self.port, canChangePort=canChangePort)
	
	def send_control(self, msg, address):
		sendto(self.socket, msg, address, True)

	def no_msgs_waiting(self):
		return not select([self.socket], [], [], 0)[0] # poll

	def receive_control(self):
		if self.no_msgs_waiting():
			self.msg = None
		else:
			self.msg, self.address = self.socket.recvfrom(10000)
			if self.msg == 'stop':
				Logger.high('got stop signal')
				self.dontStop = False
	
	def log_environment(self):
		Logger.idbg(3, 'environment:\n' + environment())

def str_to_port(x):
	return str_to_address(x)[1]

def str_to_address(x):
	parts = x.split(' ')
	return (parts[0][2:-2], int(parts[1][0:-1]))
