# Carlos Eduardo Lenz - PPGCC - UFSC
from os import SEEK_CUR
from os.path import expanduser
from socket import inet_aton
from struct import pack, unpack, calcsize
from time import time

DEFAULT_STAT = '~/tmp/%sstat.dat'

LAST_VER = 3

def no_adjust(v, l):
	return l

ZERO_ADJUST_INDEXES = [[3, 1], [3] + [9] * 16]

def adjust_stat(v, seq):
	l = list(seq)
	while v < LAST_VER:
		for i in ZERO_ADJUST_INDEXES[v]:
			l.insert(i, 0)
		v = v + 1
	return tuple(l)

VERSION_FMT = '!B'

STAT_FMTS = ['!HIIII', # read_index, extra, nout, lost, nread, netloss, totloss
	'!HIIIIII', # read_index, control, extra, nout, latebytes, lost, nread, netloss, totloss
	'!HIIIIIIIIIIIIIIIIIIIIIII', # read_index, control, extra, qdata, nout, latebytes, lost, nread, netloss, totloss, MSG COUNT: tfrc, feedback, enter, leave, nodes, partner, data, bmap, request, nack, gossip, qnack, qdata, multi, start, metadata
	'!HIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII', # read_index, control, extra, qdata, nout, latebytes, lost, nread, netloss, totloss, MSG COUNT: tfrc, feedback, enter, leave, nodes, partner, data, bmap, request, nack, gossip, qnack, qdata, multi, start, metadata, MSG LEN COUNT: tfrc, feedback, enter, leave, nodes, partner, data, bmap, request, nack, gossip, qnack, qdata, multi, start, metadata
]

FMTS = [['!Bd'] * len(STAT_FMTS), # code, time
	STAT_FMTS,
	['!H'] * len(STAT_FMTS), # nack
	['!HBB'] * len(STAT_FMTS), # avail
	['!IHB'] * len(STAT_FMTS), # lost
	['!4sHB'] * len(STAT_FMTS), # partner
	['!H15s'] * len(STAT_FMTS), # late
]

ADJUSTS = [no_adjust,
	adjust_stat,
	no_adjust,
	no_adjust,
	no_adjust,
	no_adjust,
	no_adjust
]

SIZES = [[calcsize(x) for x in l] for l in FMTS]
HEADER, SUMMARY, NACK, AVAIL, LOST, PARTNER, LATE = KINDS = range(0, len(FMTS))

class StatFile:
	def __init__(self, fname=DEFAULT_STAT, name=''):
		from util import correct_time
		self.timef = correct_time
		if fname == DEFAULT_STAT:
			fname = fname % name
		self.fname = expanduser(fname)
		self.f = None
		def make_handler(code):
			return lambda *l: self.handler(code, l)
		self.summary, self.nack, self.avail, self.lost = [make_handler(x) for x in range(SUMMARY, PARTNER)]
		self.version = LAST_VER

	def handler(self, code, l):
		s = apply(pack, (FMTS[code][LAST_VER],) + l)
		self.record(code, s)
	
	def partner(self, addr, isAdd):
		self.handler(PARTNER, (inet_aton(addr[0]), addr[1], isAdd))

	def late(self, delay, name):
		NAME_SIZE = 15
		s = name[:NAME_SIZE]
		s = '%s%s' % (s, ' ' * max(0, NAME_SIZE - len(s)))
		if len(s) != NAME_SIZE:
			Logger.quitter('NAME_SIZE %s' % ((len(s), s),), 1)
		if not (0 < delay <= 60):
			from Logger import Logger
			Logger.quitter('DELAY %f %s' % (delay, name), 2)
			delay = 60
		self.handler(LATE, (int(delay * 1000), s))

	def record(self, code, s, tm=None):
		if tm == None:
			tm = self.timef()
		self.write(pack(FMTS[HEADER][0], code, tm) + s)

	def write(self, s):
		self.getfw().write(s)

	def getfw(self):
		if not self.f:
			self.f = open(self.fname, 'w')
			self.write(pack(FMTS[HEADER][0], HEADER, time()))
			self.write('V')
			self.write(str(self.version))
		return self.f

	def read(self, kind=KINDS, defaultVer=1):
		f = open(self.fname)
		def fun():
			s = f.read(SIZES[HEADER][0])
			if s:
				hd  = unpack(FMTS[HEADER][0], s)
				kind = hd[0]
				if kind == HEADER:
					s = f.read(1)
					if s == 'V':
						self.version = int(f.read(1))
					else:
						self.version = defaultVer
						f.seek(-1, SEEK_CUR)
					return hd
				s = f.read(SIZES[kind][self.version])
				tl = ADJUSTS[kind](self.version, unpack(FMTS[kind][self.version], s))
				return hd + tl
			return None
		l = [x for x in iter(fun, None) if x[0] in kind]
		f.close()
#		print >>stderr, self.version
		return l

	def close(self):
		if self.f:
			# apply(self.record, [0] * 8) # empty line to the file's MTIME is updated
			self.f.close()
			self.f = None
