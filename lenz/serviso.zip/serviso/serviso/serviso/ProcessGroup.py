# Carlos Eduardo Lenz - PPGCC - UFSC
from copy import copy
from time import time

from Logger import Logger
from Starter import Starter

from util import correct_time

DEFAULT_WAIT = 0.05
MAX_DELAY = DEFAULT_WAIT * 1.5
ALL_DELAY = MAX_DELAY * 6.5
SOFT_DELAY = 0.85 * MAX_DELAY
DEFAULT_PERIOD = 1
LOG_CPU_TIME_PERIOD = 5
IDLE = 'Idle'
DEFAULT_CPU_TM = { IDLE : 0 }

class ProcessGroup:
	def __init__(self, processes, reception, delivery, buffer, first=None):
		self.starter = None
		self.loader = None
		self.player = None
		self.processes = processes
		self.reception = reception
		self.delivery = delivery
		self.buffer = buffer
		self.alternate = lambda : None
		self.period = DEFAULT_PERIOD
		if not first:
			first = time() + DEFAULT_PERIOD / 2
		self.when = first
		self.init_cpu_tm()	
		self.rec_wait = DEFAULT_WAIT

	def start_soon(self, delay, player):
		if not self.player and not self.starter:
			self.starter = Starter(delay, player)
			Logger.high('start around', correct_time(self.starter.when))

	def set_player(self, player):
		self.player = player
		self.starter = None

	def set_loader(self, loader):
		if not self.loader:
			self.loader = loader
			self.fast_header = True
			Logger.high('loader...')

	def __call__(self):
		self.run_and_check_delay(ALL_DELAY, 'processes', self.action)
	
	def action(self):
		self.run_reception_and(self.delivery)

		self.alternate()

		if self.when <= time():
			if self.starter:
				player = self.starter()
				if player:
					Logger.high('player...')
					self.set_player(player)
			for x in copy(self.processes):
				self.run_reception_and(x)
			if self.loader and not self.fast_header:
				self.run_reception_and(self.loader)
			if self.player and not self.player.inside_jump():
				self.run_reception_and(self.player)
			self.when = self.when + self.period

		cpu_period = time() - self.mark
		if cpu_period > LOG_CPU_TIME_PERIOD:
			for x in self.cpu_tm:
				self.cpu_tm[x] = int(100 * self.cpu_tm[x] / cpu_period)
			rec_name = self.proc_name(self.reception)
			self.cpu_tm[rec_name] = self.cpu_tm[rec_name] - self.cpu_tm[IDLE]
			if self.cpu_tm[IDLE] < 70:
				Logger.maniac(1, 'CPU Time', self.cpu_tm)
			self.init_cpu_tm()
	
	def run_reception_and(self, *args):
		self.run_and_record_cpu_time(self.reception, self.cpu_tm, self.wait_time())
		apply(self.run_and_record_cpu_time, args)

	def wait_time(self):
		if self.when > time():
			return self.rec_wait
		return 0

	def set_alt(self, *l):
		assert l
		self.alt = list(l)
		self.current = []
		self.alternate = self.alternate_list

	def alternate_list(self):
		if not self.current:
			self.current = copy(self.alt)
		proc = self.current.pop()
		self.run_reception_and(proc, time())
	
	def run_and_check_delay(self, max_delay, name, obj, args=[]):
		tm = time()
		apply(obj, args)
		delay = time() - tm
		if delay > max_delay:# and obj != self.reception:
			Logger.maniac(1, 'LATE', name, delay)
			Logger.statLate(delay, name)
		return delay
	
	def run_and_record_cpu_time(self, obj, *args):
		if self.loader and self.fast_header:
			if self.buffer.has_header():
				Logger.high('Header complete!')
				self.fast_header = False
			self.run_and_record_cpu(self.loader)
		apply(self.run_and_record_cpu, (obj,) + args)
		if self.player and self.player.inside_jump():
			self.run_and_record_cpu(self.player)

	def run_and_record_cpu(self, obj, *args):
		name = self.proc_name(obj)
		delay = self.run_and_check_delay(MAX_DELAY, name, obj, args)
		self.cpu_tm[name] = self.cpu_tm[name] + delay

	def proc_name(self, obj):
		name = obj.__class__.__name__
		if name not in self.cpu_tm:
			self.cpu_tm[name] = 0
		return name

	def init_cpu_tm(self):
		self.cpu_tm = copy(DEFAULT_CPU_TM)
		self.mark = time()
