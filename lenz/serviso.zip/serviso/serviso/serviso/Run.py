# Carlos Eduardo Lenz - PPGCC - UFSC
from os import getpid, kill
from random import uniform
from signal import SIGINT
from socket import gethostbyname
from subprocess import Popen
from sys import argv, stdout
from time import sleep, time
from threading import Thread
from traceback import format_exc

from Experiment import Experiment
from Host import HOSTIP, HOSTNAME
from Logger import Logger

from util import read_file_lines, set_multi

def run(args):
	if args and args[0] == 'auto':
		return run_auto(args[1:])
	else:
		return run_cmd(args)

def run_cmd(args):
		exp = Experiment()
		try:
			try:
				exp.load_file(args[0])
			except IOError:
				exp.manager = HOSTIP
				if args[0] != 'local':
					if args[0] == 'localhost':
						args[0] = HOSTNAME
					exp.manager = gethostbyname(args[0])
				exp.is_server = False
				if len(args) > 1:
					if args[1] == 'server':
						exp.is_server = True
					elif args[1] == 'start':
						exp.mode = exp.send_manager_start
				exp.port = int(uniform(6000,12000))
			return exp.run()
		finally:
			exp.send_stop()

def run_auto(args):
	from Logger import Logger
	server, rendezvous, cfg, secs = args[:4]
	if server == '-':
		server, rendezvous = [x.strip() for x in read_file_lines(rendezvous)][:2]
	if server == 'local':
		server = HOSTNAME
	if rendezvous == 'local':
		rendezvous = HOSTNAME
	secs, detach = int(secs), False
	if secs < 0:
		secs, detach = -secs, True
	Logger.high('name', HOSTNAME, 'ip', HOSTIP)
	def run_rendezvous(child=None):
		Logger.high('RENDEZVOUS')
		if child:
			def check_child():
				before = time()
				ret = child.wait()
				if ret or time() - before < 180: # 3min
					kill(getpid(), SIGINT)
			Thread(target=check_child).start()
		run([cfg])
	def run_server():
		if secs:
			def send_start():
				sleep(secs)
				Logger.high('START')
				run([rendezvous, 'start'])
			Thread(target=send_start).start()
		Logger.high('SERVER')
		run([rendezvous, 'server'])
	if HOSTNAME == server:
		if HOSTNAME == rendezvous:
			if detach:
				cmd = argv[0]
				if secs:
					args = (cmd, 'auto', HOSTNAME, 'localhost', cfg, str(secs))
				else:
					args = (cmd, HOSTNAME, 'server')
				detach = Popen(args)
				Logger.high('detach server', detach.pid)
			else:
				set_multi()
				Thread(target=run_server).start()
			return run_rendezvous(detach)
		else:
			return run_server()
	elif HOSTNAME == rendezvous:
		return run_rendezvous()
	else:
		if len(args) > 4:
			fname = args[4]
			hosts = [x.strip() for x in open(fname).readlines()]
			if HOSTNAME not in hosts:
				Logger.high('NOT SELECTED')
		Logger.high('CLIENT')
		return run([rendezvous])

def usage(cmd=argv[0]):
	print 'usage:', cmd, 'auto [SERVER RENDEZVOUS | - SRV-FNAME] CONFIG-FILE [-]SECS [SELECTED-FNAME] | CONFIG-FILE | RENDEZVOUS-HOST [server|start]'
