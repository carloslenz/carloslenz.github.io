# Carlos Eduardo Lenz - PPGCC - UFSC
from time import time

class Starter:
	def __init__(self, delay, player):
		self.player = player
		self.when = time() + delay
		
	def __call__(self):
		if time() >= self.when:
			return self.player
		return None
