# Carlos Eduardo Lenz - PPGCC - UFSC
from time import time

from Window import Window

DEFAULT_BMAP = (0, '')
REMOVE_AVOIDED = 5

TIMEOUT_RESP_META = TIMEOUT_REQ_META = 0.2

class Node:
	def __init__(self, address, bandwidth=0):
		self.address = address
		self.bandwidth = bandwidth
		self.partial_transfers = {}
		self.requested = []
		self.sent = []
		self.request = self.sched_bmap = self.bmap = DEFAULT_BMAP
		self.at = 0
		self.req_changed = False
		self.nacked = {}
		self.time_to_transmit = {}
		self.missed = []
		self.available = []
		self.sched = []
		self.prev_sched = set([])
		self.transfered = set([])
		self.server_blk_avail = set([])
		self.partnership_requests = self.tried_partnerships = 0
		self.tick = time()
		self.avoid_count = 0
		self.bad_rtt = 0.0
		self.avoid_msg = ''
		self.meta_req = {}
		self.meta_resp = {}

	def remove_partial(self, i):
		if i in self.partial_transfers:
			del self.partial_transfers[i]
		if i in self.nacked:
			del self.nacked[i]

	def scheduled(self, l):
		self.sched = l
		self.sched_bmap = Window.list_to_bmap(l)
	
	def request_bmap(self, i, bmap):
		pair = (i, bmap)
		if cmp(pair, self.request):
			self.request = (i, bmap)
			self.requested = Window.bmap_to_list(i, bmap)
			self.req_changed = True
		
	def has_req_changed(self):
		if self.req_changed:
			self.req_changed = False
			return True
		return False
	
	def is_partner(self):
		return self.bandwidth != 0

	def is_avoided(self):
		return self.avoid_count >= 1

	def avoid_it(self):
		self.bandwidth = 0 # not partner anymore
		self.avoid_count = self.avoid_count + 1
		return self.avoid_count > REMOVE_AVOIDED
	
	def should_request_partnership(self):
		if not self.is_partner():
			return True
		self.partnership_requests = self.partnership_requests + 1
		return (self.partnership_requests % 3) == 1
	
	def has_it(self, i, header_size, window_size):
		if i not in self.available:
			if i >= header_size:
				return False
			if self.bmap[0] == 0 and (not self.available or self.available[0] < header_size):
				return False
			if (self.bmap[0] + window_size) <= header_size:
				return False
		return True
	
	def set_bmap(self, at, i, bmap):
		self.at = at
		self.bmap = (i, bmap)
		self.available = Window.bmap_to_list(i, bmap)
	
	def get_bandwidth(self, dest):
		return max(self.bandwidth, dest.x_recv)

	def should_resp_meta(self, i):
		now = time()
		limit = now - TIMEOUT_RESP_META
		for j,tm in self.meta_resp.items():
			if tm < limit:
				del self.meta_resp[j]
		if i not in self.meta_resp:
			self.meta_resp[i] = now
			return True
		return False

	def should_req_meta(self, i):
		now = time()
		limit = now - TIMEOUT_REQ_META
		for j,tm in self.meta_req.items():
			if tm < limit:
				del self.meta_req[j]
		if i not in self.meta_req:
			self.meta_req[i] = now
			return True
		return False
