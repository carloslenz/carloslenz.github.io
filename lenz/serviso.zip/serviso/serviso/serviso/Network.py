# Carlos Eduardo Lenz - PPGCC - UFSC
from random import choice, uniform
from time import time

from Destination import DEFAULT_RENDEZVOUS_PORT
from Host import Host, DEFAULT_BANDWIDTH, HOSTIP
from Logger import Logger
from Message import gossip_msg, leave_msg, nodes_msg, partner_msg, DEFAULT_GOSSIP_TTL
from Node import Node
from util import correct_time, select_one_index

DEFAULT_SERVER_PORT = 14520
DEFAULT_PORT = 14521
DEFAULT_PARTNER_TIMEOUT = 10

CONTROL_MSG_LIMIT = 1800

class Network:
	def __init__(self, myself, rendezvous, nodeLimits, generousReply):
		self.rendezvous = rendezvous
		self.myself = myself
		self.generousReply = generousReply
		self.timeout = DEFAULT_PARTNER_TIMEOUT
		self.nodeLimits = nodeLimits
		self.enter_tick = 0
		self.nodes = {}
	
	def send(self, address, msg, prio, isReply):
		self.myself.send(self.node(address), msg, prio)
		if isReply and self.generousReply:
			self.myself.reply_len(address, len(msg))
	
	def send_info(self, address, msg):
		if len(msg) > CONTROL_MSG_LIMIT:
			Logger.panic('Big control msg', (ord(msg[0]), msg))
			assert False
		self.send(address, msg, 0, False)

	def send_data_meta(self, address, msg, topOffset, isReply=False):
		if topOffset == None:
			self.send_info(address, msg)
		else:
			self.send(address, msg, topOffset + 1, isReply)

	def send_metadata(self, hi, i, msg):
		if hi.should_resp_meta(i):
			Logger.dyn(8, hi.address, 'Metadata resp', i)
			self.send_info(hi.address, msg)
		else:
			Logger.dyn(8, hi.address, 'Metadata too soon', i)

	def request_metadata(self, hi, i, msg):
		if hi.should_req_meta(i):
			self.send_info(hi.address, msg)
			Logger.dyn(8, hi.address, 'Metadata req', i)
			return True
		Logger.dyn(8, hi.address, 'Metadata not again', i)
		return False

	def silent_nodes(self):
		limit = time() - self.timeout
		return [hi for hi in self.partners() if hi.tick < limit]

	def check_network(self):
		self.myself.check_feedback(self.rendezvous.myself)
		self.enter_network()
	
	def request_partnership(self, address, mdat_index, req=True):
		action = 'requesting'
		if not req:
			action = 'confirming'
		Logger.dbg(5, action, 'partnership', address)
		self.send_info(address, partner_msg(req, mdat_index))
	
	def node(self, address):
		key = str(address)
		if key in self.nodes:
			return self.nodes[key]
		elif address == self.rendezvous.myself.address:
			return self.rendezvous.myself
		return Node(address)
	
	def get_nodes(self):
		return self.nodes.values()

	def partners(self):
		return [x for x in self.get_nodes() if x.is_partner()]

	def avoided(self):
		return [x for x in self.get_nodes() if x.is_avoided()]

	def no_partners(self):
		return [x for x in self.get_nodes() if not x.is_partner()]
	
	def count_nodes(self):
		return len(self.nodes)
	
	def count_partners(self):
		return len(self.partners())
	
	def knows(self, address):
		return str(address) in self.nodes
	
	def add_node(self, address):
		key = str(address)
		k = self.knows(address)
		if address != self.myself.address and address[1] != self.rendezvous.myself.address[1] and not k:
			self.nodes[key] = Node(address)
			Logger.dbg(5, '+node', address, self.count_partners())
	
	def add_partner(self, address, bandwidth):
		key = str(address)
		if key in self.nodes:
			self.nodes[key].bandwidth = bandwidth
		else:
			self.nodes[key] = Node(address, bandwidth)
		Logger.dbg(5, '+partner', address, self.count_partners())
	
	def remove_node(self, address, cause):
		key = str(address)
		rtt = 0
		if key in self.myself.destinations:
			rtt = self.myself.remove_messages_for(address)
		if key in self.nodes:
			node = self.nodes[key]
			if node.is_partner():
				Logger.info(1, '-node', key, 't', correct_time(self.nodes[key].tick), 'rtt', rtt, cause, 'TOT', self.count_nodes())
			del self.nodes[key]
	
	def enter_network(self):
		tm = time()
		limit = tm - self.timeout / 2
		if self.enter_tick < limit:
			if self.enter_tick == 0:
				self.myself.bind(True)
				Logger.high('enter', self.myself.address)
			self.rendezvous.enter(self.myself)
			self.enter_tick = tm
	
	def leave_network(self, address=None):
		cause = 'silent'
		if address == None:
			address = self.myself.address
			cause = 'leaving...'
		self.rendezvous.leave(self.myself, address)
		self.gossip(leave_msg(address))
		if address == self.myself.address:
			self.nodes = {}
		else:
			self.remove_node(address, cause)
	
	def gossip(self, msg, ttl=DEFAULT_GOSSIP_TTL):
		gossipMsg = gossip_msg(msg)
#		Logger.dyn(4, 'gossip ttl', ttl, 'type', ord(msg[0]))
#		for address in self.select_some_nodes(self.count_partners()):
#			self.send_info(address, gossipMsg)
	
	def select_some_nodes_from(self, n, l):
		n = min(n, len(l))
		while len(l) > n:
			del l[select_one_index(l)]
		return l
	
	def node_addresses(self):
		return [x.address for x in self.nodes.values()]
	
	def select_some_nodes(self, n, exceptions=[]):
		exceptions.append(self.rendezvous.myself.address)
		not_rendezvous = [x for x in self.node_addresses() if not (x in exceptions)]
		return self.select_some_nodes_from(n, not_rendezvous)
	
	def select_deputy(self, avoid=None):
		addresses = [x for x in self.node_addresses() if x != avoid]
		if len(addresses) == 0:
			return self.rendezvous.myself.address
		else:
			return choice(addresses)
	
	def be_deputy(self, address):
		if address != self.rendezvous.myself.address:
			l = self.select_some_nodes(30, [address])
			self.send_info(address, nodes_msg(l))
	
	def request_more_nodes(self):
		address = self.select_deputy()
		self.send_info(address, nodes_msg([]))
	
	def need_nodes(self):
		return self.count_nodes() < self.nodeLimits[0]

	def got_nodes(self, addresses):
		limit = time() - self.timeout * 5
		target = self.no_partners()
		target.sort(lambda x,y: int(x.tick - y.tick))
		for addr in addresses:
			self.add_node(addr)
		excess = self.count_nodes() - self.nodeLimits[1]
		for i in range(0, min(excess, len(target))):
			self.remove_node(target[i], 'replaced')
	
	def expire_nodes(self):
		limit = time() - 60 # last minute
		expired = [x.address for x in self.get_nodes() if x.tick < limit]
		for addr in expired:
			self.remove_node(addr, 'expired')

	def tick(self, address):
		self.node(address).tick = time()

	@staticmethod
	def for_hostname(rendezvousName, port, max_throughput, nodeLimits, generousReply):
		from Rendezvous import Rendezvous
		if port == None:
			port = int(uniform(6000, 12000))
		rendezvous = Rendezvous.for_hostname(rendezvousName, DEFAULT_RENDEZVOUS_PORT)
		return Network(Host((HOSTIP, port), max_throughput), rendezvous, nodeLimits, generousReply)
