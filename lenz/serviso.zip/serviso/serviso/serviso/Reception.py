# Carlos Eduardo Lenz - PPGCC - UFSC
from random import random

from Logger import Logger
from Message import decode_msg, decode_msg2, BMAP_ID, DATA_ID, GOSSIP_ID, LEAVE_ID, METADATA_ID, QNACK_ID, QDATA_ID, MULTI_ID, NACK_ID, NODES_ID, PARTNER_ID, REQUEST_ID, START_ID
from NackControl import NackControl

class Reception:
	def __init__(self, network, buffer, dataFun, delivery, scheduler, partnershipManager, starter, bmaper, gossip_chance):
		self.network = network
		self.dataFun = dataFun
		self.delivery = delivery
		self.scheduler = scheduler
		self.partnershipManager = partnershipManager
		self.starter = starter
		self.bmaper = bmaper
		if buffer:
			self.buffer = buffer
			self.fdata = self.smart_data
			self.fnack = self.smart_nack
			self.decode_msg = decode_msg2
			self.decode_nack = NackControl.decode2
		else:
			self.fdata = self.trad_data
			self.fnack = self.trad_nack
			self.decode_msg = decode_msg
			self.decode_nack = NackControl.decode
		self.gossip_chance = gossip_chance
	
	def __call__(self, cpu_time, waittime):
		for (s, address) in self.network.myself(cpu_time, waittime):
			self.network.tick(address)
			l, multi_i = [s], None
			while l:
				msg = l.pop(0)
				x = self.decode_msg(msg)
				if x[0] == GOSSIP_ID:
					if random() < self.gossip_chance:
							self.network.gossip(s, x[1] - 1)
					x = decode_msg(x[2])
				if x[0] in (DATA_ID, QDATA_ID, METADATA_ID):
					assert multi_i == None or x[1] == multi_i
					if not self.fdata(address, x) and x[0] != METADATA_ID:
						Logger.quitter('INVALID data %s' % ((address, msg),), 1)
				elif x[0] == BMAP_ID:
					self.bmaper(address, x[1], x[2], x[3])
				elif x[0] == LEAVE_ID:
					if self.network.node(x[1]).is_partner():
						if address[0] != x[1][0] or address[1] != x[1][1]:
							continue # ignore
						self.partnershipManager.leaving(address, 'from network', x[2])
					self.network.remove_node(x[1], 'msg from ' + str(address))
				elif x[0] == NODES_ID:
					if len(x[1]) == 0:
						self.network.be_deputy(address)
					else:
						self.network.got_nodes(x[1])					
				elif x[0] == PARTNER_ID:
					self.partnershipManager.request(address, x[2], x[1])
				elif x[0] == REQUEST_ID:
					self.delivery.request(address, x[1], x[2])
				elif x[0] in (NACK_ID, QNACK_ID):
					self.fnack(address, x)
				elif x[0] == MULTI_ID:
					assert multi_i == None
					multi_i = self.decode_msg(x[1][0])[1]
					Logger.dbg(3, 'got multi', len(x[1]), [len(q) for q in x[1]], len(s))
					l = l + x[1]
				elif x[0] == START_ID:
					self.starter(x[1], address)
				else:
					info = x
					if x[1] != s:
						info = (x[0], x[1], s)
					Logger.panic(address, 'unrecognized msg', info) # idbg?
		self.network.check_network()

	def trad_data(self, address, x):
		return self.dataFun(address, x[1], x[2], x[3], [[]], x[0])
	
	def smart_data(self, address, x):
		return self.dataFun(address, x[1] / self.buffer.block_size, x[2], x[3], x[4], x[0])

	def trad_nack(self, address, x):
		i = x[1]
		for y in self.decode_nack(x[2]):
			self.delivery.nack(address, i, y)
			i = i + 1
	
	def smart_nack(self, address, x):
		for y in self.decode_nack(x[1], self.buffer):
			self.delivery.nack(address, y[0], y[1], x[0])
