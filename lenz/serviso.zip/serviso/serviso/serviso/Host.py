# Carlos Eduardo Lenz - PPGCC - UFSC
from select import select
from socket import error, gethostbyname, gethostname
from struct import unpack
from time import sleep, time
from threading import Thread
from traceback import format_exc

from Buffer import DEFAULT_BLOCK_SIZE
from Destination import Destination, joined, BIG_QUEUE, SEND_DATA, SEND_FEEDBACK, SEND_DATA_HEADER_SIZE
from Logger import Logger, reset_time
from Message import QDATA_ID, METADATA_ID
from Pager import restrict_access
from ProcessGroup import IDLE
from util import bind_socket, correct_time, div_or_zero, flat, not_multi, sendto, udp_non_blocking_socket

DEFAULT_BANDWIDTH = 1000000 / 8 # 1 mbps
DEFAULT_MAX_RECEIVE = DEFAULT_BLOCK_SIZE

HOSTNAME = gethostname()
HOSTIP = gethostbyname(HOSTNAME)
LOCALHOSTIP = gethostbyname('localhost')

THREADED_NET_IO_TIMEOUT = 0.05 # 50 ms

BEGIN_SIZE_CONTROLLED_DROP = 100000

def host_addresses(l):
	return [x.address for x in l]
	
class Host:
	def __init__(self, address, max_throughput):
		self.address = address
		self.max_throughput = max_throughput
		self.max_receive = DEFAULT_MAX_RECEIVE
		self.destinations = {}
		self.msg_counters = {}
		self.msglen_counters = {}
		self.sum_counters = self.drop_out = self.stat_out = self.sec_out = self.drop_rate = self.accepted = self.dropped = self.total_in = self.total_out = self.overhead = self.control = self.qdata = 0
		self.stat_when = self.stop_until = time()
		self.sec_next = self.stat_when + 1
		self.started = False
		self.mark_start = 0
		self.received = []
		self.socket = None
		self.thread = Thread(target=self.keep_receiving, name='NIO')
		self.thread.setDaemon(True)
		self.thread.start()

	def bind(self, canChangePort=False):
		self.socket = udp_non_blocking_socket()
		port = bind_socket(self.socket, self.address[1], canChangePort=True)
		self.address = (self.address[0], port)

	def is_partner(self):
		return False
	
	def send(self, hi, msg, prio):
		self.destination(hi.address).push_msg(msg, prio)
	
	def destination(self, address):
		key = str(address)
		if key not in self.destinations:
			self.destinations[key] = Destination(address)
		return self.destinations[key]
	
	def send_one_now(self, hi):
		if not hi.queue:
			return False
		prio, msg = hi.pop_msg()
		n = len(msg)
		if prio:
			msg, overhead = hi.encode_data_msg(msg, prio, self.max_throughput)
			if overhead:
				Logger.dbg(8, hi.address, 'overhead', overhead, 'pos', prio - 1)
				self.overhead = self.overhead + overhead
			if self.is_encoded_qdata(msg):
				self.qdata = self.qdata + len(msg)
			Logger.maniac(5, hi.address, 'TFRC out', prio, 'len', n)
		else:
			self.control = self.control + n
			hi.control = hi.control + n
		self.send_encoded(hi, msg, prio)
		return (not prio) and hi.queue

	def is_encoded_qdata(self, msg):
		pos = 0
		if ord(msg[0]) == SEND_DATA:
			pos = SEND_DATA_HEADER_SIZE
		return ord(msg[pos]) == QDATA_ID

	def count_msg(self, isTFRC, msg):
		kind = ord(msg[0])
		assert not isTFRC or kind == SEND_DATA
		self.msg_counters[kind] = self.msg_counter(kind) + 1
		self.msglen_counters[kind] = self.msglen_counter(kind) + len(msg)

	def msg_counter(self, kind):
		if kind not in self.msg_counters:
			return 0
		return self.msg_counters[kind]

	def msglen_counter(self, kind):
		if kind not in self.msglen_counters:
			return 0
		return self.msglen_counters[kind]

	def counters(self):
		assert 0 not in self.msg_counters
		assert not self.msg_counters or max(self.msg_counters) <= METADATA_ID
#		assert not self.msglen_counters or max(self.msglen_counters) <= METADATA_ID
		return [self.msg_counter(i) for i in range(1, METADATA_ID + 1)], [self.msglen_counter(i) for i in range(1, METADATA_ID + 1)]

	def send_encoded(self, hi, msg, isTFRC):
		n, now, msgType = len(msg), time(), ord(msg[0])
		drop = self.drop_rate
		if drop and self.total_out > BEGIN_SIZE_CONTROLLED_DROP:
			drop = 2 * drop - float(self.dropped) / self.total_out
		self.total_out = self.total_out + n
		self.count_msg(isTFRC, msg)
		if hi.drop_control(drop, isTFRC):
			self.dropped = self.dropped + n
			info = msgType
			if msgType == SEND_DATA:
				q1 = unpack('!I', msg[1:5])[0]
				q2 = sum(unpack('!IH', msg[16:22]))
				info = 'DATA %d %d' % (q1, q2)
			self.drop_out = self.drop_out + n
			Logger.maniac(5, hi.address, 'drop', info, 'len', n, 'rate', float(self.dropped) / self.total_out)
			return
		else:
			self.accepted = self.accepted + 1
 		self.stat_out = self.stat_out + n
		if self.sec_next < now:
			self.sec_out, self.sec_next = n, now + 1
		else:
			self.sec_out = self.sec_out + n
			extra = self.sec_out - self.max_throughput
			if extra > 0:
				self.stop_until, self.sec_out = self.sec_next, extra
				Logger.idbg(2, 'hit', self.stop_until - now, extra)
		sendto(self.socket, msg, hi.address)
	
	def reply_len(self, address, n):
		self.destination(address).reply_len(n)

	def remove_messages_for(self, address):
		key = str(address)
		if key in self.destinations:
			dest = self.destinations[key]
			if dest.packet_count:
				Logger.dbg(9, '-destination', dest.packet_count, dest.queue_info())
			del self.destinations[key]
			return dest.round_trip_time
		return 0
	
	def receive(self):
		receive_timestamp = time()
		msg,address = self.socket.recvfrom(self.max_receive)
		return (msg, address, receive_timestamp)
	
	def start(self, when):
		if not self.started:
			self.started = True
			if not_multi():
				reset_time(when)
			self.qdata = self.control = self.total_in = self.total_out = 0
			for hi in self.destinations.values():
				hi.packet_count_stat = hi.byte_count_stat = 0

	def dbg_stats(self, l1, l2):
		apply(Logger.dbg, [9] + list(l2))

	def info_stats(self, l1, l2):
		apply(Logger.info, [3] + list(l2))
		apply(Logger.stat, l1)

	def log_stats(self, read_index, last_block, late_info, lost_info, todo, sched, when, npart):
		fdbg = self.dbg_stats
		if self.started:
			if when:
				return
			fdbg = self.info_stats
		elif when:
			self.start(when)
			fdbg = self.info_stats
		net, est = self.usage()
		dstat = [x.stats() for x in self.destinations.values()]
		n = max(1, len(dstat))
		def fix(i):
			items = [x[i] for x in dstat]
			b = sum(items) / n
			if b < 0:
				Logger.quitter('NOT PERCENT %f %s' % (b, items), 1)
				return 0
			elif b > 100:
				Logger.quitter('NOT PERCENT %f %s' % (b, items), 1)
				return 100
			return b
		l = [fix(q) for q in (0, 1)]
		nrWait, lenWait = self.len_received()
		waitinfo =  '%d %d' % (nrWait, lenWait)
		if not nrWait:
			waitinfo = '0 -'
		counters, lencounters = self.counters()
		l1 = [read_index, self.control, self.overhead, self.qdata, self.total_out, late_info, lost_info[0], lost_info[1]] + counters + lencounters
		sum_counters = sum(counters)
		l2 = ['stat', read_index, net * 8 / 1000, '/', div_or_zero(self.overhead, self.total_out), div_or_zero(self.qdata, self.total_out), div_or_zero(self.control, self.total_out), sum_counters - self.sum_counters, '/', div_or_zero(lost_info[0], lost_info[1]), div_or_zero(late_info, lost_info[1]), '/', l[1], todo, sched, waitinfo, npart]
		self.sum_counters = sum_counters
		fdbg(l1, l2)
		dstat = [[x[2], x[3], x[5], x[4], x[6], x[0], x[1]] for x in dstat if x[3]]
		# address/rtt/loss_rate/prio_msgs/X/net_loss/tot_loss
		if dstat:
			apply(Logger.idbg, [6, len(dstat)] + flat(dstat))
		# in/last
		Logger.dbg(9, 'xtat', self.total_in, last_block)
		self.stat_when = time()
		self.stat_out = self.drop_out = 0
		if not read_index and self.period() > 200: # 3 min 20 s
			Logger.quitter('hasnt start for too long', 2)

	def period(self):
		if not self.mark_start:
			self.mark_start = time()
			return 0
		return time() - self.mark_start

	def usage(self):
		dif = time() - self.stat_when
		return (self.stat_out / dif, (self.stat_out + self.drop_out) / dif)

	def process_receive(self, msg, address, receive_timestamp):
		if not msg:
			Logger.panic(address, 'EXITING?')
			return None
		msgType = ord(msg[0])
		self.total_in = self.total_in + len(msg)
		if address[0] == LOCALHOSTIP:
			address = (HOSTIP, address[1])
		if msgType in (SEND_DATA, SEND_FEEDBACK):
			hi = self.destination(address)
			return hi.receive(msg, receive_timestamp, self)
		# non-DATA/FEEDBACK packets: avoid TFRC
		return msg, address
		
	def want_to_send(self):
		l = [x for x in self.destinations.values() if x.wants_to_send()]
		l.sort(key=lambda x: x.next_transfer)
		return l
	
	def process_list(self, l):
		l = [self.process_receive(msg[0], msg[1], msg[2]) for msg in l]
		return [x for x in l if x]	
	
	def check_feedback(self, rendezvous, host=None):
		tnow = time()
		if not host:
			host = self
		for hi in self.destinations.values():
			hi.check_feedback(tnow, host)
		if rendezvous:
			rendezvous.check_feedback(None, host)

	def stop(self):
		self.max_receive = 0

	def keep_receiving(self):
		while not self.socket:
			sleep(THREADED_NET_IO_TIMEOUT * 10)
		lsocket = [self.socket]
		want = self.want_to_send()
		timeout = THREADED_NET_IO_TIMEOUT
		while self.max_receive:
			l = []
			lread, _, _ = select(lsocket, [], [], timeout)
			while lread: # first receive everything
				try:
					timeout = 0
					msg = self.receive()
					l.append(msg)
					lread, _, _ = select(lsocket, [], [], 0) # keep receiving
				except error, v:
					Logger.maniac(1, 'socket error', v)
			if l:
				self.append_received(l)
			if not want:
				want = self.want_to_send()
				timeout = THREADED_NET_IO_TIMEOUT
			elif self.stop_until <= time():
				_, lwrite, _ = select([], lsocket, [], 0)
				if lwrite:
					dest = want.pop(0) # try destinations in sequence
					n, logQueue = 1, len(dest.queue) >= BIG_QUEUE
					if logQueue:
						before = dest.queue_info()
					try:
						while self.send_one_now(dest) and select([], lsocket, [], 0)[1]:
							n = n + 1 # keeps sending info msgs (prio == 0) until a DATA one
					except:
						Logger.panic('NIO error', format_exc())
					if logQueue:
						Logger.dbg(9, dest.address, 'OUT', n, dest.queue_info(), 'before', before)

	def __call__(self, cpu_time, waittime):
		if waittime > 0:
			tm = time()
			sleep(waittime)
			cpu_time[IDLE] = cpu_time[IDLE] + (time() - tm)
		msgs = self.pop_received()
		return self.process_list(msgs)

	def len_received(self):
		def len_rec():
			return len(self.received), sum([len(x[0]) for x in self.received])
		return restrict_access(len_rec)

	def append_received(self, l):
		def append():
			self.received = self.received + l
			return []
		return access_received(append)

	def pop_received(self):
		def replace():
			lold, self.received = self.received, []
			return lold
		return access_received(replace)

def access_received(fun):
	return restrict_access(fun, [])
