# Carlos Eduardo Lenz - PPGCC - UFSC
from math import ceil
from os.path import expanduser
from struct import unpack

from Block import PARTS_PER_BLOCK
from Logger import Logger
from Part import Part, HEADER_TYPE, OTHER_TYPE

def dummy_loader(path):
	return FileLoader(None, path, True, False)

def header_length(path):
	loader = dummy_loader(path)
	return loader.last

class FileLoader:
	def __init__(self, buffer, path, isSmart, isTest):
		self.pinfo = path + '.info'
		self.open_info()
		self.last = self.read_info_si32()
		if buffer:
			self.buffer = buffer
			self.skipped = self.pos = 0
			if isSmart:
				self.load = self.smart_load
				buffer.mdat_index = self.last
			else:
				self.load = self.trad_load
				buffer.mdat_index = int(ceil(float(self.last) / self.buffer.block_size))
			self.file = open(expanduser(path), 'rb')
			if isTest:
				self.file.seek(self.last)
				self.skipped = self.pos = self.last
				Logger.high('test mode: skipping header')
				buffer.mdat_index = 0
			Logger.high('mdat', self.last, 'index', self.buffer.mdat_index)

	def open_info(self):
		self.finfo = open(expanduser(self.pinfo), 'rb')

	def __call__(self):
		return self.load()

	def trad_load(self):
		b = self.file.read(self.buffer.block_size)
		if b:
			self.buffer.trad_append(b)
		else:
			self.buffer.mark_end()
		return b

	def read_info_si32(self):
		data = self.finfo.read(4)
		if len(data) < 4:
			return 0
		return unpack('!i', data)[0] # 32bit signed integer
	
	def read_info_offsets(self, until):
		l = []
		while self.last < until:
			sz = self.read_info_si32()
			isVid = True
			if sz == 0:
				break
			elif sz < 0:
				isVid = False
				sz = -sz
			l.append((self.last, sz, isVid))
			self.last = self.last + sz
		return l

	def around(self, pos): # special-case for Buffer.trad_lost
		sz = 0
		while self.last < pos:
			sz = self.read_info_si32()
			if sz < 0:
				sz = -sz
			self.last = self.last + sz
		# if already past pos, returns: x > pos, x
		return self.last - sz, self.last

	def smart_load(self):
		target = self.skipped + self.buffer.expected_start_stop(self.buffer.append_index)[1]
		if self.buffer.mdat_index <= self.pos:
			b = ''
			offsets = self.read_info_offsets(target)
			if offsets:
				first = offsets[0][0]
				last = sum(offsets[-1][:2])
				offsets = [(x[0] - self.skipped, x[1], x[2]) for x in offsets]
				if self.pos < first:
					size = first - self.pos
					Logger.panic('LEFT BEHIND', self.pos, first, size)
					offsets.insert(0, (self.pos - self.skipped, size, False))
					first = self.pos
				elif first < self.pos:
					Logger.panic('error loading', first, self.pos)
				size = last - first
				if size:
					b = (self.file.read(size), self.pos - self.skipped, offsets, OTHER_TYPE)
					self.pos = last
		else:
			l = self.read_info_offsets(target)
			offsets = [x[0] for x in l]
			if offsets:
				assert target > l[-1][0]
				Logger.high('ignore offsets', offsets, target)
			size = target - self.pos
			s = self.file.read(size)
			size, start, offsets = len(s), self.pos, []
			while size > 0:
				n = min(self.buffer.part_size, size)
				offsets.append((start - self.skipped, n, False))
				size = size - n
				start = start + n
			b = (s, self.pos - self.skipped, offsets, HEADER_TYPE)
			self.pos = target
		if b:
			self.buffer.smart_append(b)
		else:
			self.buffer.mark_end()
		return len(b)
