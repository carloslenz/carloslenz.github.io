#!/usr/bin/env python
from SocketServer import BaseRequestHandler, TCPServer

from datetime import datetime
from os import chdir, environ, getpid, kill, mkdir, system
from signal import SIGINT, SIGSEGV
from socket import gethostname
from subprocess import Popen, PIPE, STDOUT
from sys import argv

import re

HOSTNAME = gethostname()

MAX_RTT = 0.1
NETWORK_PORT = 17936

OK = 'ok'
MAYBE_OK = 'ok?'
FAILED = 'failed'

def all_nodes():
	return [s.split(',')[0].strip() for s in open('nodes/allnodes.txt')]
			
class ControlClient(BaseRequestHandler):
	def handler(self):
		cmd = self.request.recv(MSG_MAX_SIZE)
		if cmd == 'quit':
			cmd_quit()
		ret = self.process(cmd)
		if ret:
			self.request.send(ret)

	def process(self, cmd):
		return Popen([argv[0]] + cmd.split(), stdout=PIPE, stderr=STDOUT).communicate()[0]

class ControlServer(ControlClient):
	def process(self, cmd):
		l = cmd.split()
		kind = l.pop(0)
		if kind == 'all':
			who = all_nodes()
		elif kind == 'one':
			who = [l.pop(0)]
		cmd = ' '.join(cmd)
		self.send_all(cmd, who)
		return '%s\n%s' % (ControlClient.process(self, cmd), MAYBE_OK)

	def send_all(cmd, l):
		for hostname in l:
			if hostname != HOSTNAME:
				send_to(hostname, cmd)

def cmd_network(klass):
	TCPServer(('0.0.0.0', NETWORK_PORT), klass).serve_forever()

def cmd_disable():
	system('chmod -x $HOME/pyt/bin/serviso-test')

def cmd_deploy():
	system('PYTHONPATH=/home/rnp_LAPESD/pyt /home/rnp_LAPESD/pyt/bin/easy_install -q --install-dir=/home/rnp_LAPESD/pyt --prefix=/home/rnp_LAPESD/pyt http://www.inf.ufsc.br/~lenz/serviso-0.4dev-py2.5.egg')

def cmd_get_info():
	try:
		mkdir('samples')
	except OSError:
		pass
	chdir('samples')
	system('wget -q http://www.inf.ufsc.br/~lenz/tim_maia30m_small.mp4.info')

def cmd_prepare():
	environ['PYTHONPATH'] = environ['PYT'] = '%s/pyt' % environ['HOME']
	system('python site_info.py')
	system('mkdir pyt tmp samples 2> /dev/null')
	system('wget -q http://peak.telecommunity.com/dist/ez_setup.py')
	system('python ez_setup.py -q --prefix $PYT --install-dir $PYT -U setuptools')
	system('rm ez_setup.py samples/tim_maia.mp4* 2> /dev/null')
	for s in ('', '.info'):
		system('ln -s tim_maia30m_small.mp4%s samples/tim_maia.mp4%s 2> /dev/null' % (s, s))
	cmd_start_cron()

def cmd_start_cron():
	psout = Popen(['ps', '-C', 'crond', '-o', 'cmd'], stdout=PIPE).communicate()[0]
	if psout.strip() != 'CMD\ncrond':
		system('sudo /sbin/service crond start')

def cmd_interrupt():
	cmd_signal(SIGINT)

def cmd_kill():
	cmd_signal(SIGSEGV)

def cmd_signal(sig):
	me = getpid()
	for s in Popen('ps -C python -C serviso-test -o pid'.split(), stdout=PIPE).communicate()[0].split('\n'):
		try:
			pid = int(s)
			if pid != me:
				kill(pid, sig)
		except ValueError:
			pass

def cmd_ps():
	cmd = 'ps -C python -C serviso-test -o pid,ppid,start,rss,vsz,lim,command'
	me = getpid()
	rex = re.compile('^ *%d.*$' % me)
	for s in Popen(cmd.split(), stdout=PIPE).communicate()[0].split('\n'):
		if not rex.match(s):
			print s

def cmd_remove_logs():
	system('rm -f tmp/*')

def cmd_cron(option, hour, minute):
	dt = datetime.now()
	cmd_crontab('%s %s %d %d * python Control.py test cmds.txt %s > tmp/status.txt 2>&1\n' % (minute, hour, dt.day, dt.month, option))

def load_cfg_file(path):
	dict = {}
	for s in open(path).readlines():
		option,cmd = s.split('=')
		dict[option] = cmd
	return dict

def cmd_test(l):
	path = l.pop(0)
	option = l.pop(0)
	cfg = load_cfg_file(path)
	if option not in cfg:
		print 'File: "%s", option not found: "%s"' % (path, option)
		return
	s = cfg[option]
	print '>', s
	environ['PYTHONPATH'] = '%s/pyt' % environ['HOME']
	system(s)

def cmd_crontab(s):
	Popen(['crontab'], stdin=PIPE).communicate(s)

def cmd_no_crontab():
	system('crontab -r')

def cmd_query():
	system('crontab -l')

def cmd_send(s):
	server = open('server.txt').readlines()[0]
	send_to(server, s)

def send_to(hostname, s):
	sock = socket(AF_INET, SOCK_STREAM)
	sock.connect((hostname, NETWORK_PORT))
	sock.send(s)
	sock.close()

def cmd_goodnode(args):
	lok, lalmost, isfirst = [], [], True
	
	try:
		for s in open('allnodes.txt').readlines():
			l = s.split(',')
			name = l[0]
			rtt = float(l[1])
			nr_oks = int(l[-2])
			nr_noks = int(l[-1])
			isfirst = False
			if name != HOSTNAME and nr_oks:
				if rtt < MAX_RTT:
					lok.append(name)
				elif nr_oks > nr_noks:
					lalmost.append(name)
	except IndexError:
		if not isfirst:
			raise
		print 'Is crond running? Has the hourly link check been enabled?'
		exit()
	
	minok = 1
	prefix = ''
	verbose = False
	
	if args and args[0] == '-v':
			verbose = True
			args.pop(0)
	if args:
		try:
			minok = int(args[0])
			args.pop(0)
		except ValueError:
			pass
	
	if args:
		prefix = args[0]
	
	if len(lok) >= minok:
		if prefix:
			print prefix,
		print HOSTNAME, len(lok)
	elif verbose and len(lok) + len(lalmost) >= minok:
		if prefix:
			print prefix,
		print HOSTNAME, len(lok), ' '.join(lok), len(lalmost), ' '.join(lalmost)

if __name__ == '__main__':
	if len(argv) > 1:
		if argv[1] == 'server':
			cmd_network(ControlServer)
		elif argv[1] == 'client':
			cmd_network(ControlClient)
		elif argv[1] == 'disable':
			cmd_disable()
		elif argv[1] == 'deploy':
			cmd_deploy()
		elif argv[1] == 'prepare':
			cmd_prepare()
		elif argv[1] == 'start-cron':
			cmd_start_cron()
		elif argv[1] == 'get-info':
			cmd_get_info()
		elif argv[1] == 'interrupt':
			cmd_interrupt()
		elif argv[1] == 'kill':
			cmd_kill()
		elif argv[1] == 'ps':
			cmd_ps()
		elif argv[1] == 'remove-logs':
			cmd_remove_logs()
		elif argv[1] == 'cron':
			apply(cmd_cron, argv[2:5])
		elif argv[1] == 'schedule':
			cmd_kill()
			cmd_remove_logs()
			apply(cmd_cron, argv[2:5])
		elif argv[1] == 'no-crontab':
			cmd_no_crontab()
		elif argv[1] == 'query':
			cmd_query()
		elif argv[1] == 'send-server':
			cmd_send(' '.join(argv[2:]))
		elif argv[1] == 'goodnode':
			cmd_goodnode(argv[2:])
		elif argv[1] == 'test':
			cmd_test(argv[2:])
