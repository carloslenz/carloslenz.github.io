#!/usr/bin/env python

import sys, urllib, xmlrpclib, socket

api_server = xmlrpclib.ServerProxy('https://www.planet-lab.org/PLCAPI/')

auth = {}
auth['AuthMethod'] = "anonymous"
auth['Role'] = "user"

def site_info():
	hostname = socket.gethostname()
	query = api_server.GetNodes(auth, {'hostname': hostname}, ['site_id'])
	if not query:
		print >>sys.stderr, hostname
		return
	site_id = query[0]['site_id']
	fields = 'site_id name url latitude longitude login_base'.split(' ')
	site_info = api_server.GetSites(auth, {'site_id': site_id}, fields)[0]
	keys = keys = 'site_id name login_base url latitude longitude'.split(' ')
	return [hostname] + [str(site_info[x]) for x in keys]

def save():
	f = open('loc.txt', 'w')
	print >>f, ','.join(site_info())
	f.close()

if __name__ == '__main__':
	save()
