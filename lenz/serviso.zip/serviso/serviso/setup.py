from setuptools import setup, find_packages
import sys, os

version = '0.4'

setup(name='serviso',
      version=version,
      description="Selective Retransmission Video Streaming Overlay",
      long_description="""\
New Video Streaming P2P Overlay that handles losses through selective retransmission.""",
      classifiers=[], # Get strings from http://pypi.python.org/pypi?%3Aaction=list_classifiers
      keywords='video streaming p2p overlay',
      author='Carlos Eduardo Lenz',
      author_email='lenz@inf.ufsc.br',
      url='http://www.inf.ufsc.br/~lenz/serviso/',
      license='Private Beta (unreleased) Software',
      packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
      scripts = ['serviso-test'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          # -*- Extra requirements: -*-
      ],
      entry_points="""
      # -*- Entry points: -*-
      """,
      )
