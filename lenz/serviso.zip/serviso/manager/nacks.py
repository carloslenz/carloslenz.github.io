# Carlos Eduardo Lenz - PPGCC - UFSC

import os
import os.path

import serviso

import util

def load_nacks(target, sub, nackstm, nacksseg):
	stat = serviso.StatFile(os.path.join(target, sub))
	for x in stat.read([serviso.NACK]):
		tm = int(x[1])
		seg = x[2]
		if tm not in nackstm:
			nackstm[tm] = 0
		nackstm[tm] = nackstm[tm] + 1
		if seg not in nacksseg:
			nacksseg[seg] = 0
		nacksseg[seg] = nacksseg[seg] + 1

def nack(l):
	"""nack [-pSTEP] [DIR]: counts NACK/s"""
	step = 15
	if l and l[0][:2] == '-p':
		step = int(l.pop(0)[2:])
	if l:
		target = l.pop(0)
	else:
		target = util.find_target()
	f = open(os.path.join(target, 'nack.csv'), 'w')
	nackstm = {}
	nacksseg = {}
	nodes = 0
	for sub in os.listdir(target):
		if util.STATNAMEREX.match(sub):
			load_nacks(target, sub, nackstm, nacksseg)
			nodes = nodes + 1
	acctm = accseg = 0
	print >>f, 'I\tTM\tSEG\tACCTM\tACCSEG\tMAXSEG\tAVGTM\tAVGSEG\tAVGACCTM\tAVGACCSEG\tAVGMAXSEG'
	print >>f, '\t\t\t\t\t'
	last = 0
	if nackstm:
		last = max(nackstm)
	if nacksseg:
		last = max(last, max(nacksseg))
	for x in range(0, last, step):
		stop = x + step
		ltm = [nackstm[y] for y in range(x, stop) if y in nackstm]
		lseg = [nacksseg[y] for y in range(x, stop) if y in nacksseg]
		alltm = sum(ltm)
		allseg = sum(lseg)
		if alltm:
			acctm = acctm + alltm
		if allseg:
			accseg = accseg + allseg
		alltm = serviso.div_or_zero(alltm, step)
		allseg = serviso.div_or_zero(allseg, step)
		maxseg = 0
		if lseg:
			maxseg = max(lseg)
		acctmp = serviso.div_or_zero(acctm, stop)
		accsegp = serviso.div_or_zero(accseg, stop)
		avgtm = alltm / nodes
		avgseg = allseg / nodes
		avgacctmp = acctmp / nodes
		avgaccsegp = accsegp / nodes
		avgmaxseg = maxseg / nodes
		print >>f, '%d\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f' % (x, alltm, allseg, acctmp, accsegp, maxseg, avgtm, avgseg, avgacctmp, avgaccsegp, avgmaxseg)
