# Carlos Eduardo Lenz - PPGCC - UFSC

import datetime
import os
import re
import signal
import sys
import tempfile

import server
import subprocess
import util
import work

DEFAULT_INTERVAL = 5

def all_tests(l):
	"""all-tests [MODEs, [LOSS_RATEs,]]: opens a tab for each automated test"""
	modes, rates = ['trad', 'smart', 'adapt', 'mkf'], [0,20]
	if l:
		modes = l.pop(0).split(',')
		if l:
			rates = [int(x) for x in l.pop(0).split(',')]
	f = tempfile.NamedTemporaryFile()
	print >>f, '1 cd ~/exp;./x batch 2 delay 6 see'
	delay = 0
	for r in rates:
		for m in modes:
			modname, n = '%s%02d' % (m, r), -1
			while modname[-1] == '0':
				modname = modname[:-1]
			print >>f, '1 cd ~/exp;./x batch 2 delay %d 2 test %s' % (delay, modname)
			delay = delay + 60
	f.flush()
#	util.sysl(['cat', f.name])
	util.sysl([sys.argv[0], 'auto', f.name])
	f.close()

def jumbo(l=[]):
	"""jumbo:\t\tschedules link tests"""
	schedule(['jumbo'])
	util.sysl([sys.argv[0], 'delay', '3'])
	util.sysl([sys.argv[0], 'see'])

def cron(l, cmd='cron'):
	"""cron CFG:\tschedules a SeRViSO test"""
	when = datetime_in_minutes(DEFAULT_INTERVAL)
	do_all_nodes('python Control.py %s %s %d %d' % (cmd, l[0], when.hour, when.minute))

def schedule(l):
	"""schedule CFG:\tschedules a clear-state SeRViSO test"""
	cron(l, 'schedule')

def test(l):
	"""test CFG:\truns test and fetchs logs"""
	cfg = l.pop(0)
	util.sysl([sys.argv[0], 'schedule', cfg])
	util.sysl([sys.argv[0], 'delay', '42'])
	util.sysl([sys.argv[0], 'fetch-logs'])

def query(l):
	"""query [-all]:\tinspects node's crontab"""
	cmd = 'python Control.py query'
	if l and l[0] == '-all':
		do_all_nodes(cmd)
	else:
		server.ssh_server(cmd.split())

def do_all_nodes(s):
	ssh = 'ssh rnp_LAPESD@%%s %s' % s
	work.work_all_nodes(True, lambda name: ssh % name)

def datetime_in_minutes(minutes):
	now = datetime.datetime.utcnow()
	delta = datetime.timedelta(minutes=minutes)
	return now + delta

def skip(l):
	"""skip REGEX:\tkills a local process matching regex"""
	rex = re.compile(l.pop(0))
	for s in util.sysl(['ps', '-o', 'pid,command'], out=subprocess.PIPE)[0].split('\n'):
		l = s.split()
		try:
			pid = int(l.pop(0))
			if rex.search(' '.join(l)):
				os.kill(pid, signal.SIGTERM)
		except ValueError:
			pass
