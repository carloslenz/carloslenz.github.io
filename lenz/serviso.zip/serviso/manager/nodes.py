# Carlos Eduardo Lenz - PPGCC - UFSC

import sys

import server
import util
import work

def min_copy(l=[]):
	"""min-copy:\tuploads Control.py, allnodes, server, cmds cfgs"""
	util.sysc('%s put serviso/Control.py serviso/site_info.py nodes/allnodes.txt %s serviso/cmds.txt cfgs' % (sys.argv[0], server.SERVER_TXT))

def reset(l=[]):
	"""reset:\tremoves all files from nodes"""
	work.do_all_nodes('rm -rf * 2> /dev/null')

def update(l):
	"""update:\t\tupdates new version to planetlab nodes"""
	util.sysc('%s batch egg deploy clear' % sys.argv[0])
