# Carlos Eduardo Lenz - PPGCC - UFSC

import os
import os.path
import re
import subprocess
import sys

DIRNAMEREX = re.compile('\d{4}-\d{1,2}-\d{1,2}_\d{1,2}_\d{1,2}_\d{1,2}')
STATNAMEREX = re.compile('^(.*)stat.dat$')

def ssh(l):
	"""ssh NODE [CMD...]: logs to a node"""
	cmd, user, server = 'ssh', 'rnp_LAPESD', l.pop(0)
	uri = '%s@%s' % (user, server)
	print >>sys.stderr, '> %s %s %s' % (cmd, uri, ' '.join(l))
	os.execvp(cmd, [cmd, uri] + l)

def sysl(l, s=None, out=None, err=None, useCommunicate=True):
	print >>sys.stderr, '>', ' '.join(l)
	cmdin = None
	if s:
		cmdin = subprocess.PIPE
	proc = subprocess.Popen(l, stdin=cmdin, stdout=out, stderr=err)
	if useCommunicate:
		return proc.communicate(s)
	return proc

def sysc(cmd):
	print >>sys.stderr, '>', cmd
	ret = os.system(cmd)
	return not (ret & 255) and (ret & 255) == 0

def just_hostname(x):
	l = x.split(',')
	if len(l) > 1:
		return l[0]
	l = x.split()
	if len(l) > 1:
		return l[1]
	return x.strip()

def find_target():
	tmpdir, target = os.path.expanduser('~/tmp'), ''
	for sub in os.listdir(tmpdir):
		full = os.path.join(tmpdir, sub)
		if os.path.isdir(full) and DIRNAMEREX.match(sub) and target < full:
			target = full
	return target
