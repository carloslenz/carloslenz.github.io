# Carlos Eduardo Lenz - PPGCC - UFSC

import math
import os
import os.path
import sys

import serviso

import util

def block_size():
	cfg = serviso.Config()
	cfg.load_from_file('cfgs/basetrad')
	buf = serviso.Buffer(0, 0, 0, 0, 0, serviso.dummy_loader(cfg.path), None, True, serviso.DEFAULT_SELECT_ALGO, False)
	buf.set_block_size(cfg.block_size, False)
	return buf.block_size

BLOCK_SIZE = block_size()

def each_file(path, fun):
	for x in os.listdir(path):
		fname = os.path.join(path, x)
		if os.path.isfile(fname) or os.path.islink(fname):
			fun(fname)

def gunzip_dir(path, z):
	def gunzip(fname):
		if fname[-3:] == '.gz':
			ret = util.sysc('gzip -dc %s > %s' % (fname, fname[:-3]))
			if z == 2:
				os.remove(fname)
	each_file(path, gunzip)

def stat(l):
	"""stat [-z[z] | [-pSTEP]] [DIR]: generates stat CSV"""
	path, z, preproc = os.path.expanduser('~/tmp'), 0, 5
	if l and l[0][0] == '-':
		if l[0][:2] == '-z':
			z = 1
			if l.pop(0) == '-zz':
				z = 2
		elif l[0][:2] == '-p':
			preproc = int(l.pop(0)[2:])
	if l:
		path = l.pop(0)
	if z:
		gunzip_dir(path, z)
	else:
		e = Extractor()
		e.setdir(path)
		e.process_times(preproc)
		e.print_results()

def msgs(l):
	"""msgs [-pSTEP] [DIR]: generates msgs CSV"""
	step = 30
	if l and l[0][:2] == '-p':
		step = int(l.pop(0)[2:])
	if l:
		target = l.pop(0)
	else:
		target = find_target()
	e = Extractor(False)
	e.setdir(target)
	e.process_times(step)
	e.print_results()

STAT_ITEMS = 42

class Extractor:
	def __init__(self, general=True):
		self.res = []
		self.stats = {}
		self.partials = {}
		self.limit = 0
		if general:
			self.n = 7
			self.basefname = 'stat'
			self.loadf = self.loadfile
			self.count = self.count_general
			self.baseheader = ['I', 'CONTROL', 'OVERHEAD', 'QDATA', 'OUT', 'LATE', 'LOST', 'READ', 'NR_OUT', 'NR_READ', 'DIF_CONTROL', 'DIF_OVERHEAD', 'DIF_QDATA', 'DIF_OUT', 'DIF_LATE', 'DIF_LOST', 'DIF_READ']
			self.do_rates = self.do_rates_general
			self.adjust_line = self.adjust_line_general
		else:
			self.n = 32
			self.basefname = 'msgs'
			self.loadf = self.loadmsgs
			self.count = lambda i: []
			ltmp = ['TFRC', 'FEEDBACK', 'ENTER', 'LEAVE', 'NODES', 'PARTNER', 'DATA', 'BMAP', 'REQUEST', 'NACK', 'GOSSIP', 'QNACK', 'QDATA', 'MULTI', 'START', 'METADATA']
			self.baseheader = ltmp + ['LEN%s' % x for x in ltmp]
			self.do_rates = self.do_rates_msgs
			self.adjust_line = self.adjust_line_msgs

	def setdir(self, path):
		self.fstat = open(os.path.join(path, '%s.csv' % self.basefname), 'w')
		each_file(path, self.loadf)

	def loadmsgs(self, path):
		if path[-4:] == '.dat':
			stats = serviso.StatFile(path)
			def select_stats(x):
#  0 B code == 1
#  1 d time
#      ...
# 10 I tfrc
# 11 I feedback
# 12 I enter
# 13 I leave
# 14 I nodes
# 15 I partner
# 16 I data
# 17 I bmap
# 18 I request
# 19 I nack
# 20 I gossip
# 21 I qnack
# 22 I qdata
# 23 I multi
# 24 I start
# 25 I metadata
				if len(x) != STAT_ITEMS:
					print 'LEN STAT', x
					exit(-1)
				return [x[1]] + list(x[10:STAT_ITEMS]) + [x[2]]
			l = [select_stats(x) for x in stats.read([serviso.SUMMARY])]
			if l:
				self.limit = max(self.limit, int(math.ceil(l[-1][0])))
				self.stats[path] = l

	def loadfile(self, path):
		if path[-4:] == '.dat':
			print >>sys.stderr, 'IN', path
			stats = serviso.StatFile(path)
			def select_stats(x):
#  0 B code == 1
#  1 d time ********
#  2 H read_index ********
#  3 I control ********
#  4 I extra ********
#  5 I qdata ********
#  6 I nout ********
#  7 I latebytes ********
#  8 I lost ********
#  9 I nread ********
#      ...
				if len(x) != STAT_ITEMS:
					print 'LEN STAT', x
					exit(-1)
				return [x[1]] + list(x[3:10]) + [x[2]]
			l = [select_stats(x) for x in stats.read([serviso.SUMMARY])]
			if l:
				self.limit = max(self.limit, int(math.ceil(l[-1][0])))
				self.stats[path] = l

	def process_times(self, step):
		self.do_partials()
		self.do_sum()
		if self.res:
			self.do_diffs()
			if step:
				self.to_minutes(step)
			self.do_rates()

	def adjust_line_msgs(self, l):
		return l[-1][:1] + self.lproc(l, 1, 1 + 2 * self.n)

	def lproc(self, line, a, b, f=lambda ll: sum(ll) / len(ll)):
		return [f([x[i] for x in line]) for i in range(a, b)]

	def adjust_line_general(self, l):
		for l1 in l:
			if len(l1) != (3 + 2 * self.n):
				print 'ADJ', self.n, l1
				exit(-1)
		return l[-1][: self.n] + self.lproc(l, self.n, self.n + 2, max) + self.lproc(l, self.n + 2, 2 * self.n + 3)

	def to_minutes(self, preproc):
		target, first = preproc, self.res.pop(0)
		newRes = [first]
		assert first[0] == 0
		while self.res:
			l = [self.res.pop(0)]
			while self.res and self.res[0][0] <= target:
				l.append(self.res.pop(0))
			newRes.append(self.adjust_line(l))
			target = target + preproc
		self.res = newRes

	def do_partials(self):
		for x in self.stats:
			lines = self.stats[x]
			def do_i(i):
				ln1, ln2 = self.lines_around(i, lines)
				return self.approx(i, ln1, ln2)
			self.partials[x] = [do_i(i) for i in range(0, self.limit)]

	def count_general(self, i):
		return [len([1 for x in self.partials.values() if x[i][j] > x[i-1][j]]) for j in (2, 4)]

	def do_sum(self):
		print >>sys.stderr, 'COUNT', len(self.partials)
		print >>sys.stderr, 'LIMIT', self.limit
		def sum_i(i):
			def sum_i_j(i, j):
				for x in self.partials.values():
					if len(x[i]) <= self.n:
						print >>sys.stderr, 'size', self.n, i, x[i]
						exit(1)
				return sum([x[i][j] for x in self.partials.values()])
			return [sum_i_j(i, j) for j in range(1, self.n + 1)]
		self.res = [[i] + sum_i(i) + self.count(i) for i in range(0, self.limit)]

	def do_diffs(self):
		first = self.res[0] + ([0] * self.n)
		def with_diffs(x):
			if len(self.res[x]) < self.n + 1:
				print 'DIF LEN', self.n, self.res[x]
				exit(-1)
			def smart_diff(j):
				dif = self.res[x][j]
				if dif != 0:
					assert dif > 0
					dif = dif - self.res[x - 1][j]
					if dif < 0:
						err =  -dif / self.res[x - 1][j]
						ignoreStart = 60
						if self.limit > 3 * ignoreStart:
							ignoreStart = 10
						if err > 0.05 and ignoreStart <= x < min(self.limit - 20, 1825):
							print 'NEG', dif, j, err
							print self.res[x - 2]
							print self.res[x - 1]
							print self.res[x]
							print self.res[x + 1]
							print self.res[x + 2]
							# search causes in self.partials ???
							#exit(-1)
						dif = 0 # because of approx, negative values may arise
				return dif
			return self.res[x] + [smart_diff(j) for j in range(1, self.n + 1)]
		self.res = [first] + [with_diffs(x) for x in range(1, len(self.res))]

	def do_rates_msgs(self):
		columns = self.baseheader + ['DIF_%s' % x for x in self.baseheader]
		columns = columns + ['%s%%' % x for x in columns]
		header = [['I'] + columns, []]
		mid, mid2 = self.n / 2 + 1, 3 * self.n / 2 + 1
		def with_rates(line):
			if len(line) != 1 + 2 * self.n:
				print 'LEN ERR', self.n, len(line), line
				exit(-1)
			sumacc = sum(line[1 : mid])
			ratesacc = [100 * serviso.div_or_zero(line[i], sumacc) for i in range(1, mid)]
			sumlenacc = sum(line[mid : self.n + 1])
			rateslenacc = [100 * serviso.div_or_zero(line[i], sumacc) for i in range(mid, self.n + 1)]
			sumdif = sum(line[self.n + 1 : mid2])
			ratesdif = [100 * serviso.div_or_zero(line[i], sumdif) for i in range(self.n + 1, mid2)]
			sumdif = sum(line[mid2 : len(line)])
			rateslendif = [100 * serviso.div_or_zero(line[i], sumdif) for i in range(mid2, len(line))]
			return line + ratesacc + rateslenacc + ratesdif + rateslendif
		self.res = header + [with_rates(line) for line in self.res]

	def do_rates_general(self):
		columns = self.baseheader + ['DIF_BASE', 'NCONTROL', 'NOVERHEAD', 'NQDATA', 'NBASE', 'NOUT', 'NLATE', 'NLOST', 'NREAD', 'RELCONTROL', 'RELOVERHEAD', 'RELQDATA', 'RELBASE', 'RELOUT', 'CONTROL%', 'EXTRA', 'QDATA%', 'LATE%', 'LOSS', 'ACC_CONTROL%', 'ACC_EXTRA', 'ACC_QDATA%', 'ACC_LATE%', 'ACC_LOSS', 'ACC_BASE']
		labels = ['instant', 'control bytes', 'retransmitted bytes', 'transmitted (QDATA) bytes', 'transmitted bytes', 'late bytes', 'lost bytes', 'read bytes', 'hosts transmitting', 'hosts reading', 'control bytes by period', 'transmitted (QDATA) bytes by period', 'retransmitted bytes by period', 'transmitted bytes by period', 'late bytes by period', 'lost bytes by period', 'read bytes by period'] + ['out - overhead - control - qdata', 'control / block_size', 'overhead / block_size', 'qdata / block_size', 'base / block_size', 'out / block_size', 'late / block_size', 'lost / block_size', 'read / block_size', 'control / block_size / nrNodes', 'overhead / block_size / nrNodes', 'qdata / block_size / nrNodes', 'base / block_size / nrNodes', 'out / block_size / nrNodes', 'control / base by period', 'overhead / base by period', 'qdata / base by period', 'late / read by period', 'lost / read by period', 'overhead / base', 'qdata / base', 'late / read', 'lost / read', 'accout - accoverhead - acccontrol - accqdata']
		header = [columns, labels]
		nrNodes = len(self.stats)
		global prev
		prev = None
		def with_rates(line):
			acccontrol, accoverhead, accqdata, accout, acclate, acclost, accread = line[1 : self.n + 1] # cumulative
			try:
				control, overhead, qdata, out, late, lost, read = line[self.n + 3 : 3 + 2 * self.n]
			except:
				print line
				exit(-1)
			base = out - overhead - control - qdata
			global prev
			if base < 0:
				if line[0] < min(self.limit - 20, 0.975 * self.limit, 1825):
					print 'BASE', base, out, overhead, control, qdata
					print 'PREV', prev
					print 'LINE', line
					assert base > -0.1
				base = 0  # because of approx, negative values may arise
			ncontrol = serviso.div_or_zero(control, BLOCK_SIZE)
			noverhead = serviso.div_or_zero(overhead, BLOCK_SIZE)
			nqdata = serviso.div_or_zero(qdata, BLOCK_SIZE)
			nbase = serviso.div_or_zero(base, BLOCK_SIZE)
			nout = serviso.div_or_zero(out, BLOCK_SIZE)
			nlate = serviso.div_or_zero(late, BLOCK_SIZE)
			nlost = serviso.div_or_zero(lost, BLOCK_SIZE)
			nread = serviso.div_or_zero(read, BLOCK_SIZE)
			relcontrol = serviso.div_or_zero(ncontrol, nrNodes)
			reloverhead = serviso.div_or_zero(noverhead, nrNodes)
			relqdata = serviso.div_or_zero(nqdata, nrNodes)
			relbase = serviso.div_or_zero(nbase, nrNodes)
			relout = serviso.div_or_zero(nout, nrNodes)
			controlp = serviso.div_or_zero(control, base) * 100
			extra = serviso.div_or_zero(overhead, base) * 100
			qdatap = serviso.div_or_zero(qdata, base) * 100
			latep = serviso.div_or_zero(late, read) * 100
			loss = serviso.div_or_zero(lost, read) * 100
			accbase = accout - accoverhead - acccontrol - accqdata
			acccontrolp = serviso.div_or_zero(acccontrol, accbase) * 100
			accextra = serviso.div_or_zero(accoverhead, accbase) * 100
			accqdatap = serviso.div_or_zero(accqdata, accbase) * 100
			acclatep = serviso.div_or_zero(acclate, accread) * 100
			accloss = serviso.div_or_zero(acclost, accread) * 100
			prev = line
			return line + [base, ncontrol, noverhead, nqdata, nbase, nout, nlate, nlost, nread, relcontrol, reloverhead, relqdata, relbase, relout, controlp, extra, qdatap, latep, loss, acccontrolp, accextra, accqdatap, acclatep, accloss, accbase]
		self.res = header + [with_rates(line) for line in self.res]

	def lines_around(self, i, l):
		zeroes, DOESNT_EXIST = [0] * self.n, 50000
		prev, next = [[x] + zeroes for x in (0, DOESNT_EXIST)]
		while l:
			line = l[0]
			if line[0] == i:
				while l[0] == i:
					prev = next = l[0]
					l.pop(0)
				break
			elif prev[0] <= line[0] < i:
				prev = line
				next[1:] = line[1:]
			elif i < line[0] < next[0]:
				next = line
				break
			l.pop(0)
		if next[0] == DOESNT_EXIST:
			next = prev
		return (prev, next)

	def approx(self, i, ln1, ln2):
		period_dif = ln2[0] - ln1[0]
		if period_dif < 0:
			print >>sys.stderr, 'PERIOD', ln1, ln2
		def at_i(idx):
			coef = (ln2[idx] - ln1[idx]) / max(period_dif, 0.0001)
			xdif = i - ln1[0]
			ydif = coef * xdif
			y = ln1[idx] + ydif
			if y < 0:
				print >>sys.stderr, 'NEG', idx, y, 'lines', ln1, ln2
			return y
		return [i] + [at_i(idx) for idx in range(1, len(ln1))]

	def print_results(self):
		for x in self.res:
			line = ''
			for y in x:
				line = line + ('%s\t' % str(y))
			print >>self.fstat, line
