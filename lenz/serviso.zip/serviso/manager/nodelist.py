# Carlos Eduardo Lenz - PPGCC - UFSC

import heapq
import sys
import work

import util

def dashes(s):
	if s[:3] == '-- ':
		name, prio = s[3:].split()
		return name, int(prio)
	return None

def simple(s):
	parts = s.split()
	if s[0] != '-' and len(parts) == 2:
		return parts[0], int(parts[1])
	return None

def sort_nodes(l):
	"""sort-nodes [simple]: sorts goodnodes in descending order"""
	f = dashes
	if l and l[0] == 'simple':
		f = simple
	l = []
	for s in sys.stdin:
		if s:
			v = f(s)
			if v:
				heapq.heappush(l, (-v[1], v[0], v[1]))
	while l:
		name, prio = heapq.heappop(l)[1:]
		print name, prio

def goodnodes(l):
	"""goodnodes [PREFIX] [CMD..]: which nodes have a good number of fast links"""
	wait_all = False
	cmd = 'python Control.py goodnode 40 --'
	if l:
		start = 0
		if 'A' in l[0]:
			start = 1
			wait_all = True
		if 'S' in l[0]:
			start = 1
			sys.stdout = open('nodes/good.txt', 'w')
		l = l[start:]
		if l:
			cmd = ' '.join(l)
	ssh = 'ssh rnp_LAPESD@%%s %s' % cmd
	work.work_all_nodes(wait_all, lambda name: ssh % name)

def chkname(s):
	if s[0] == '-':
		s = s[1:]
	s = s.split(',')
	return s[0].strip()

def filter_append(l):
	"""filter-append IGNORE-F FORBIDDEN-F FAILED-F: avoids failed nodes"""
	all = [s.strip() for s in sys.stdin.readlines() if s]
	rmv = [s[1:] for s in all if s[0] == '-']
	add = [s for s in all if s[0] != '-']
	assert l
	ignore = set([s.split()[0] for s in open(l.pop(0)).readlines()])
	forbidden = []
	if l:
		forbidden = [chkname(s) for s in open(l.pop(0)).readlines()]
		if l:
			failed = [chkname(s) for s in open(l.pop(0)).readlines()]
			forbidden = forbidden + failed
	forbidden = set(forbidden)
	for s in add:
		if s not in forbidden:
			print s
		else:
			print >>sys.stderr, '-%s' % s
	for s in rmv:
		if s in ignore:
			print >>sys.stderr, s
		else:
			print '-%s' % s

def read_txt(fname):
	return set([util.just_hostname(ln) for ln in open(fname).readlines()])

def prep_append(l):
	"""prep-append:\tfills append.txt with +- from old/new node list"""
	oldname, newname = l[:2]
	olds = read_txt(oldname)
	news = read_txt(newname)
	rmvs = olds - news
	adds = news - olds
	for x in rmvs:
		print '-%s' % x
	for x in adds:
		print x
