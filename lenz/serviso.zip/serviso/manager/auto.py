# Carlos Eduardo Lenz - PPGCC - UFSC

import re
import subprocess

import serviso

def execCfgFile(path, args):
	execCfg(serviso.read_file_lines(path), args)

def execCfg(lines, args):
	cfg = loadCfg(lines, args)
	cmds = commandsFor(cfg)
	osaTabsRunCmds(cmds)

def commandsFor(cfg):
	cmds = []
	for l in cfg:
		if l:
			nr,s = l
			if isinstance(nr, int):
				for q in range(0, nr):
					cmds.append(s)
			else:
				cmds.append(sshCmd(nr, '', s))
	return cmds

def sshCmd(host, l):
	return 'ssh rnp_LAPESD@%s %s' % (host, ' '.join(l))

def loadCfg(lines, args):
	l, names = preProc(lines, args)
	return [replaceNames(nr, s, names) for nr,s in l]

REGEX = re.compile(r'\$[a-zA-Z0-9][a-zA-Z0-9]*')

def replaceNames(nr, s, names):
	def replace(m):
		found = m.group(0)
		if found in names:
			return names[found]
		return found
	if isinstance(nr, str):
		nr = REGEX.sub(replace, nr)
	return (nr, REGEX.sub(replace, s))

def preProc(lines, args):
	names = {}
	def convert(s):
		parts = serviso.strip_nl(s).split(' ')
		if len(parts) == 1:
			parts.append('')
		first = parts.pop(0)
		if first == '-':
			assert len(parts) <= len(args)
			for i in range(0, len(parts)):
				names['$' + parts[i]] = args[i]
		else:
			try:
				first = int(first)
			except:
				pass
			return [first, ' '.join(parts)]
		return []
	l = [convert(x) for x in lines]
	return ([q for q in l if q], names)

def osaTabsRun(cmds):
	lines = ['tell application "Terminal"', '\tactivate']
	for s in cmds:
		lines.append('\ttell application "System Events" to tell process "Terminal" to keystroke "t" using command down')
		lines.append('\tdelay 0.2')
		lines.append('\tdo script "%s" in window 1' % s)
	lines.append('end tell\n')
	return '\n'.join(lines)

def runWithInput(cmd, s, err=None):
	subprocess.Popen([cmd], stdin=subprocess.PIPE, stderr=err).communicate(s)

def osaTabsRunCmds(cmds):
	script = osaTabsRun(cmds)
	print script,
	runWithInput('osascript', script)

def cocoa(l):
	"""cocoa:\t\truns CocoaSeRViSO.app control gui"""
	runWithInput('osascript', 'tell application "CocoaSeRViSO"\n\tactivate\nend tell\n')

def auto(l):
	"""auto [ssh NODES | CFG ARGS]: parallel Terminal.app tabs"""
	path = l.pop(0)
	if path == 'ssh':
		osaTabsRunCmds([sshCmd(x, []) for x in l])
	else:
		execCfgFile(path, l)
