# Carlos Eduardo Lenz - PPGCC - UFSC

import os
import os.path
import re

import serviso

import util

STATS = ('avail', 'lost', 'msgs', 'nack', 'stat')
EXPGRPREX = re.compile('(\d{1,2})([A-Z])')

FILTER = {
	'avail': lambda l: [],
	'lost': lambda l: [l[0], l[30], l[40], l[42], l[44]] + l[51:54],
	'msgs': lambda l: [],
	'nack': lambda l: [l[0], l[8]],
	'stat': lambda l: [l[0]] + l[36:41]
}

def avg(l):
	"avg DIR:\tjoins the results of several experiment runs into an average"
	if not l:
		l = ['~/tmp/Experiment']
	basepath = os.path.expanduser(l.pop(0))
	dict, algos, errrates, grps = load_CSVs(basepath)
	cols = {}
	for stat in STATS:
		for errrate in errrates:
			avgs = {}
			for algo in algos:
				l = join_CSV(dict, avgs, cols, algo, errrate, grps, stat)
				store_CSV(basepath, l, algo, errrate, stat)
			store_table(basepath, errrate, stat, avgs, cols)

def load_CSVs(basepath):
	dict, algos, errrates, grps = {}, set([]), set([]), set([])
	for ex in os.listdir(basepath):
		m = EXPGRPREX.match(ex)
		if m:
			errrate, grp = m.group(1, 2)
			errrates.add(errrate)
			grps.add(grp)

			if errrate not in dict:
				dict[errrate] = {}
			assert grp not in dict[errrate]
			
			dict[errrate][grp] = grpdict = {}

			grpbase = os.path.join(basepath, ex)
			for test in os.listdir(grpbase):
				if util.DIRNAMEREX.match(test):
					algo = test.split('-')[3]
					assert algo
					assert algo not in grpdict
					algos.add(algo)
					grpdict[algo] = algodict = {}
					
					basedir = os.path.join(grpbase, test)
					for stat in STATS:
						statpath = '%s/%s.csv' % (basedir, stat)
						try:
							lines = serviso.read_file_lines(statpath)
							if lines:
								algodict[stat] = [ln.strip().split('\t') for ln in lines]
						except IOError:
							pass
	return dict, algos, errrates, grps

def CSV_line(dict, grps, algo, stat):
	return [dict[grp][algo][stat] for grp in grps if len(dict[grp][algo][stat]) > 2]

def join_CSV(dict, avgs, cols, algo, errrate, grps, stat):
	dict = dict[errrate]
	res = []
	l = CSV_line(dict, grps, algo, stat)
	while l:
		lines = [x.pop(2) for x in l]

		index = lines[0].pop(0) # first col
		if int(index) > 1860:
			break

		line = [index]
		for i in range(1, len(lines)):
			if line[0] != lines[i].pop(0):
				print res
				print lines
				print line
				assert False

		while lines[0]:
			lcol = [float(ln.pop(0)) for ln in lines]
			line.append(str(sum(lcol) / len(lcol))) # average
		for i in range(1, len(lines)):
			if lines[i]:
				print len(res), grps, line
				print lines
				assert False

		res.append(line)
		if index == '1800':
			assert algo not in avgs
			avgs[algo] = line[1:]
		l = CSV_line(dict, grps, algo, stat)
	res = dict[list(grps)[0]][algo][stat][0:2] + res # preserve header lines
	if stat not in cols:
		cols[stat] = ['Algoritmo'] + res[0][1:]
	return res

def store_CSV(basepath, l, algo, errrate, stat):
	base = '%s/union/%s/0000-00-00_00_00_00-%s' % (basepath, errrate, algo)
	if not os.path.exists(base):
		os.makedirs(base)
	fname = '%s/%s.csv' % (base, stat)
	open(fname, 'w').writelines(['%s\n' % '\t'.join(line) for line in l])

def store_table(basepath, errrate, stat, avgs, cols):
	base = '%s/union/%s/tables' % (basepath, errrate)
	if not os.path.exists(base):
		os.makedirs(base)
	fname = '%s/%s.tex' % (base, stat)
	filter_lines = FILTER[stat]
	lines = [cols[stat]] + [[algo] + avgs[algo] for algo in avgs]
	filtered = [filter_lines(l) for l in lines]
	if filtered[0]:
		open(fname, 'w').writelines(['%s\\\\\n' % ' & '.join(l) for l in filtered])
