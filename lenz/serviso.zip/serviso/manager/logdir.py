# Carlos Eduardo Lenz - PPGCC - UFSC

import os
import os.path
import re
import sys

import util

def logdir_clean(target1, *ignore):
	statlinkrex = re.compile('\d{1,5}stat.dat')
	statcsvpngrex = re.compile('stat(\.csv|.*\.png)')
	for sub in os.listdir(target1):
		full = os.path.join(target1, sub)
		if statlinkrex.match(sub):
			print >>sys.stderr, 'LINK', full
			os.unlink(full)
		elif os.path.isdir(full):
			for name in os.listdir(full):
				if statcsvpngrex.match(name):
					fname = os.path.join(full, name)
					print >>sys.stderr, 'PLOT', fname
					os.unlink(fname)
		elif statcsvpngrex.match(sub):
			print >>sys.stderr, 'PLOT', full
			os.unlink(full)

def logdir(target1, keep, individual, plot, step):
	n = 1
	for sub in os.listdir(target1):
		full = os.path.join(target1, sub)
		if os.path.isdir(full):
			l = os.listdir(full)
			if l:
				found = False
				for fname in l:
					m = util.STATNAMEREX.match(fname)
					if m:
						fullname = os.path.join(full, fname)
						dest = os.path.join(sub, fname)
						os.symlink(dest, '%s/%dstat.dat' % (target1, n))
						n = n + 1
						found = True
				if found:
					print >>sys.stderr, 'PROCESSING', full #, 'FILES', ' '.join(l)
					if individual:
						util.sysl([sys.argv[0], 'plot-stat', '-extract%s' % step, full])
						util.sysl([sys.argv[0], 'plot-nack', '-extract%s' % step, full])
						util.sysl([sys.argv[0], 'plot-lost', '-extract%s' % step, full])
						util.sysl([sys.argv[0], 'plot-avail', '-extract%s' % step, full])
						util.sysl([sys.argv[0], 'plot-msgs', '-extract%s' % step, full])
					continue
				elif not l:
					pass
				elif [x for x in l if '-disabled' != x[-9:]]:
					if not keep:
						print >>sys.stderr, 'USELESS', full, ' '.join(l)
#						continue
						for fname in l:
							os.unlink(os.path.join(full, fname))
					else:
						continue
				else:
					print >>sys.stderr, 'DISABLED', full
#					util.sysl([sys.argv[0], 'stat', full])
					continue
			print >>sys.stderr, 'EMPTY', full
			os.rmdir(full)
	if plot:
		util.sysl([sys.argv[0], 'plot-stat', '-extract%s' % step, target1])
		util.sysl([sys.argv[0], 'plot-nack', '-extract%s' % step, target1])
		util.sysl([sys.argv[0], 'plot-lost', '-extract%s' % step, target1])
		util.sysl([sys.argv[0], 'plot-avail', '-extract%s' % step, target1])
		util.sysl([sys.argv[0], 'plot-msgs', '-extract%s' % step, target1])
	else:
		util.sysl([sys.argv[0], 'stat', '-p%s' % step, target1])
		util.sysl([sys.argv[0], 'nack', '-p%s' % step, target1])
		util.sysl([sys.argv[0], 'lost', '-p%s' % step, target1])
		util.sysl([sys.argv[0], 'avail', '-p%s' % step, target1])
		util.sysl([sys.argv[0], 'msgs', '-p%s' % step, target1])

def logdir_options(s, f = logdir, keep = False, individual = False, plot = False, step = '30'):
	if s == '-clean':
		f = logdir_clean
	elif s[:2] == '-p':
		s = s[2:]
		if s:
			int(s)
			step = s
	else:
		s = s[1:]
		if 'k' in s:
			keep = True
		if 'i' in s:
			individual = True			
		if 'P' in s:
			plot = True
	return f, keep, individual, plot, step

def log_dir(l):
	"""log-dir [DIR] [-clean|[-p[STEP]] -[k][i][P]]: process log directories"""
	f, keep, individual, plot, step  = logdir_options('')
	if l and l[0] != '-':
		target = l.pop(0)
	else:
		target = util.find_target()
	if target:
		print >>sys.stderr, 'TARGET', target
	else:
		exit()
	if l and l[0][0] == '-':
		f, keep, individual, plot, step = logdir_options(l.pop(0))
		if l and l[0][0] == '-':
			f, keep, individual, plot, step = logdir_options(l.pop(0), f, keep, individual, plot, step)
	f(target, keep, individual, plot, step)
