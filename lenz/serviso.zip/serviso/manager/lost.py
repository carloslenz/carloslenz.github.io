# Carlos Eduardo Lenz - PPGCC - UFSC

import math
import os
import os.path
import re
import struct

import serviso

import util

KINDS = { 255: 'H', 0: 'N', 1: 'NIDR', 2: '1A', 3: '2B', 4: '3C', 5:  'IDR', 6: 'SEI', 7: 'SPS', 8: 'PPS', 9: 'Z', 10: 'Z', 11: 'Z', 12: 'Z', 13: 'SPSE', 14: 'I', 15: 'P', 16: 'B', 17: 'O' }

NEEDED = ['I-LOST', 'I', 'P-LOST', 'P', 'B-LOST', 'B', 'O-LOST', 'O', 'ALL-LOST', 'ALL']

class StatKeeper():
	def __init__(self):
		self.store = {}
		self.count = 0

	def add(self, kind, size, trailing=''):
		if kind in ('H', '1A', 'IDR', 'SEI', 'SPS', 'PPS', 'SPSE'):
			kind = 'I'
		elif kind in ('NIDR', '2B', '3C'):
			kind = 'B'
		name = kind + trailing
		allname = 'ALL' + trailing
		if name not in self.store:
			self.store[name] = 0
			if allname not in self.store:
				self.store[allname] = 0
		self.store[name] = self.store[name] + size
		self.store[allname] = self.store[allname] + size

	def lost(self, kind, size):
		self.add(kind, size, '-LOST')
		self.count = self.count + 1

	def report(self):
		for name in NEEDED:
			self.add(name, 0) # ensure it is there
		avg = serviso.div_or_zero(self.store['ALL-LOST'], self.count)
		return [self.store[x] for x in NEEDED]

class StatLost:
	def __init__(self, details='~/samples/tim_maia.mp4.details'):
		self.load_parts(details)

	def load_parts(self, details):
		start, sz, f = 0, struct.calcsize(serviso.ENCODE_FMT), open(os.path.expanduser(details))
		self.parts = []
		s = f.read(sz)
		used = set([])
		while s:
			size, kind = struct.unpack(serviso.ENCODE_FMT, s)
			if kind not in KINDS:
				kind = 17
			kind = KINDS[kind]
#			print kind, start
			self.parts.append((start, size, kind))
			used.add(kind)
			start, s = start + size, f.read(sz)
		print sorted(used)

	def put_status(self, sec, l):
		if sec not in self.stats:
			self.stats[sec] = l
		else:
			before = self.stats[sec]
			assert len(before) == len(l)
			self.stats[sec] = [l[q] + before[q] for q in range(0, len(l))]

	def select_lost(self, x):
		if x[4]:
			return None
		return x[1:4]

	def lost_lines(self, target, sub):
		fname = os.path.join(target, sub)
		stat = serviso.StatFile(fname)
		lines = stat.read([serviso.LOST])
		ll = [y for y in [self.select_lost(x) for x in lines] if y]
		return ll

	def setdir(self, target):
		self.target = target
		self.stats = {}
		self.rates = {}
		for sub in os.listdir(target):
			if util.STATNAMEREX.match(sub):
				ll = self.lost_lines(target, sub)
				self.idx = 0
				lsti = lstp = lstb = lsto = lst = alli = allp = allb = allo = all = count = 0
				keeper = StatKeeper()
				sm = 0
				def poppart():
					l, self.idx = self.parts[self.idx], self.idx + 1
					keeper.add(l[2], l[1])
					return l, sum(l[:2])
				part, stop = poppart()
				limit, last, i, broken = 1, 0, 0, 0
				while i < len(ll):
					tm, start, size = ll[i]
					i = i + 1
					while tm > limit:
						self.put_status(limit - 1, keeper.report())
						keeper, limit = StatKeeper(), limit + 1
					if last > start:
						size, start = size + start - last, last
						if not size:
							continue
					while self.idx < len(self.parts) and stop <= start:
						part, stop = poppart()
					if self.idx >= len(self.parts) and stop <= start:
						continue
					if start != part[0]:
						broken = broken + 1
					keeper.lost(part[2], part[1])
					sm = sm + part[1]
					last = stop
					miss = start + size - stop
					if miss > 0:
						i = i - 1 # replace and repeat
						ll[i] = (tm, last, miss)
					elif miss < 0:
						broken = broken + 1
				if keeper.store:
					self.put_status(limit - 1, keeper.report())
				end = sum(self.parts[-1][:2])
				rt = 100 * float(sm) / end
				rtBroken = 100 * serviso.div_or_zero(float(broken), 2 * len(ll))
				self.rates[sub] = rt, rtBroken
				print '%s\t%d\t%d%%\t%d%%' % (sub, len(ll), int(rt), int(rtBroken))

	def accumulate(self):
		n = len(NEEDED)
		nn = n + n
		prev = [0] * n
		for l in self.stats.values():
			assert len(l) == n
			acc = [l[i] + prev[i] for i in range(0, len(NEEDED))]
			l.extend(acc)
			assert len(l) == nn
			prev = acc

	def check_rates(self):
		avg = [sum([x[i] for x in self.rates.values()]) / len(self.rates) for i in (0, 1)]
		stdev = [math.sqrt(sum([(x[i] - avg[i]) ** 2 for x in self.rates.values()]) / len(self.rates)) for i in (0, 1)]
		limits = [int(avg[0] - stdev[0]), int(avg[0] + stdev[0])]
		limits2 = [int(avg[0] - 2 * stdev[0]), int(avg[0] + 2 * stdev[0])]
		bad = [name for name,rates in self.rates.iteritems() if not (limits2[0] <= int(rates[0]) <= limits2[1])]
		rpt = [
			'avg\tstdev\tlimits\t\tlimits 2\n%d\t%d\t%s\t%s\n%d\t%d' % (int(avg[0]), int(stdev[0]), limits, limits2, int(avg[1]), int(stdev[1])),
			'outside 1 stdev: %s' % ' '.join([name for name,rates in self.rates.iteritems() if not (limits[0] <= int(rates[0]) <= limits[1]) and name not in bad]),
			'outside 2 stdev:', ' '.join(bad)]
		f = open(os.path.join(self.target, 'rpt-lost.txt'), 'w')
		for x in rpt:
			print x
			print >>f, x

	def print_results(self, step):
		if self.stats:
			f = open(os.path.join(self.target, 'lost.csv'), 'w')
			accneeded = ['ACC-%s' % x for x in NEEDED]
			allneeded = NEEDED + accneeded
			percents = ['I%', 'P%', 'B%', 'O%', 'A%']
			accpercents = ['ACC-%s' % x for x in percents]
			absolute = allneeded + percents + accpercents
			rex = re.compile('A(LL|\%)')
			relneeded = ['REL-%s' % x for x in absolute if not rex.search(x)]
			print >>f, '\t'.join(['SEC'] + absolute + relneeded)
			print >>f, '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t'
			self.accumulate()
			n = len(NEEDED)
			ns, nn = n - 2, n + n
			nns = n + ns
			half = ns / 2
			for i in range(0, max(self.stats), step):
				last = min(max(self.stats), i + step)
				values = [sum([self.stats[k][j] for k in range(i, last)]) for j in range(0, nn)]
				assert len(values) == nn
				rates = [100 * serviso.div_or_zero(values[j], values[j + 1]) for j in range(0, nn, 2)]
				assert len(rates) == n
				relative0 = [100 * serviso.div_or_zero(values[j], values[ns + (j % 2)]) for j in range(0, ns)]
				assert len(relative0) == ns
				relative1 = [100 * serviso.div_or_zero(values[j], values[nns + (j % 2)]) for j in range(n, nns)]
				assert len(relative1) == ns
				relative2 = [100 * serviso.div_or_zero(rates[j], rates[half]) for j in range(0, half)]
				assert len(relative2) == half
				relative3 = [100 * serviso.div_or_zero(rates[j], rates[9]) for j in range(half + 1, n - 1)]
				assert len(relative3) == half
				print >>f, '\t'.join([str(x) for x in [i] + values + rates + relative0 + relative1 + relative2 + relative3])

def lost(l):
	"""lost [-pSTEP] [DIR]: individual lost statistics"""
	saveBad = False
	step = 20
	if l and l[0][:2] == '-p':
		step = int(l.pop(0)[2:])
	if l:
		target = l.pop(0)
	else:
		target = util.find_target()
	statLost = StatLost()
	statLost.setdir(target)
	statLost.check_rates()
	statLost.print_results(step)
