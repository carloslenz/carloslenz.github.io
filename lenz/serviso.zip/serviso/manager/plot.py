# Carlos Eduardo Lenz - PPGCC - UFSC

import os
import os.path
import tempfile
import sys

import auto
import compare
import serviso
import util

def doGraphs(basename, opts, table=compare.TMP_INFO, cols=compare.COLS):
	basepath = os.path.expanduser(basename)
	lines = serviso.read_file_lines(basepath + '.csv')
	if lines:
		for x in opts:
			n = [y[0] for y in table].index(x)
			do_plot('%s%d_%s.png' % (basepath, n, x), compare.prepareData(lines, x, cols))

def do_plot(fname, info):
	auto.runWithInput('gnuplot', gnuplotInput(info + [fname]), compare.errDevNull())

def gnuplotInput(info):
	title, labely, labelx, data, fname = info
	datafd, datafilename = tempfile.mkstemp()
	for x in data:
		os.write(datafd, '%s\t%s\n' % x)
	lines = ['unset label',
		'set title "%s"' % title, 'set ylabel "%s"' % labely,
		'set xlabel "%s"' % labelx, 'set grid', 'set terminal png size 640,360 crop', 
		'set output "%s"' % fname,
		'plot "%s" using 1:2 title "%s" with lines \n' % (datafilename, 'value')]
	return '\n'.join(lines)

def plotGeneric(l, name, all, table, cols):
	basename, opts = l[0], all
	if basename[:8] == '-extract' and len(l) > 1:
		step = basename[8:]
		basename = os.path.join(l[1], name)
		cmdl = [sys.argv[0], name, l[1]]
		if step:
			cmdl.insert(-1, '-p%s' % step)
		util.sysl(cmdl)
		l = [basename] + l[2:]
	if len(l) > 1:
		opts = l[1].split(',')
		if opts[0] == '-all':
			opts = cols
	doGraphs(basename, opts, table, cols)

def plot_stat(l):
	"""plot-stat [DIR/stat | -extract[STEP] DIR] [GRAPH]: plots graphs"""
	return plotGeneric(l, 'stat', ['extra', 'qdatap', 'loss', 'latep', 'controlp'], compare.TMP_INFO, compare.COLS)

def plot_msgs(l):
	"""plot-msgs [DIR/msgs | -extract[STEP] DIR] [GRAPH]: plots msg graphs"""
	return plotGeneric(l, 'msgs', ['dif_len%sp' % x for x in ('tfrc', 'feedback', 'enter', 'nodes', 'partner', 'bmap', 'request', 'nack', 'metadata')], compare.TMP_MSGS_INFO, compare.MSGS_COLS)

def plot_nack(l):
	"""plot-nack [DIR/nack | -extract DIR] [GRAPH]: plots nack graphs"""
	return plotGeneric(l, 'nack', ['avgtm', 'avgacctm', 'avgmaxseg'], compare.TMP_NACK_INFO, compare.NACK_COLS)

def plot_lost(l):
	"""plot-lost [DIR/lost | -extract DIR] [GRAPH]: plots detailed lost graphs"""
	return plotGeneric(l, 'lost', [], compare.TMP_DETAIL_INFO, compare.DETAIL_COLS)

def plot_avail(l):
	"""plot-avail [DIR/avail | -extract DIR] [GRAPH]: plots availability, reachability graphs"""
	return plotGeneric(l, 'avail', [], compare.TMP_AVAIL_INFO, compare.AVAIL_COLS)
