# Carlos Eduardo Lenz - PPGCC - UFSC

import os
import os.path

import serviso

import util

def load_avail(target, sub):
	stat, avail, reach, play = serviso.StatFile(os.path.join(target, sub)), {}, {}, {}
	for x in stat.read([serviso.SUMMARY, serviso.AVAIL]):
		tm, seg = int(x[1]), x[2]
		if x[0] == serviso.SUMMARY:
			when = int(tm)
			if when not in play:
				play[when] = 0
			play[when] = max(play[when], seg)
		else:
			assert x[0] == serviso.AVAIL and len(x) == 5
			if not x[3]:
				continue
			target = reach # reachable in NackControl.check_available()
			if x[4]: # available in Block.{trad,smart}_create()
				target = avail # removed in Buffer.clear()
			if seg not in target:
				target[seg] = tm
#				print seg, target[seg], tm
	return avail, reach, play

def avail(l):
	"""avail [-pSTEP] [DIR]: checks when segments become reacheable, available and played"""
	step = 15
	if l and l[0][:2] == '-p':
		step = int(l.pop(0)[2:])
	if l:
		target = l.pop(0)
	else:
		target = util.find_target()
	stats = [load_avail(target, sub) for sub in os.listdir(target) if util.STATNAMEREX.match(sub)]
	def each(dict, i):
		vals = [one[i] for one in dict if i in one]
		return serviso.div_or_zero(sum(vals), len(vals))
	def do_for_all_in(idx, f=lambda v,i: v):
		dict = [x[idx] for x in stats]
		maxes = [max(x) for x in dict if x]
		if not maxes:
			return []
		return [f(each(dict, i), i) for i in range(0, max(maxes))]
	plays = do_for_all_in(2)
	reachs = do_for_all_in(1)
	avails = do_for_all_in(0)
	delayplays = [t - plays[t] for t in range(0, len(plays))]
	delayreachs = [reachs[seg] - seg for seg in range(0, len(reachs))]
	delayavails = [avails[seg] - seg for seg in range(0, len(avails))]
	reach2plays = [delayplays[i] - delayreachs[i] for i in range(0, min(len(delayplays), len(delayreachs)))]
	reach2avails = [delayavails[i] - delayreachs[i] for i in range(0, min(len(delayavails), len(delayreachs)))] 
	avail2plays = [delayplays[i] - delayavails[i] for i in range(0, min(len(delayplays), len(delayavails)))]
	def avgstep(l, x, stop):
		if not l:
			return 0
		stop = min(stop, x + len(l))
		return sum(l[x:stop]) / (stop - x)
	def fstep(l, x, stop, f):
		stop = min(stop, len(l))
		l = l[x:stop]
		if not l:
			return 0
		return f(l)
	if not (plays or reachs or avails):
		return
	f = open(os.path.join(target, 'avail.csv'), 'w')
	print >>f, 'I\tSEGS\tREACH\tAVAIL\tDELAYPLAY\tDELAYREACH\tDELAYAVAIL\tREACH2PLAY\tREACH2AVAIL\tAVAIL2PLAY'
	print >>f, ''
	for x in range(0, max(len(plays), len(reachs), len(avails)), step):
		stop = min(x + step, len(plays))
		seg = avgstep(plays, x, stop)
		reach = avgstep(reachs, x, stop)
		avail = avgstep(avails, x, stop)
		delayseg = avgstep(delayplays, x, stop)
		delayreach = fstep(delayreachs, x, stop, max)
		delayavail = fstep(delayavails, x, stop, max)
		reach2play = fstep(reach2plays, x, stop, min)
		reach2avail = fstep(reach2avails, x, stop, min)
		avail2play = fstep(avail2plays, x, stop, min)
		print >>f, '%d\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f' % (x, seg, reach, avail, delayseg, delayreach, delayavail, reach2play, reach2avail, avail2play)
