# Carlos Eduardo Lenz - PPGCC - UFSC

import select
import subprocess
import sys
import termios
import threading
import time
import tty

import util

MAX_WORKERS = 50

n_out = 0
lock = threading.RLock()

too_slow = 0
last = 0

def reset_known_hosts():
	util.sysc('cp ~/.ssh/known_hosts.local ~/.ssh/known_hosts')

def locked(f):
	got = False
	while not got:
		try:
			lock.acquire()
			got = True
			return f()
		except:
			if got:
				raise
		finally:
			if got:
				lock.release()

def pop_list(l):
	def popper():
		if l:
			return l.pop()
		return None
	return locked(popper)

def print_out(node, cmd, s):
	x = '** %s **' % cmd
	line = '=' * len(x)
	print >>sys.stdout, line
	print >>sys.stdout, x
	print >>sys.stdout,line
	print >>sys.stdout, s.strip()

def worker(prepf, proc_out, include_empty, l):
	x = pop_list(l)
	while x:
#		cmd = prepf(x)
#		print >>sys.stderr, cmd
		cmd = prepf(x).split() #cmd.split()
		s, serr = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()
		global n_out
		n_out = n_out + 1
		if s and s[:27] == 'Warning: Permanently added ':
			pos = s.find('\n')
			if pos > 0:
				s = s[pos + 1:]
		if s or include_empty:
			locked(lambda : proc_out(x, ' '.join(cmd), s))
		x = pop_list(l)

def work_all_nodes(wait_all, prepf, beforef=None, proc_out=print_out, include_empty=False, nodes=[]):
	reset_known_hosts()
	start_workers(prepf, beforef, proc_out, include_empty, nodes)
	wait_workers(wait_all)

def wait_workers(wait_all):
	try:
		while not is_enough(wait_all):
			time.sleep(5)
	except KeyboardInterrupt:
		exit()

def start_workers(prepf, beforef, proc_out, include_empty, l):
	print >>sys.stderr, 'You might want to hit ^D to load the default node list from nodes/allnodes.txt'
	if not l:
		if has_input():
			l = [util.just_hostname(s) for s in sys.stdin]
		if not l:
			l = list(default_nodes())
			if l and beforef:
				beforef()
	tl = [threading.Thread(target=worker, args=(prepf, proc_out, include_empty, l)) for x in range(0, MAX_WORKERS)]
	for t in tl:
		t.start()

def is_enough(wait_all):
	global too_slow
	global last
	miss = len(threading.enumerate()) - 1
	if miss < 1:
		return True
	if not wait_all and miss < 15:
		if 0 <= last - miss <= 5:
			too_slow = too_slow + 1
		last = miss
		got, target = float(MAX_WORKERS - miss) / MAX_WORKERS, 1 - 0.01 * too_slow
		print >>sys.stderr, ':', miss, n_out, last, too_slow, got, target
		return got > target
	print >>sys.stderr, ':', miss, n_out
	return False

def has_input(timeout=15):
	try:
		old_settings = termios.tcgetattr(sys.stdin)
		try:
			tty.setcbreak(sys.stdin.fileno())
			return select.select([sys.stdin], [], [], timeout)[0]
		finally:
			termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
	except termios.error:
		pass
	return False

def default_nodes():
	seq = set([util.just_hostname(s) for s in open('nodes/allnodes.txt')])
	for x in [util.just_hostname(s) for s in open('nodes/skip.txt')]:
		seq.discard(x)
	return seq
