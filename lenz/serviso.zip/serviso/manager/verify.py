# Carlos Eduardo Lenz - PPGCC - UFSC

import sys

import util
import work

def verify_cron(l):
	"""verify-cron [-auto-ssh]: verify which nodes are broken beyond repair"""
	autoLog = l and l[0] == '-auto-ssh'
	f = open('nodes/error.txt', 'w')
	def write_node_error(node,s):
		print >>f, '%s,%s' % (node, s)
		f.flush()
	missing_cron = []
	def proc_out(node, cmd, s):
		s = s.strip()
		if s == 'Permission denied (publickey).':
			write_node_error(node, 'denied')
		elif s == 'Permission denied (publickey,keyboard-interactive).':
			write_node_error(node, 'denied')
		elif s == 'src/vsh.c:297: getpwnam_r(rnp_LAPESD)':
			write_node_error(node, 'crashed')
		elif s == 'ssh: connect to host %s port 22: Connection refused' % node:
			write_node_error(node, 'refused')
		elif s == 'Read from socket failed: Connection reset by peer':
			write_node_error(node, 'reset')
		elif s == 'ssh_exchange_identification: read: Connection reset by peer':
			write_node_error(node, 'reset')
		elif s == 'ssh_exchange_identification: Connection closed by remote host':
			write_node_error(node, 'closed')
		elif s[:21] == 'Connection closed by ':
			write_node_error(node, 'closed by')
		elif s == 'ssh: Could not resolve hostname %s: nodename nor servname provided, or not known' % node:
			write_node_error(node, 'unresolved')
		elif s == 'ssh: connect to host %s port 22: Operation timed out' % node:
			write_node_error(node, 'timeout')
		elif s == 'sudo: sorry, you must have a tty to run sudo':
			write_node_error(node, 'sudo crond')
			missing_cron.append(node)
			print node, 'SUDO'
		elif s == '':
			pass
		elif s == 'Starting crond: [  OK  ]':
			pass
		elif s == """We trust you have received the usual lecture from the local System
Administrator. It usually boils down to these three things:

    #1) Respect the privacy of others.
    #2) Think before you type.
    #3) With great power comes great responsibility.

[  OK  ] crond: [  OK  ]""":
			pass
		else:
		 print >>sys.stderr, 'unexpected: "%s", output: "%s"' % (cmd, s)
	work.work_all_nodes(True, lambda name: 'ssh rnp_LAPESD@%s python Control.py start-cron' % name, proc_out=proc_out, include_empty=True)
	if autoLog:
		util.sysl([sys.argv[0], 'auto', 'ssh'] + missing_cron)
