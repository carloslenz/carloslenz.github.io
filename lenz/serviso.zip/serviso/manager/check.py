# Carlos Eduardo Lenz - PPGCC - UFSC

import os
import os.path
import subprocess
import sys

import serviso
import util

ALLNODES_TXT = 'nodes/allnodes.txt'

def check_nodes1(l):
	rtt = float(l[0])
	min_ok = int(l[1])
	min_rate = float(l[2])
	dir = os.path.expanduser('~/tmp/Experiment/allnodes')
	out = open('nodes/check.txt', 'w')
	def load_allnodes_txt(hostname):
		path = '%s/%s/allnodes.txt' % (dir, hostname)
		if os.path.isfile(path):
			return serviso.AllNodes(path, min_ok, min_rate, 0, 0, rtt, hostname)
		return None
	l = [info for info in [load_allnodes_txt(x) for x in os.listdir(dir)] if info]
	l.sort(key=lambda x: -len(x.good_nodes()))
	print >>out, len(l)
	names = set([x.hostname for x in l])
	for alnds in l:
		alnds.nodes = [hs for hs in alnds.nodes if hs.hostname in names]
	prev_rate = 0
	bad = [x for x in l if not x.network_ok(False)]
	while bad:
		bad = [(len(x.good_nodes()), x) for x in bad]
		bad.sort()
		n = bad[0][0]
		limit = n * 1.15
		asbad = [x for q,x in bad if q <= limit]
		tot = len(l)
		nbad = len(asbad)
		resp = 'n'
		new_rate = n * 100.0 / tot
		if new_rate - prev_rate > 5 and nbad > 5:
			resp = raw_input('Removing %d having %d (%d%%) out of %d, abort? ' % (nbad, n, new_rate, tot))
		else:
			print 'Auto-removed %d having %d (%d%%) out of %d!' % (nbad, n, new_rate, tot)
		if resp.lower() in ('y', 'yes'):
			break
		prev_rate = new_rate
		for x in asbad:
			l.remove(x)
			print >> out, '-%s' % x.hostname
			for h in l:
				h.remove(x)
		bad = [x for x in l if not x.network_ok(False)]
	l.sort(key=lambda x: -len(x.good_nodes()))
	for x in l:
		print >>out, x.hostname, len(x.good_nodes())
	print >>out, len(l)
	return True

def check_nodes(l=[], rate='0.9'):
	"""check-nodes [-fetch] [-put] [RATE]: detects nodes with acceptable round trip time"""
	putCheck = False
	if l and l[0] == '-fetch':
		l.pop(0)
		util.sysc('%s fetch allnodes.txt' % sys.argv[0])
#		files = ['allnodes.txt']
#		target1 = fetch(files)
#		files.insert(0, target1)
#		continue_fetch(files)
	if l and l[0] == '-put':
		putCheck = True
		l.pop(0)
	if not l:
		l = ['0.1', '10', rate]
	if check_nodes1(l) and putCheck:
		subprocess.Popen([sys.argv[0], 'put', 'nodes/check.txt'], stdin=open(ALLNODES_TXT)).communicate()
	util.sysc('cp nodes/check.txt ~/tmp/Experiment/check%d.txt' % (float(l[0]) * 1000))
	return True
