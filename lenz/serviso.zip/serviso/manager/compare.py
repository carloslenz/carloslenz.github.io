# Carlos Eduardo Lenz - PPGCC - UFSC

import os
import os.path
import re
import sys

import serviso

import util

TMP_AVAIL_INFO = [
	('played', 'played segments', 'segments'),
	('reachable', 'segment', 'instant (seconds)'),
	('available', 'segment', 'instant (seconds)'),
	('delay2play', 'segment', 'seconds'),
	('delay2reach', 'segment', 'seconds'),
	('delay2avail', 'segment', 'seconds'),
	('reach2play', 'Segments\' Tplayback - Treachable', 'seconds'),
	('reach2avail', 'Segments\' Tavailable - Treachable', 'seconds'),
	('avail2play', 'Segments\' Tplayback - Tavailable', 'seconds'),
]

TMP_DETAIL_INFO = [
	('i-lost', 'lost i-slices', 'bytes'),
	('i', 'total i-slices', 'bytes'),
	('p-lost', 'lost p-slices', 'bytes'),
	('p', 'all p-slices', 'bytes'),
	('b-lost', 'lost b-slices', 'bytes'),
	('b', 'b-slices', 'bytes'),
	('other-lost', 'other lost', 'bytes'),
	('other', 'total audio', 'bytes'),
	('all-lost', 'total lost data', 'bytes'),
	('all', 'total data', 'bytes'),
	('acci-lost', 'total lost i-slices', 'bytes'),
	('acci', 'total i-slices', 'bytes'),
	('accp-lost', 'total lost p-slices', 'bytes'),
	('accp', 'total p-slices', 'bytes'),
	('accb-lost', 'total lost b-slices', 'bytes'),
	('accb', 'total b-slices', 'bytes'),
	('accother-lost', 'total other-lost', 'bytes'),
	('accother', 'total other', 'bytes'),
	('accall-lost', 'total lost data', 'bytes'),
	('accall', 'total data', 'bytes'),
	('ip', 'i-lost / i', 'loss%'),
	('pp', 'p-lost / p', 'loss%'),
	('bp', 'b-lost / b', 'loss%'),
	('otherp', 'other-lost / other', 'loss%'),
	('allp', 'all-lost / all', 'loss%'),
	('accip', 'i-lost / i', 'loss%'),
	('accpp', 'p-lost / p', 'loss%'),
	('accbp', 'b-lost / b', 'loss%'),
	('accotherp', 'other-lost / other', 'loss%'),
	('accallp', 'all-lost / all', 'loss%'),

	('reli-lost', 'lost i-slices', 'loss%'),
	('reli', 'total i-slices', 'bytes%'),
	('relp-lost', 'lost p-slices', 'loss%'),
	('relp', 'all p-slices', 'bytes%'),
	('relb-lost', 'b-slices', 'loss%'),
	('relb', 'b-slices', 'bytes%'),
	('relother-lost', 'audio lost', 'loss%'),
	('relother', 'total audio', 'bytes%'),

	('relacci-lost', 'lost i-slices', 'loss%'),
	('relacci', 'total i-slices', 'bytes%'),
	('relaccp-lost', 'lost p-slices', 'loss%'),
	('relaccp', 'all p-slices', 'bytes%'),
	('relaccb-lost', 'b-slices', 'loss%'),
	('relaccb', 'b-slices', 'bytes%'),
	('relaccother-lost', 'audio lost', 'loss%'),
	('relaccother', 'total audio', 'bytes%'),

	('relip', 'i-lost / i', 'loss%'),
	('relpp', 'p-lost / p', 'loss%'),
	('relbp', 'b-lost / b', 'loss%'),
	('relotherp', 'other-lost / other', 'loss%'),
	('relaccip', 'i-lost / i', 'loss%'),
	('relaccpp', 'p-lost / p', 'loss%'),
	('relaccbp', 'b-lost / b', 'loss%'),
	('relaccotherp', 'other-lost / other', 'loss%'),
]

TMP_NACK_INFO = [
	('tm', 'nacks / s', 'nacks'),
	('seg', 'nacks / segment', 'nacks'),
	('acctm', 'nacks / s', 'nacks'),
	('accseg', 'nacks / segment', 'nacks'),
	('maxseg', 'nacks / segment', 'nacks'),
	('avgtm', 'nacks / nodes / s', 'nacks'),
	('avgseg', 'nacks / nodes / segment', 'nacks'),
	('avgacctm', 'nacks / nodes / s', 'nacks'),
	('avgaccseg', 'nacks / nodes / segment', 'nacks'),
	('avgmaxseg', 'nacks / nodes / segment', 'nacks'),
]

TMP_INFO = [
	('control', 'Transmitted bytes (Control messages)', 'bytes'),
	('overhead', 'Retransmitted bytes', 'bytes'),
	('qdata', 'Transmitted (QDATA) bytes', 'bytes'),
	('out', 'Transmitted bytes', 'bytes'),
	('late', 'late bytes', 'bytes'),
	('lost', 'lost bytes', 'bytes'),
	('read', 'read bytes', 'bytes'),
	('nr_out', 'hosts transmitting', 'hosts'),
	('nr_read', 'hosts reading', 'hosts'),
	('dif_control', 'Transmitted bytes by Period (Control messages)', 'bytes'),
	('dif_overhead', 'Retransmitted bytes by Period', 'bytes'),
	('dif_qdata', 'Transmitted (QDATA) bytes by Period', 'bytes'),
	('dif_out', 'Transmitted bytes by Period', 'bytes'),
	('dif_late', 'Late bytes by Period', 'bytes'),
	('dif_lost', 'Lost bytes by Period', 'bytes'),
	('dif_read', 'Read bytes by Period', 'bytes'),
	('base', 'out - overhead - control', 'bytes'),
	('ncontrol', 'control / block_size', 'block-s'),
	('noverhead', 'overhead / block_size', 'block-s'),
	('nqdata', 'qdata / block_size', 'block-s'),
	('nbase', 'base / block_size', 'blocks'),
	('nout', 'out / block_size', 'blocks'),
	('nlate', 'late / block_size', 'blocks'),
	('nlost', 'lost / block_size', 'blocks'),
	('nread', 'read / block_size', 'blocks'),
	('rel_control', 'control / block_size / nrNodes', 'blocks per host'),
	('rel_overload', 'overhead / block_size / nrNodes', 'blocks per host'),
	('rel_qdata', 'qdata / block_size / nrNodes', 'blocks per host'),
	('rel_base', 'base / block_size / nrNodes', 'blocks per host'),
	('rel_out', 'base / block_size / nrNodes', 'blocks per host'),
	('controlp', 'Control by Period', 'control%'),
	('extra', 'Overhead by Period', 'overhead%'),
	('qdatap', 'QDATA by Period', 'qdata%'),
	('latep', 'Late by Period', 'late%'),
	('loss', 'Loss by Period', 'loss%'),
	('acccontrolp', 'Accumulated Control', 'control%'),
	('accextra', 'Accumulated Overhead', 'overhead%'),
	('accqdatap', 'Accumulated QDATA', 'qdata%'),
	('acclatep', 'Accumulated Late', 'late%'),
	('accloss', 'Accumulated Loss', 'loss%'),
	('accbase', 'Accumulated Base', 'bytes'),
]

TMP_MSGS_INFO = [
	('tfrc', 'TFRC DATA messages', 'messages'),
	('feedback', 'TFRC FEEDBACK messages', 'messages'),
	('enter', 'ENTER messages', 'messages'),
	('leave', 'LEAVE messages', 'messages'),
	('nodes', 'NODES messages', 'messages'),
	('partner', 'PARTNER messages', 'messages'),
	('data', 'DATA messages', 'messages'),
	('bmap', 'BMAP messages', 'messages'),
	('request', 'REQUEST messages', 'messages'),
	('nack', 'NACK messages', 'messages'),
	('gossip', 'GOSSIP messages', 'messages'),
	('qnack', 'QNACK messages', 'messages'),
	('qdata', 'QDATA messages', 'messages'),
	('multi', 'MULTI messages', 'messages'),
	('start', 'START messages', 'messages'),
	('metadata', 'METADATA messages', 'messages'),

	('lentfrc', 'TFRC DATA messages', 'bytes'),
	('lenfeedback', 'TFRC FEEDBACK messages', 'bytes'),
	('lenenter', 'ENTER messages', 'bytes'),
	('lenleave', 'LEAVE messages', 'bytes'),
	('lennodes', 'NODES messages', 'bytes'),
	('lenpartner', 'PARTNER messages', 'bytes'),
	('lendata', 'DATA messages', 'bytes'),
	('lenbmap', 'BMAP messages', 'bytes'),
	('lenrequest', 'REQUEST messages', 'bytes'),
	('lennack', 'NACK messages', 'bytes'),
	('lengossip', 'GOSSIP messages', 'bytes'),
	('lenqnack', 'QNACK messages', 'bytes'),
	('lenqdata', 'QDATA messages', 'bytes'),
	('lenmulti', 'MULTI messages', 'bytes'),
	('lenstart', 'START messages', 'bytes'),
	('lenmetadata', 'METADATA messages', 'bytes'),

	('dif_tfrc', 'TFRC DATA messages', 'messages'),
	('dif_feedback', 'TFRC FEEDBACK messages', 'messages'),
	('dif_enter', 'ENTER messages', 'messages'),
	('dif_leave', 'LEAVE messages', 'messages'),
	('dif_nodes', 'NODES messages', 'messages'),
	('dif_partner', 'PARTNER messages', 'messages'),
	('dif_data', 'DATA messages', 'messages'),
	('dif_bmap', 'BMAP messages', 'messages'),
	('dif_request', 'REQUEST messages', 'messages'),
	('dif_nack', 'NACK messages', 'messages'),
	('dif_gossip', 'GOSSIP messages', 'messages'),
	('dif_qnack', 'QNACK messages', 'messages'),
	('dif_qdata', 'QDATA messages', 'messages'),
	('dif_multi', 'MULTI messages', 'messages'),
	('dif_start', 'START messages', 'messages'),
	('dif_metadata', 'METADATA messages', 'messages'),

	('dif_lentfrc', 'TFRC DATA messages', 'bytes'),
	('dif_lenfeedback', 'TFRC FEEDBACK messages', 'bytes'),
	('dif_lenenter', 'ENTER messages', 'bytes'),
	('dif_lenleave', 'LEAVE messages', 'bytes'),
	('dif_lennodes', 'NODES messages', 'bytes'),
	('dif_lenpartner', 'PARTNER messages', 'bytes'),
	('dif_lendata', 'DATA messages', 'bytes'),
	('dif_lenbmap', 'BMAP messages', 'bytes'),
	('dif_lenrequest', 'REQUEST messages', 'bytes'),
	('dif_lennack', 'NACK messages', 'bytes'),
	('dif_lengossip', 'GOSSIP messages', 'bytes'),
	('dif_lenqnack', 'QNACK messages', 'bytes'),
	('dif_lenqdata', 'QDATA messages', 'bytes'),
	('dif_lenmulti', 'MULTI messages', 'bytes'),
	('dif_lenstart', 'START messages', 'bytes'),
	('dif_lenmetadata', 'METADATA messages', 'bytes'),

	('tfrcp', 'TFRC DATA messages%', 'messages%'),
	('feedbackp', 'TFRC FEEDBACK messages%', 'messages%'),
	('enterp', 'ENTER messages%', 'messages%'),
	('leavep', 'LEAVE messages%', 'messages%'),
	('nodesp', 'NODES messages%', 'messages%'),
	('partnerp', 'PARTNER messages%', 'messages%'),
	('datap', 'DATA messages%', 'messages%'),
	('bmapp', 'BMAP messages%', 'messages%'),
	('requestp', 'REQUEST messages%', 'messages%'),
	('nackp', 'NACK messages%', 'messages%'),
	('gossipp', 'GOSSIP messages%', 'messages%'),
	('qnackp', 'QNACK messages%', 'messages%'),
	('qdatap', 'QDATA messages%', 'messages%'),
	('multip', 'MULTI messages%', 'messages%'),
	('startp', 'START messages%', 'messages%'),
	('metadatap', 'METADATA messages%', 'messages%'),

	('lentfrcp', 'TFRC DATA messages', 'bytes%'),
	('lenfeedbackp', 'TFRC FEEDBACK messages', 'bytes%'),
	('lenenterp', 'ENTER messages', 'bytes%'),
	('lenleavep', 'LEAVE messages', 'bytes%'),
	('lennodesp', 'NODES messages', 'bytes%'),
	('lenpartnerp', 'PARTNER messages', 'bytes%'),
	('lendatap', 'DATA messages', 'bytes%'),
	('lenbmapp', 'BMAP messages', 'bytes%'),
	('lenrequestp', 'REQUEST messages', 'bytes%'),
	('lennackp', 'NACK messages', 'bytes%'),
	('lengossipp', 'GOSSIP messages', 'bytes%'),
	('lenqnackp', 'QNACK messages', 'bytes%'),
	('lenqdatap', 'QDATA messages', 'bytes%'),
	('lenmultip', 'MULTI messages', 'bytes%'),
	('lenstartp', 'START messages', 'bytes%'),
	('lenmetadatap', 'METADATA messages', 'bytes%'),

	('dif_tfrcp', 'TFRC DATA messages%', 'messages%'),
	('dif_feedbackp', 'TFRC FEEDBACK messages%', 'messages%'),
	('dif_enterp', 'ENTER messages%', 'messages%'),
	('dif_leavep', 'LEAVE messages%', 'messages%'),
	('dif_nodesp', 'NODES messages%', 'messages%'),
	('dif_partnerp', 'PARTNER messages%', 'messages%'),
	('dif_datap', 'DATA messages%', 'messages%'),
	('dif_bmapp', 'BMAP messages%', 'messages%'),
	('dif_requestp', 'REQUEST messages%', 'messages%'),
	('dif_nackp', 'NACK messages%', 'messages%'),
	('dif_gossipp', 'GOSSIP messages%', 'messages%'),
	('dif_qnackp', 'QNACK messages%', 'messages%'),
	('dif_qdatap', 'QDATA messages%', 'messages%'),
	('dif_multip', 'MULTI messages%', 'messages%'),
	('dif_startp', 'START messages%', 'messages%'),
	('dif_metadatap', 'METADATA messages%', 'messages%'),

	('dif_lentfrcp', 'TFRC DATA messages', 'bytes%'),
	('dif_lenfeedbackp', 'TFRC FEEDBACK messages', 'bytes%'),
	('dif_lenenterp', 'ENTER messages', 'bytes%'),
	('dif_lenleavep', 'LEAVE messages', 'bytes%'),
	('dif_lennodesp', 'NODES messages', 'bytes%'),
	('dif_lenpartnerp', 'PARTNER messages', 'bytes%'),
	('dif_lendatap', 'DATA messages', 'bytes%'),
	('dif_lenbmapp', 'BMAP messages', 'bytes%'),
	('dif_lenrequestp', 'REQUEST messages', 'bytes%'),
	('dif_lennackp', 'NACK messages', 'bytes%'),
	('dif_lengossipp', 'GOSSIP messages', 'bytes%'),
	('dif_lenqnackp', 'QNACK messages', 'bytes%'),
	('dif_lenqdatap', 'QDATA messages', 'bytes%'),
	('dif_lenmultip', 'MULTI messages', 'bytes%'),
	('dif_lenstartp', 'START messages', 'bytes%'),
	('dif_lenmetadatap', 'METADATA messages', 'bytes%'),
]

def prepare_cols(table):
	cols = {}
	for n in range(0, len(table)):
		q = table[n]
		cols[q[0]] = (n + 1,) + q[1:]
	return cols

AVAIL_COLS = prepare_cols(TMP_AVAIL_INFO)
DETAIL_COLS = prepare_cols(TMP_DETAIL_INFO)
NACK_COLS = prepare_cols(TMP_NACK_INFO)
COLS = prepare_cols(TMP_INFO)
MSGS_COLS = prepare_cols(TMP_MSGS_INFO)

ALL_AVAIL = list(AVAIL_COLS)
ALL_DETAILS = list(DETAIL_COLS)
ALL_NACKS = list(NACK_COLS)
ALL = list(COLS)
ALL_MSGS = list(MSGS_COLS)

def prepareData(info, mode, table):
	table  = list(table[mode])
	i = table.pop(0)
	def getColumn():
		cols = serviso.strip_nl(s).split('\t')
		try:
			return (cols[0], cols[i])
		except:
			print 'column', i, len(cols), cols
			exit(-1)
	if isinstance(info, list):
		data = [getColumn() for s in info[2:]]
	else:
		data = [(name, [getColumn() for s in info[name][2:]]) for name in info]
		data.sort()
	return table + ['period', data]

def errDevNull():
	return open('/dev/null', 'w')

def doCompare(basename, opts, rstr, fname, table, cols, destname):
	basepath = os.path.expanduser(basename)
	stats = {}
	last = None
	storename, namerex = 'default', None
	if rstr:
		storename, namerex = rstr, re.compile(rstr)
	graphs = os.path.join(basepath, 'graphs')
	storefull = os.path.join(graphs, storename)
	if not os.path.isdir(graphs):
		os.mkdir(graphs)
	if not os.path.isdir(storefull):
		os.mkdir(storefull)
	for sub in os.listdir(basepath):
		m = util.DIRNAMEREX.match(sub)
		if m:
			if namerex and not namerex.search(sub):
				continue
			fullname = '%s/%s/%s.csv' % (basepath, sub, fname)
			name = sub.split('-')[3]
			linkname = '%s/%s-%s.csv' % (storefull, fname, name)
			srcname = '../../%s/%s.csv' % (sub, fname)
			if os.path.islink(linkname):
				os.unlink(linkname)
			try:
				lines = serviso.read_file_lines(fullname)
				if lines:
					stats[name] = last = lines
				os.symlink(srcname, linkname)
			except IOError:
				pass
	if last:
		for x in opts:
			n = [y[0] for y in table].index(x)
			plotCompare('%s/graphs/%s/%s%d_%s' % (basepath, storename, destname, n, x), prepareData(stats, x, cols))

def plotCompare(fname, info):
	scriptname = '%s.plotscript' % fname
	open(scriptname, 'w').write(gnuplotInputCompare(info + [fname]))
	util.sysl(['gnuplot', scriptname], err=errDevNull())

def write_gnuplot_data(fname, data):
	datafname = '%s.plotdata' % fname
	f = open(datafname, 'w')
	for l in data:
		f.write('%s\n' % '\t'.join(l))
	return datafname

def gnuplotInputCompare(info):
	title, labely, labelx, data, fname = info
	levels = [x[0] for x in data]
	data = adjust_data_format(data)
	datafilename = write_gnuplot_data(fname, data)
	lines = ['unset label',
		'set style line 1 lt 4 lw 3',
		'set style line 2 lt 1 lw 3',
		'set style line 3 lt 2 lw 3',
		'set style line 4 lt 3 lw 3',
		'set title "%s"' % title, 'set ylabel "%s"' % labely,
		'set xlabel "%s"' % labelx, 'set grid', 'set terminal pdf color fname "Helvetica" fsize 7 dashed size 10cm,5.6cm',
		'unset grid',
		'set output "%s.pdf"' % fname]
	header = '\n'.join(lines)
	lines = ['"%s" using 1:%d title "%s"ls %d with lines' % (datafilename, i+2, levels[i], i + 1) for i in range(0, len(levels))]
	cmds = ', '.join(lines)
	return '%s\nplot %s\n' % (header, cmds)

def adjust_data_format(data):
	step = int(data[0][1][1][0])
	if step == 1:
		step = int(data[0][1][2][0])
	for x in data: # faster to adjust in here
		if x[1][1][0] == '1': # not disible by step
			del x[1][1]
		last = int(x[1][-1][0])
		if last / step * step != last: # not disible by step
			del x[1][-1]
	n = max([int(x[1][-1][0]) for x in data])
	l = []
	def extract_v(pair, i):
		if not pair[1]:
			return '0'
		fst = pair[1].pop(0)
		if fst[0] != str(i):
			print i, fst
			exit(-1)
		return str(fst[1]) # max(0, float(fst[1])))
	return [[str(i)] + [extract_v(p, i) for p in data if 0 <= i <= 1800] for i in range(0, n + 1, step)]

def cmp_all(l):
	"""cmp-all [DIR] [-xREGEXP [-all]|-clean|-redoSTEP|-all]: plots all default graphs"""
	if not l or l[0] in ('-all', '-clean') or l[0][:2] == '-x' or l[0][:5] == '-redo':
		l.insert(0, os.path.expanduser('~/tmp/Experiment'))
	target, xopt = l.pop(0), None
	args = [target]
	if l:
		if l[0][:2] == '-x':
			xopt = l.pop(0)
			args.append(xopt)
			if l and l[0] == '-all':
				args.append(l.pop(0))
		elif l[0] == '-all':
			args.append(l.pop(0))
		elif l[0] == '-clean':
			util.sysc('rm -r %s/graphs' % args[0])
			return True
		elif l[0][:5] == '-redo':
			step = l.pop(0)[5:]
			if not step:
				step = '30'
			for sub in os.listdir(target):
				full = os.path.join(target, sub)
				if os.path.isdir(full) and util.DIRNAMEREX.match(sub):
					args1 = [sys.argv[0], 'log-dir', full]
					util.sysl(args1 + ['-clean'])
					util.sysl(args1 + ['-p%s' % step])
	util.sysl([sys.argv[0], 'cmp-stat'] + args)
	util.sysl([sys.argv[0], 'cmp-msgs'] + args)
	util.sysl([sys.argv[0], 'cmp-nack'] + args)
	util.sysl([sys.argv[0], 'cmp-lost'] + args)
	util.sysl([sys.argv[0], 'cmp-avail'] + args)
	if not xopt:
		xopt = '-xdefault'
	target = '%s/graphs/%s' % (target, xopt[2:])
	util.sysc('gs -dBATCH -dNOPAUSE -q -sDEVICE=pdfwrite -sOutputFile=%s/allgraphs.pdf %s/cmp*.pdf' % (target, target))

def cmpGeneric(l, defaultGraphs, allGraphs, fname, table, cols):
	if not l:
		l.append(os.path.expanduser('~/tmp/Experiment'))
	basename, graphs, rstr = l.pop(0), defaultGraphs, None
	if l and l[0][:2] == '-x':
		assert len(l[0]) > 2
		rstr = l.pop(0)[2:]
	if l:
		graphs = l.pop(0).split(',')
		if graphs[0] == '-all':
			graphs = allGraphs
	doCompare(basename, graphs, rstr, fname, table, cols, 'cmp-%s' % fname)

def cmp_stat(l):
	"""cmp_stat DIR [-xREGEXP] [GRAPH,s]: plots comparison graphs"""
	return cmpGeneric(l, ['dif_out', 'extra', 'qdatap', 'latep', 'loss', 'controlp'], ALL, 'stat', TMP_INFO, COLS)

def cmp_msgs(l):
	"""cmp-msgs DIR [-xREGEXP] [GRAPH,s]: plots msg comparison graph"""
	return cmpGeneric(l, [], ALL_MSGS, 'msgs', TMP_MSGS_INFO, MSGS_COLS)

def cmp_nack(l):
	"""cmp-nack DIR [-xREGEXP] [GRAPH,s]: plots nacks comparison graph"""
	return cmpGeneric(l, ['avgtm'], ALL_NACKS, 'nack', TMP_NACK_INFO, NACK_COLS)

def cmp_lost(l):
	"""cmp-lost DIR [-xREGEXP] [GRAPH,s]: plots detailed loss comparison graphs"""
	return cmpGeneric(l, ['relip', 'relaccip', 'allp'], ALL_DETAILS, 'lost', TMP_DETAIL_INFO, DETAIL_COLS)

def cmp_avail(l):
	"""cmp-avail DIR [-xREGEXP] [GRAPH,s]: plots availability,reachability graphs"""
	return cmpGeneric(l, [], ALL_AVAIL, 'avail', TMP_AVAIL_INFO, AVAIL_COLS)
