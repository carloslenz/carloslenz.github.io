# Carlos Eduardo Lenz - PPGCC - UFSC

import datetime
import re
import sys
import util
import work

import os
import os.path

import server
import work

def put(files):
	"""put [-dDIR] FILES: uplods files"""
	target = ''
	if files and len(files[0]) > 2 and files[0][:2] == '-d':
		target = files.pop(0)[2:]
	assert files
	scp = 'scp -pqrC %s rnp_LAPESD@%%s:%s' % (' '.join(files), target)
	work.work_all_nodes(True, lambda name: scp % name)

def fetch_logs(l=[]):
	"""fetch-logs:\tfetchs tmp/* from planetlab nodes"""
	path, logs = tmp_dt_dir(), 'tmp/*'
	print >>sys.stderr, path
	for i in range(0, 3):
		util.sysl([sys.argv[0], 'continue-fetch', path, logs])
	util.sysl([sys.argv[0], 'log-dir', path])
	fname = '%s/%s/output.txt' % (path, server.get_server())
	rex = re.compile('now .* cmd .* cfgs/([^ ]*)')
	for s in open(fname):
		m = rex.search(s)
		if m:
			cfg = m.group(1)
			if cfg == 'basesmart':
				name = 'SeRViSO, +00% loss, NACK disabled'
			elif cfg == 'smart':
				name = 'SeRViSO, +00% loss'
			elif cfg == 'smart05':
				name = 'SeRViSO, +05% loss'
			elif cfg == 'smart1':
				name = 'SeRViSO, +10% loss'
			elif cfg == 'smart2':
				name = 'SeRViSO, +20% loss'
			elif cfg == 'smart3':
				name = 'SeRViSO, +30% loss'
			elif cfg == 'basetrad':
				name = 'Traditional, +00% loss, NACK disabled'
			elif cfg == 'trad':
				name = 'Traditional, +00% loss'
			elif cfg == 'trad05':
				name = 'Traditional, +05% loss'
			elif cfg == 'trad1':
				name = 'Traditional, +10% loss'
			elif cfg == 'trad2':
				name = 'Traditional, +20% loss'
			elif cfg == 'trad3':
				name = 'Traditional, +30% loss'
			else:
				print >>sys.stderr, 'unknown cfg:', cfg
				break
			if path[-1] == '/':
				path = path[:-1]
			print >>sys.stderr, 'rename', path, name
			dirnames = path.split('/')
			targetname = dirnames.pop()
			basepath = '/'.join(dirnames)
			expdir = 'Experiment/'
			if not os.path.isdir(os.path.join(basepath, expdir)):
				expdir = ''
			target = '%s/%s%s-%s' % (basepath, expdir, targetname, name)
			print >>sys.stderr, 'rename', path, name, target
			os.rename(path, target)
			util.sysl([sys.argv[0], 'cmp-all'])
			break

def fetch(files):
	"""fetch FILES:\tretrieve files"""
	assert files
	target1 = tmp_dt_dir()
	print >>sys.stderr, target1
	files.insert(0, target1)
	continue_fetch(files)
	return target1

def tmp_dt_dir():
	s_date = datetime.datetime.now().strftime('%Y-%m-%d_%H_%M_%S')
	return os.path.expanduser('~/tmp/%s/' % s_date)

def continue_fetch(files):
	"""continue-fetch DIR FILES: continue a previous incomplete fetch"""
	target1 = files.pop(0)
	assert files
	nodes = work.default_nodes()
	if os.path.isdir(target1):
		for sub in os.listdir(target1):
			full = os.path.join(target1, sub)
			if os.path.isdir(full) and os.listdir(full):
				nodes.discard(sub)
	else:
		os.mkdir(target1)
	def prepare_copy(name):
		target2 = os.path.join(target1, name)
		location = 'rnp_LAPESD@%s' % name
		l = ['scp -pqrC'] +	['%s:%s' % (location, fname) for fname in files] + [target2]
		full = os.path.expanduser(target2)
		if not os.path.isdir(full):
			os.mkdir(full)
		return ' '.join(l)
	work.work_all_nodes(True, prepare_copy, nodes=list(nodes))
	print >>sys.stderr, target1
