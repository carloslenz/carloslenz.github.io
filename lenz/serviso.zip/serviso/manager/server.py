# Carlos Eduardo Lenz - PPGCC - UFSC

import cp
import util

SERVER_TXT = 'serviso/server.txt'

def get_server():
	return open(SERVER_TXT).readlines()[1].strip()

def copy_mp4(l=[]):
	"""copy-mp4:\tcopies the mp4 video to the server"""
	util.sysc('scp ~/samples/*30m_small.mp4.info rnp_LAPESD@%s:samples' % get_server())
	util.sysc('scp ~/samples/*30m_small.mp4 rnp_LAPESD@%s:samples' % get_server())

def server(l=[]):
	"""server:\tprints the selected server node"""
	print get_server()

def ssh_server(l):
	"""ssh-server [CMD...]: logs to the server node"""
	util.ssh([get_server()] + l)

def stop(l):
	"""stop:\t\tinterrupts server"""
	ssh_server(['python', 'Control.py', 'interrupt'])

def see(l):
	"""see:\t\tsees server output"""
	ssh_server(['tail', '-f', 'tmp/output.txt'])

def select_server(l):
	"""select-server SERVER [-put]: selects new server node"""
	server = l.pop(0)
	open(SERVER_TXT, 'w').write('%s\n%s\n' % (server, server))
	if l and l[0] == '-put':
		cp.put([SERVER_TXT])
