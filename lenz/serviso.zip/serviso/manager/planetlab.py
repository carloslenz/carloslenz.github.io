# Carlos Eduardo Lenz - PPGCC - UFSC

import datetime
import os.path
import subprocess
import sys
import urllib
import xmlrpclib

import check
import util
import work

SLICE_NAME = 'rnp_LAPESD'

PWDNAME = os.path.expanduser('~/Dropbox/keep4now/plbpwd')

def prospect(l):
	"""propect LOAD LIVESLICES GBFREE: finds reliable nodes using CoMon"""
	load, liveslices, gbfree = l[:3] # 5 5 0.3
	query = '(resptime > 0 && 1minload < %s && liveslices <= %s) && ((drift > 1m || (dns1udp > 80 && dns2udp > 80) || gbfree < %s || sshstatus > 2h) == 0)' % (load, liveslices, gbfree)
	url = "http://comon.cs.princeton.edu/status/tabulator.cgi?table=table_nodeviewshort&format=nameonly&sort=5minload&select='(%s)'" % urllib.quote(query)
#	print >>sys.stderr, url
	l = [s.strip() for s in urllib.urlopen(url).readlines()]
	out = open('nodes/relax.txt', 'w')
	for s in l:
		print >>out, s
	print >>sys.stderr, len(l)

def allnodes(l=[]):
	"""allnodes:\tsaves PlanetLab's slice node list"""
	subprocess.Popen([sys.argv[0], 'planetlab', '-list'], stdout=open(check.ALLNODES_TXT, 'w')).communicate()


def planetlab(l):
	"""planetlab [-list]: adds/removes/lists nodes to/from/with the slice"""
	api_server = xmlrpclib.ServerProxy('https://www.planet-lab.org/PLCAPI/')
	auth = {}
	auth['Username'] = "carlos.lenz@gmail.com"
	auth['AuthString'] = open(PWDNAME).read().strip()
	auth['AuthMethod'] = "password"
	if l and l[0] == '-list':
		node_ids = api_server.GetSlices(auth, [SLICE_NAME], ['node_ids'])[0]['node_ids']
		hostnames = [node['hostname'] for node in api_server.GetNodes(auth, node_ids, ['hostname'])]
		for name in hostnames:
			print name
	else:
		print >>sys.stderr, 'You might want to hit ^D to read node list from the default nodes/append.txt.'
		l = []
		if work.has_input():
			l = [s.strip() for s in stdin]
		if not l:
			l = [s.strip() for s in open('nodes/append.txt')]
		
		adds = [s for s in l if s and s[0] != '-']
		rmvs = [s[1:] for s in l if s and s[0] == '-']
		
		if adds:
			api_server.AddSliceToNodes(auth, SLICE_NAME, adds)
		if rmvs:
			api_server.DeleteSliceFromNodes(auth, SLICE_NAME, rmvs)
		print 'added', len(adds), 'removed', len(rmvs)
		when = datetime.datetime.now() + datetime.timedelta(minutes=30)
		print 'wait until: %d:%d' % (when.hour, when.minute)

def prepare_append(l=[]):
	"""prepare-append:\tfinds news nodes add, bad ones to remove"""
	util.sysc('%s prospect 5 5 0.3' % sys.argv[0]) and \
	check.check_nodes(rate='0.5') and \
	util.sysc('%s sort-nodes simple < nodes/check.txt > nodes/sorted.txt' % sys.argv[0]) and \
	util.sysc('%s prep-append nodes/allnodes.txt nodes/relax.txt > nodes/prepare.txt' % sys.argv[0]) and \
	util.sysc('%s filter-append nodes/sorted.txt nodes/error.txt < nodes/prepare.txt > nodes/append.txt 2> nodes/notbad.txt' % sys.argv[0])
