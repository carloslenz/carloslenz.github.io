# Carlos Eduardo Lenz - PPGCC - UFSC

from datetime import datetime

import os
import os.path
import sys
import tempfile
import time

import serviso

import util

# SCRIPT HELPERS

def grep(l):
	"""grep REGEXP:\tgreps serviso source code directory"""
	util.sysc('grep %s serviso/serviso/*y' % ' '.join(l))

def delay(l):
	"""delay MIN[:SEC]: sleeps"""
	values = l.pop(0).split(':')
	seconds = 0
	minutes = int(values.pop(0))
	if values:
		seconds = int(values.pop(0))
	while minutes > 0:
		print 'now %s remaining %d' % (datetime.now(), minutes)
		time.sleep(60)
		minutes = minutes - 1
	time.sleep(seconds)
	print 'now %s waking up...' % datetime.now()

def batch(l):
	"""batch [CMD | N CMD...]*: runs commands in series"""
	while l:
		s = l.pop(0)
		try:
			n = int(s)
			s = ' '.join(l[:n])
			l = l[n:]
		except:
			pass
		if not util.sysc('%s %s' % (sys.argv[0], s)):
			break

# LOCAL REPO

def clear(l=[]):
	"""clear:\t\tremoves pyc, egg, ..."""
	clear_local()
	clear_remote()

def clear_local():
	util.sysc('rm *.pyc *~ serviso/serviso/*.pyc manager/*.pyc 2> /dev/null') and \
	util.sysc('rm -rf serviso/dist serviso/build serviso/serviso.egg-info')

# GIT

def gitpush(l=[]):
	"""gitpush:\tpushes changes to origin"""
	util.sysc('git push origin')

def githealth(l=[]):
	"""githealth:\tcleans up repository"""
	util.sysc('git fsck --full') and \
	util.sysc('git prune') and \
	util.sysc('git count-objects') and \
	util.sysc('git gc --aggressive --quiet')

# BACKUP

def redeinf_tgz(l=[]):
	"""redeinf-tgz:\tuploads a tgz backup to RedeINF"""
	githealth()
	before_dir = os.getcwd()
	os.chdir(os.path.expanduser('~/Documents/GIT'))
	tmpbck = tempfile.NamedTemporaryFile()
	tmpname = tmpbck.name
	if util.sysc('tar zcf %s serviso' % tmpname):
		util.sysc('scp %s lenz@venus.inf.ufsc.br:autoria/tese/code/python/serviso.tgz' % tmpname)
		if os.path.isdir('/Volumes/CEL_01'):
			util.sysc('cp -v %s /Volumes/CEL_01/tese/code/python/serviso.tgz' % tmpname)
		os.chdir(before_dir)

def upload(l=[]):
	"""upload:\t\tbackups to origin and RedeINF"""
	clear(*l)
	gitpush()
	redeinf_tgz()

# PYT

def test_pyt(l):
	"""test-pyt CFG:\tupdates $HOME/pyt and tests locally"""
	if pyt():
		util.sysl([sys.argv[0], 'auto', 'config/pyt', l[0]])

def pyt(l=[]):
	"""pyt:\t\tbuilds egg and uploads to $HOME/pyt"""
	if util.sysc('python serviso/serviso/util.py'):
		before_dir = os.getcwd()
		os.chdir('serviso')
		ret = util.sysc('python setup.py bdist_egg')
		if ret:
			os.environ['PYTHONPATH'] = os.path.join(os.environ['HOME'], 'pyt')
			ret = util.sysc('%s/pyt/bin/easy_install --install-dir=$PYTHONPATH --prefix=$PYTHONPATH dist/serviso-0.4dev-py2.5.egg' % os.environ['HOME'])
		os.chdir(before_dir)
		return ret
	return False

# EGG

def egg(l=[]):
	"""egg:\t\tbuilds and uploads egg"""
	if pyt(l):
		util.sysc('scp serviso/dist/*.egg lenz@venus.inf.ufsc.br:public_html')

def clear_remote():
	util.sysc("ssh lenz@venus.inf.ufsc.br 'rm -f public_html/*.egg'")

# GENERATOR

def gen_details(l):
	"""gen-details [CFGFNAME]: generate mp4.details"""
	cfgname = 'cfgs/basesmart'
	if l:
		cfgname = l.pop(0)
	config = serviso.Config()
	config.load_from_file(cfgname)
	config.adjust_logger(serviso.DEFAULT_RENDEZVOUS_PORT, None, True)
	isTest = re.search('test', config.mode)
	syst = serviso.System('127.0.0.1', serviso.DEFAULT_RENDEZVOUS_PORT, config, True, True, isTest)
	loader, buffer, stop, cont = syst.loader, syst.buffer, 0, True
	f = open(os.path.expanduser('%s.details' % config.path), 'w')
	while cont:
		for q in range(0, config.map_size):
			if not loader():
				cont = False
				break
			stop, s = buffer.get(buffer.last_block()).encoded(stop)
			f.write(s)
		buffer.read_index = buffer.last_block() - config.map_size / 2
		buffer.purge_erasable()
	print serviso.okrate()
